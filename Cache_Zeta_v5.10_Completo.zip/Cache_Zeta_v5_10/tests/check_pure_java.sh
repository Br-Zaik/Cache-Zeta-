#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
javac -encoding UTF-8 -d "$WORK" \
  app/src/main/java/com/zetacache/app/{AppTarget,SelectionRules,UiLabels,SessionState,IdenticalFiles,StorageDocuments}.java \
  tests/PureJavaCheck.java tests/FilesCheck.java tests/StorageWalkCheck.java
java -cp "$WORK" PureJavaCheck
java -cp "$WORK" com.zetacache.app.FilesCheck
java -cp "$WORK" com.zetacache.app.StorageWalkCheck "$WORK"
javac -encoding UTF-8 -d "$WORK" tests/ParseAndroidSources.java
java -cp "$WORK" ParseAndroidSources

python3 tests/check_ui_source.py

python3 tests/check_history.py
