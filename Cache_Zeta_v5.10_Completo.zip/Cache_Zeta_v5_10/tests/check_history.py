"""Exercise the v3-to-v4 history migration using the app's actual SQL."""
from pathlib import Path
import re
import sqlite3

source = Path("app/src/main/java/com/zetacache/app/ResultsDb.java").read_text()
history = source.split("List<Row> history", 1)[1]
queries = [
    "".join(re.findall(r'"([^"]*)"', parts))
    for parts in re.findall(r"String query=(.*?);", history, re.S)
]

with sqlite3.connect(":memory:") as db:
    for statement in re.findall(r'execSQL\("(CREATE [^"]+)', source):
        db.execute(statement)
    db.executescript("""
        CREATE TABLE previews(id TEXT PRIMARY KEY, jpeg BLOB NOT NULL);
        CREATE TABLE detail_previews(session INTEGER,ref TEXT,preview TEXT,PRIMARY KEY(session,ref));
        INSERT INTO sessions VALUES(1,100,'Duplicados · Fotos','Terminada');
        INSERT INTO details VALUES(1,'a','foto.jpg','Memoria interna',1024,0,'Eliminado');
        INSERT INTO previews VALUES('abc',zeroblob(8192));
        INSERT INTO detail_previews VALUES(1,'a','abc');
        INSERT INTO media VALUES(0,'b','uri','foto.jpg','SD',1024,1234,'abc');
        INSERT INTO sessions VALUES(2,110,'Caché de apps','Terminada');
        INSERT INTO details VALUES(2,'app','Mi app','app',4096,-1,'Sin verificar');
    """)
    for statement in re.findall(r'execSQL\("(DROP TABLE IF EXISTS [^"]+)', source):
        db.execute(statement)
    tables = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert tables == {"sessions", "details", "hash_work", "media"}
    assert db.execute("SELECT count(*) FROM media").fetchone() == (1,)
    assert db.execute(queries[0], (1,)).fetchone()[4:] == (1, 4096, None, 0)
    assert db.execute(queries[1], (1, 100)).fetchall() == [("foto.jpg", 1024, 0, "Eliminado")]
    assert db.execute(queries[1], (2, 100)).fetchall() == [("Mi app", 4096, -1, "Sin verificar")]
print("OK: migración del historial con nombres, tamaños e índice de duplicados conservados")
