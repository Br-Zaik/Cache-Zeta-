package com.zetacache.app;

import org.junit.Test;
import java.util.*;
import static org.junit.Assert.*;

public class GallerySelectionTest {
    private DuplicateIndex.Family group(int n){
        DuplicateIndex.Family family=new DuplicateIndex.Family("hash"+n);
        for(int copy=0;copy<3;copy++){
            String key=n+"/"+copy;
            family.items.add(new DuplicateIndex.Item(key,null,key,"memoria/"+key,21,0,0));
        }
        return family;
    }
    @Test public void batchPreservesOnePerGroup(){
        Set<String> marks=new HashSet<>();
        for(int i=0;i<815;i++){
            DuplicateIndex.Family family=group(i);
            family.markCopies(marks);
            assertSame(family.items.get(0),family.keeper(marks));
            assertFalse(family.toggle(family.items.get(0),marks));
        }
        assertEquals(1630,marks.size());
    }
    @Test public void chosenKeeperSurvivesBulkSelection(){
        DuplicateIndex.Family family=group(0);Set<String> marks=new HashSet<>();
        family.toggle(family.items.get(0),marks);
        family.markCopies(marks);
        assertSame(family.items.get(1),family.keeper(marks));
    }
    @Test public void manualFloorAppliesToTopAndPickedApps(){
        long mb=1048576;
        List<AppTarget> apps=Arrays.asList(new AppTarget("a","A",false,19*mb),new AppTarget("b","B",false,20*mb));
        Set<String> picks=new HashSet<>(Arrays.asList("a","b"));
        for(int filter:new int[]{SelectionRules.CUSTOM,SelectionRules.MANUAL}){
            List<AppTarget> selected=SelectionRules.select(apps,true,filter,10,picks,true,20*mb);
            assertEquals(1,selected.size());assertEquals("b",selected.get(0).packageName);
        }
    }
}
