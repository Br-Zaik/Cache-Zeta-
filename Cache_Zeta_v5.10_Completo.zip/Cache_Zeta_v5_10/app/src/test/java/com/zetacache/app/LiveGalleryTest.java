package com.zetacache.app;

import org.junit.Test;
import java.util.List;
import java.io.*;
import static org.junit.Assert.*;

public class LiveGalleryTest {
    private static DuplicateIndex.Item file(String name,long size){
        return new DuplicateIndex.Item(name,null,name,"SD/"+name,size,1,0);
    }
    @Test public void publishesOnlyRealPairsAndKeepsEarlierSnapshotStable(){
        ScanProgress scan=new ScanProgress(0,"SD");
        scan.verified("hash1",file("a",8));
        scan.verified("different",file("b",8));assertEquals(0,scan.groups());
        scan.verified("hash1",file("c",8));
        List<DuplicateIndex.Family> first=scan.snapshot();
        assertEquals(1,first.size());assertEquals(2,first.get(0).items.size());
        scan.verified("hash1",file("d",8));
        scan.verified("hash2",file("x",20));
        scan.verified("hash2",file("y",20));
        assertEquals(2,first.get(0).items.size());
        assertEquals(3,scan.snapshot().get(0).items.size());
        assertEquals(2,scan.groups());
    }
    @Test public void showsEnumerationAndBytesConsumed(){
        ScanProgress scan=new ScanProgress(1,"phone");
        scan.found("Movies/2026.mp4");assertEquals(1,scan.listed);
        scan.file("Movies/2026.mp4",200000);
        try(InputStream in=scan.counting(new ByteArrayInputStream(new byte[200000]))){
            byte[] buffer=new byte[65536];
            assertEquals(65536,in.read(buffer));assertEquals(65536,scan.bytes);
            while(in.read(buffer)!=-1){}
        }catch(IOException e){throw new AssertionError(e);}
        assertEquals(200000,scan.bytes);
    }
}
