package com.zetacache.app;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/** A worker publishes counters and newly verified families. The UI only copies changed results. */
final class ScanProgress {
    final int type;
    final String scope;
    volatile String location="";
    volatile int listed,total=-1,done;
    volatile long bytes,fileSize;
    volatile boolean saving;
    private final Map<String,DuplicateIndex.Item> first=new HashMap<>();
    private final LinkedHashMap<String,DuplicateIndex.Family> matches=new LinkedHashMap<>();
    private long previousSize=-1;
    private int revision;

    ScanProgress(int type,String scope){this.type=type;this.scope=scope;}
    void found(String path){listed++;location=path;}
    void file(String name,long size){location=name;fileSize=size;bytes=0;}
    InputStream counting(InputStream in){
        return new FilterInputStream(in){
            @Override public int read(byte[] b,int off,int len)throws IOException{
                int n=super.read(b,off,len);if(n>0)bytes+=n;return n;
            }
        };
    }
    synchronized void verified(String hash,DuplicateIndex.Item item){
        if(item.size!=previousSize){first.clear();previousSize=item.size;}
        String key=hash+"/"+item.size;
        DuplicateIndex.Family family=matches.get(key);
        if(family==null){
            DuplicateIndex.Item previous=first.putIfAbsent(key,item);
            if(previous==null)return;
            family=new DuplicateIndex.Family(hash);family.items.add(previous);
            matches.put(key,family);first.remove(key);
        }
        family.items.add(item);revision++;
    }
    synchronized int revision(){return revision;}
    synchronized int groups(){return matches.size();}
    synchronized List<DuplicateIndex.Family> snapshot(){
        List<DuplicateIndex.Family> copy=new ArrayList<>(matches.size());
        for(DuplicateIndex.Family family:matches.values()){
            DuplicateIndex.Family f=new DuplicateIndex.Family(family.digest);f.items.addAll(family.items);copy.add(f);
        }
        return copy;
    }
}
