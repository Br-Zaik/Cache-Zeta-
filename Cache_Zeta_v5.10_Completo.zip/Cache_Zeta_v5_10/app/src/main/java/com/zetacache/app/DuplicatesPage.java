package com.zetacache.app;

import android.app.AlertDialog;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.provider.Settings;
import android.Manifest.permission;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;

final class DuplicatesPage extends ToolsPage {
    DuplicatesPage(MainActivity host){super(host);}
    private int kind;
    private volatile int revision;
    private TextView status,scanLocation,emptyGallery;
    private ProgressBar meter;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private ScanProgress shownRun;
    private String allowedScope="";
    private int shownRevision;
    private boolean visible,partial;
    private final Runnable track=new Runnable(){public void run(){
        if(!visible)return;
        updateLive();
        if(DuplicateIndex.pending(kind))ui.postDelayed(this,500);
    }};
    private void trackNow(){ui.removeCallbacks(track);if(visible)ui.post(track);}

    private Button scan,access;
    private long approvalSession;
    private boolean requesting;
    private final BroadcastReceiver volumes=new BroadcastReceiver(){public void onReceive(Context c,Intent i){restartScan();}};
    private GridView grid;
    private Button select,review;
    private final Adapter adapter=new Adapter();
    private List<DuplicateIndex.Family> families=Collections.emptyList();
    private final ArrayList<DuplicateIndex.Item> all=new ArrayList<>(),shown=new ArrayList<>();
    private final Map<String,Integer> owner=new HashMap<>();
    private final Set<String> selected=new HashSet<>();
    private GalleryViewer viewer;
    private boolean reviewing,paused;
    private final Button[] tabs=new Button[3];
    private final Map<Integer,Set<String>> tabSelections=new HashMap<>();
    private final ExecutorService reader=Executors.newSingleThreadExecutor();
    private final BroadcastReceiver updated=new BroadcastReceiver(){public void onReceive(Context c,Intent i){int type=i.getIntExtra("kind",-1);if(!deleting&&(type<0||type==kind)){if(i.getBooleanExtra("published",true))refresh();else updateStatus();}}};
    private boolean deleting;
    @Override void create(Bundle b){
        super.create(b);kind=b==null?0:b.getInt("kind");heading.setText("Duplicados");
        if(b!=null){approvalSession=b.getLong("approval");requesting=b.getBoolean("requesting");deleting=approvalSession!=0;}
        LinearLayout types=new LinearLayout(this);body.addView(types);
        for(int i=0;i<tabs.length;i++){
            final int type=i;tabs[i]=button(DuplicateIndex.TITLES[i]);action(types,tabs[i]);
            tabs[i].setOnClickListener(v->{
                if(deleting||kind==type)return;
                tabSelections.put(kind,new HashSet<>(selected));
                kind=type;allowedScope="";partial=false;shownRun=null;paused=false;reviewing=false;selected.clear();groups=0;stamp=0;
                install(Collections.emptyList());selected.addAll(tabSelections.getOrDefault(kind,Collections.emptySet()));
                showType();
            });
        }
        LinearLayout actions=new LinearLayout(this);body.addView(actions);
        access=button("Cambiar selección");action(actions,access);access.setOnClickListener(v->requestAccess());
        scan=button("Analizar");action(actions,scan);scan.setOnClickListener(v->{
            if(!DeviceStorage.allowed(this,kind)){requestAccess();return;}
            if(DuplicateIndex.pending(kind)){
                paused=true;DuplicateIndex.cancel();
            }else{
                paused=false;DuplicateIndex.focus(this,kind,true);
            }
            updateStatus();trackNow();
        });
        status=new TextView(this);status.setTextColor(NeonStyle.MUTED);status.setPadding(dp(6),dp(9),dp(6),dp(9));body.addView(status);
        meter=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        body.addView(meter,-1,dp(5));meter.setVisibility(android.view.View.GONE);
        scanLocation=new TextView(this);scanLocation.setTextColor(NeonStyle.MUTED);scanLocation.setTextSize(12);
        scanLocation.setSingleLine();scanLocation.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        body.addView(scanLocation,-1,-2);
        grid=new GridView(this);grid.setNumColumns(GridView.AUTO_FIT);grid.setColumnWidth(dp(142));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);grid.setHorizontalSpacing(dp(8));grid.setVerticalSpacing(dp(8));
        grid.setAdapter(adapter);
        FrameLayout galleryArea=new FrameLayout(this);
        body.addView(galleryArea,new LinearLayout.LayoutParams(-1,0,1));
        galleryArea.addView(grid,-1,-1);
        emptyGallery=new TextView(this);emptyGallery.setGravity(android.view.Gravity.CENTER);
        emptyGallery.setTextSize(14);emptyGallery.setTextColor(NeonStyle.MUTED);
        galleryArea.addView(emptyGallery,-1,-1);grid.setEmptyView(emptyGallery);
        LinearLayout bar=new LinearLayout(this);body.addView(bar);
        select=button("Marcar copias");action(bar,select);select.setOnClickListener(v->bulk());
        review=button("Revisar");action(bar,review);review.setOnClickListener(v->{
            if(reviewing)confirmBatch();else{reviewing=true;render();grid.setSelection(0);}
        });
    }
    @Override void enter(){visible=true;
        IntentFilter f=new IntentFilter(DuplicateIndex.EVENT);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(updated,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(updated,f);
        IntentFilter mounts=new IntentFilter();mounts.addAction(Intent.ACTION_MEDIA_MOUNTED);mounts.addAction(Intent.ACTION_MEDIA_UNMOUNTED);
        mounts.addAction(Intent.ACTION_MEDIA_REMOVED);mounts.addDataScheme("file");
        if(Build.VERSION.SDK_INT>=33)registerReceiver(volumes,mounts,Context.RECEIVER_EXPORTED);else registerReceiver(volumes,mounts);
        if(DeviceStorage.partial(this,kind)){
            // Recheck the permitted IDs before showing a previously saved partial selection.
            allowedScope="";partial=false;stamp=0;install(Collections.emptyList());
        }
        if(paused)DuplicateIndex.cancel();
        showType();
    }
    @Override void leave(){visible=false;ui.removeCallbacks(track);++revision;if(viewer!=null){viewer.close();viewer=null;}unregisterReceiver(volumes);unregisterReceiver(updated);}
    @Override void save(Bundle b){super.save(b);b.putInt("kind",kind);b.putLong("approval",approvalSession);b.putBoolean("requesting",requesting);}
    @Override void dispose(){reader.shutdownNow();super.dispose();}
    private long stamp;
    private int unread,groups;
    private boolean authorized;
    private void updateStatus(){
        boolean limited=DeviceStorage.partial(this,kind);
        access.setVisibility(limited?android.view.View.VISIBLE:android.view.View.GONE);
        access.setEnabled(!deleting&&!requesting);
        boolean working=DuplicateIndex.pending(kind);
        scan.setEnabled(!deleting&&!requesting&&!reviewing);
        scan.setText(!authorized?"Dar acceso":working?"Pausar":paused?"Reanudar":stamp>0?"Actualizar":"Analizar "+DuplicateIndex.TITLES[kind].toLowerCase(Locale.ROOT));
        for(Button tab:tabs)tab.setEnabled(!deleting&&!requesting);
        if(deleting)status.setText("Verificando copias…");
        else if(!authorized)status.setText(kind==2&&Build.VERSION.SDK_INT>=30?"Permite el acceso a todos los archivos.":"Permite el acceso para buscar duplicados.");
        else if(reviewing)status.setText("Copias que vas a borrar · "+selected.size());
        else if(working)status.setText("Analizando "+DuplicateIndex.TITLES[kind].toLowerCase(Locale.ROOT)+"…");
        else if(paused)status.setText("Análisis pausado · "+families.size()+" grupos");
        else if(DuplicateIndex.progress.equals("No se pudo analizar "+DuplicateIndex.TITLES[kind].toLowerCase(Locale.ROOT)))status.setText(DuplicateIndex.progress);
        else if(stamp==0)status.setText("Pendiente de análisis");
        else status.setText((groups==0?"Sin duplicados":groups+" grupos")+(limited?" · Acceso parcial":"")+(unread>0?" · "+unread+" sin acceso":""));
        boolean showMeter=working&&!deleting&&!reviewing&&authorized;
        meter.setVisibility(showMeter?android.view.View.VISIBLE:android.view.View.GONE);
        scanLocation.setVisibility(showMeter?android.view.View.VISIBLE:android.view.View.GONE);
        if(showMeter)describe(DuplicateIndex.live);
        String hint=!authorized?"":working?"Las coincidencias aparecerán aquí":paused?"Puedes reanudar el análisis":
                stamp>0?"No se encontraron copias idénticas":"";
        if(!android.text.TextUtils.equals(hint,emptyGallery.getText()))emptyGallery.setText(hint);
        if(select!=null){
            select.setEnabled(!deleting&&!partial&&!all.isEmpty());
            select.setText(reviewing?"Volver":selected.size()>0&&selected.size()==all.size()-families.size()?"Desmarcar":"Marcar copias");
            review.setEnabled(!deleting&&!partial&&!selected.isEmpty());
            review.setText((reviewing?"Borrar":"Revisar")+(selected.isEmpty()?"":" ("+selected.size()+")"));
        }
    }
    private void describe(ScanProgress run){
        if(run==null||run.type!=kind){
            meter.setIndeterminate(true);status.setText("Preparando análisis…");scanLocation.setText("");return;
        }
        int total=run.total;
        if(total<0){
            meter.setIndeterminate(true);
            status.setText("Buscando "+DuplicateIndex.TITLES[kind].toLowerCase(Locale.ROOT)+" · "+run.listed+" revisados");
        }else{
            meter.setIndeterminate(false);meter.setMax(Math.max(1,total));meter.setProgress(run.done);
            status.setText(run.saving?"Guardando resultados…":"Comparando "+run.done+" de "+total+" · "+run.groups()+" grupos");
        }
        String where=run.location;
        if(total>=0 && run.bytes>0 && run.bytes<run.fileSize)
            where=CacheScanner.size(run.bytes)+" / "+CacheScanner.size(run.fileSize)+" · "+where;
        scanLocation.setText(where);
    }
    private void updateLive(){
        if(deleting||reviewing||!authorized){updateStatus();return;}
        ScanProgress run=DuplicateIndex.live;
        if(run!=null&&run.type==kind&&run.scope.equals(allowedScope)&&DuplicateIndex.pending(kind)){
            if(shownRun!=run){shownRun=run;shownRevision=0;}
            int rev=run.revision();
            if(stamp==0 && rev>shownRevision){
                shownRevision=rev;partial=true;groups=run.groups();install(run.snapshot());
            }
        }
        updateStatus();
    }
    private void showType(){
        authorized=DeviceStorage.allowed(this,kind);
        if(!authorized){stamp=0;groups=0;install(Collections.emptyList());}
        for(int i=0;i<tabs.length;i++)tabs[i].setBackground(NeonStyle.ripple(NeonStyle.chip(this,i==kind)));
        if(visible&&!deleting&&!paused)DuplicateIndex.focus(this,kind,false);
        updateStatus();refresh();trackNow();
        if(visible&&!authorized&&!requesting&&!deleting&&kind<2 && !DuplicateIndex.prefs(this).getBoolean("asked"+kind,false))requestAccess();
    }
    private void refresh(){
        final int type=kind,ticket=++revision;
        reader.execute(()->{
            if(ticket!=revision)return;
            try{
            String scope=DeviceStorage.scope(this,type);
            boolean current=!scope.isEmpty()&&scope.equals(DuplicateIndex.prefs(this).getString("scope"+type,""));
            List<DuplicateIndex.Family> data=current?DuplicateIndex.families(this,type):Collections.emptyList();
            long when=current?DuplicateIndex.prefs(this).getLong("time"+type,0):0;
            runOnUiThread(()->{
                if(isDestroyed()||ticket!=revision||deleting||!visible)return;
                allowedScope=scope;authorized=!scope.isEmpty();groups=data.size();stamp=when;
                unread=DuplicateIndex.prefs(this).getInt("unread"+type,0);
                if(authorized&&!current&&!paused&&!deleting&&!DuplicateIndex.pending(type)
                        &&DuplicateIndex.prefs(this).getLong("time"+type,0)>0){
                    DuplicateIndex.focus(this,type,true);
                    trackNow();
                }
                if(current||!partial||!DuplicateIndex.pending(type)||!authorized){
                    partial=false;install(data);
                }
            });
            }catch(RuntimeException e){
                android.util.Log.e("DuplicatesPage","No se pudo leer la galería",e);
                runOnUiThread(()->{if(visible&&ticket==revision&&!isDestroyed())status.setText("No se pudo leer la galería. Vuelve a intentar el análisis.");});
            }
        });
    }
    private void install(List<DuplicateIndex.Family> data){
        families=data;all.clear();owner.clear();
        for(int i=0;i<data.size();i++){
            List<DuplicateIndex.Item> copies=data.get(i).items;
            for(DuplicateIndex.Item item:copies){all.add(item);owner.put(item.doc,i);}
            boolean keep=false;for(DuplicateIndex.Item item:copies)if(!selected.contains(item.doc)){keep=true;break;}
            if(!partial&&!keep)selected.remove(copies.get(0).doc);
        }
        if(!partial)selected.retainAll(owner.keySet());if(selected.isEmpty())reviewing=false;
        render();
    }
    private void render(){
        shown.clear();for(DuplicateIndex.Item item:all)if(!reviewing||selected.contains(item.doc))shown.add(item);
        adapter.notifyDataSetChanged();updateStatus();
    }
    private void bulk(){
        if(reviewing){reviewing=false;render();return;}
        if(selected.size()==all.size()-families.size())selected.clear();
        else for(DuplicateIndex.Family family:families)family.markCopies(selected);
        render();
    }
    private void mark(DuplicateIndex.Item item){
        if(deleting||partial)return;
        if(!families.get(owner.get(item.doc)).toggle(item,selected))toast("Desmarca otra copia del grupo para conservarla.");
        if(selected.isEmpty())reviewing=false;
        render();
    }
    private final class Adapter extends BaseAdapter{
        public int getCount(){return shown.size();}
        public DuplicateIndex.Item getItem(int i){return shown.get(i);}
        public long getItemId(int i){return i;}
        public android.view.View getView(int position,android.view.View recycled,android.view.ViewGroup parent){
            GalleryTile tile=recycled==null?new GalleryTile(DuplicatesPage.this):(GalleryTile)recycled;
            DuplicateIndex.Item item=getItem(position);
            tile.title.setText(item.name);
            int group=owner.get(item.doc);
            String volume=item.path.split(" / ",2)[0];
            tile.caption.setText(volume+"\nGrupo "+(group+1)+" · "+CacheScanner.size(item.size)+(partial?"":selected.contains(item.doc)?" · Borrar":" · Conservar"));
            tile.symbol.setText(kind==2?GalleryTile.format(item.name):kind==1?"▶":"Foto");
            if(item.kind<2)MediaPictures.bind(tile.picture,item.doc+"/"+item.mtime,()->MediaPictures.thumbnail(getApplicationContext(),item.uri,item.kind));
            else MediaPictures.clear(tile.picture);
            tile.mark.setChecked(selected.contains(item.doc));tile.mark.setEnabled(!deleting&&!partial);
            tile.mark.setContentDescription("Marcar "+item.name);tile.mark.setOnClickListener(v->mark(item));
            tile.setOnClickListener(v->{if(!deleting){if(viewer!=null)viewer.close();int current=shown.indexOf(item);if(current>=0)viewer=new GalleryViewer(DuplicatesPage.this,new ArrayList<>(shown),current);}});
            return tile;
        }
    }
    private void invalidateAccess(){
        allowedScope="";shownRun=null;partial=false;tabSelections.clear();selected.clear();
        install(Collections.emptyList());

    }
    private void restartScan(){if(deleting||!visible)return;DuplicateIndex.cancel();showType();}
    private void requestAccess(){
        if(requesting)return;
        if(kind==2 && Build.VERSION.SDK_INT>=30){
            Intent settings=new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,Uri.parse("package:"+getPackageName()));
            try{requesting=true;host.startActivityForResult(settings,44);}
            catch(ActivityNotFoundException e){
                try{host.startActivityForResult(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION),44);}
                catch(ActivityNotFoundException noSettings){requesting=false;toast("Abre Acceso especial → Acceso a todos los archivos en Ajustes.");}
            }
            return;
        }
        String primary=Build.VERSION.SDK_INT>=33?DeviceStorage.mediaPermission(kind):permission.READ_EXTERNAL_STORAGE;
        boolean asked=DuplicateIndex.prefs(this).getBoolean("asked"+kind,false);
        if(asked&&!DeviceStorage.allowed(this,kind)&&!host.shouldShowRequestPermissionRationale(primary)){
            requesting=true;
            host.startActivityForResult(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())),44);return;
        }
        List<String> permissions=new ArrayList<>();permissions.add(primary);
        if(Build.VERSION.SDK_INT>=34)permissions.add(permission.READ_MEDIA_VISUAL_USER_SELECTED);
        if(Build.VERSION.SDK_INT<30)permissions.add(permission.WRITE_EXTERNAL_STORAGE);
        DuplicateIndex.prefs(this).edit().putBoolean("asked"+kind,true).apply();requesting=true;
        host.requestPermissions(permissions.toArray(new String[0]),45);
    }
    void permissionResult(int code,String[] names,int[] values){
        
        if(code==45){requesting=false;paused=false;invalidateAccess();restartScan();}
    }
    void activityResult(int code,int result,Intent data){
        
        if(code==44){requesting=false;paused=false;invalidateAccess();restartScan();}
        if(code==46&&approvalSession!=0){
            long session=approvalSession;approvalSession=0;
            DuplicateIndex.worker.execute(()->{
                DuplicateIndex.resolveChunk(this,session,result==android.app.Activity.RESULT_OK);
                if(result==android.app.Activity.RESULT_OK)approval(session);else complete(DuplicateIndex.finishRemoval(this,session));
            });
        }
    }
    private void approval(long session){
        ArrayList<Uri> chunk=DuplicateIndex.nextApproval(this,session);
        if(chunk.isEmpty()){complete(DuplicateIndex.finishRemoval(this,session));return;}
        runOnUiThread(()->{
            if(!isDestroyed()&&!isFinishing()){
                try{
                    approvalSession=session;
                    host.startIntentSenderForResult(MediaStore.createDeleteRequest(getContentResolver(),chunk).getIntentSender(),46,null,0,0,0);
                    return;
                }catch(IntentSender.SendIntentException|RuntimeException e){approvalSession=0;}
            }
            DuplicateIndex.worker.execute(()->complete(DuplicateIndex.finishRemoval(this,session)));
        });
    }
    private void complete(String message){
        runOnUiThread(()->{
            if(isDestroyed())return;
            deleting=false;selected.clear();reviewing=false;toast(message);render();refresh();
        });
    }
    private void confirmBatch(){
        if(selected.isEmpty()||deleting)return;
        long bytes=0;for(DuplicateIndex.Item item:shown)bytes+=item.size;
        new AlertDialog.Builder(this).setTitle("Borrar "+selected.size()+" copias")
            .setMessage(CacheScanner.size(bytes)+" seleccionados. Se conservará al menos una copia por grupo.")
            .setNegativeButton("Cancelar",null).setPositiveButton("Borrar",(d,w)->{
                deleting=true;updateStatus();DuplicateIndex.cancel();++revision;
                List<DuplicateIndex.Family> batch=new ArrayList<>(families);
                Set<String> marked=new HashSet<>(selected);int type=kind;
                DuplicateIndex.worker.execute(()->{
                    try{
                        DuplicateIndex.Removal result=DuplicateIndex.remove(getApplicationContext(),batch,marked,type);
                        if(result.needsApproval){approval(result.session);return;}
                        complete(result.message);
                        if(result.originalUnavailable)runOnUiThread(()->explainOriginal());
                    }catch(RuntimeException e){complete("Revisa el resultado en Historial.");}
                });
            }).show();
    }
    @Override void back(){
        if(reviewing&&!deleting){reviewing=false;render();return;}
        super.back();
    }
    private void explainOriginal(){
        if(isDestroyed()||isFinishing())return;
        AlertDialog.Builder dialog=new AlertDialog.Builder(this).setTitle("Verificar los originales")
                .setMessage("Android no entregó los archivos originales para comparar todos sus bytes, incluidos los metadatos. Las copias sin verificar se conservaron.")
                .setNegativeButton("Cerrar",null);
        if(checkSelfPermission(permission.ACCESS_MEDIA_LOCATION)!=android.content.pm.PackageManager.PERMISSION_GRANTED)
            dialog.setPositiveButton("Permitir acceso",(d,w)->host.requestPermissions(new String[]{permission.ACCESS_MEDIA_LOCATION},47));
        dialog.show();
    }
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_SHORT).show();}
}
