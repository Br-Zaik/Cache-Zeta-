package com.zetacache.app;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import java.util.*;
import java.util.concurrent.*;

/** All journal operations run in submission order, independently of the accessibility/UI thread. */
final class CacheAudit {
    private static final ExecutorService io=Executors.newSingleThreadExecutor();
    private final Context context;
    private final List<AppTarget> clicked=new ArrayList<>();
    private long id; // Only accessed by io.

    CacheAudit(Context c,List<AppTarget> targets){
        context=c.getApplicationContext();
        List<AppTarget> initial=new ArrayList<>(targets);
        submit(()->{
            ResultsDb store=ResultsDb.get(context);
            SQLiteDatabase db=store.getWritableDatabase();
            db.beginTransaction();
            try{
                long session=store.begin("Caché de apps");
                for(AppTarget app:initial)store.detail(session,app.packageName,app.label,app.packageName,app.cacheBytes,-1,"Sin procesar");
                db.setTransactionSuccessful();id=session;
            }finally{db.endTransaction();}
        });
    }
    private void submit(Runnable task){
        io.execute(()->{
            try{task.run();}
            catch(android.database.SQLException e){Log.e("CacheAudit","No se pudo actualizar el historial",e);}
        });
    }
    void record(AppTarget app,boolean pressed){
        submit(()->{
            if(id==0)return;
            if(pressed)clicked.add(app);
            ResultsDb.get(context).detail(id,app.packageName,app.label,app.packageName,app.cacheBytes,-1,pressed?"Sin verificar":"Omitida");
        });
    }
    void close(boolean interrupted){
        CacheSnapshot.invalidate(context);
        submit(()->{
            if(id==0)return;
            ResultsDb store=ResultsDb.get(context);
            store.finish(id,interrupted?"Interrumpida":"Terminada");notifyHistory();
            if(clicked.isEmpty())return;
            List<AppTarget> measured=CacheScanner.measure(context,clicked,null);
            SQLiteDatabase db=store.getWritableDatabase();
            db.beginTransaction();
            try{
                for(AppTarget app:measured)store.measured(id,app);
                db.setTransactionSuccessful();
            }finally{db.endTransaction();}
            notifyHistory();
        });
    }
    private void notifyHistory(){
        context.sendBroadcast(new Intent("com.zetacache.app.HISTORY_CHANGED").setPackage(context.getPackageName()));
    }
}
