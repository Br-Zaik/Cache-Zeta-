package com.zetacache.app;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.graphics.drawable.ColorDrawable;
import java.util.Collections;
import android.view.ViewGroup;
import android.widget.*;
import java.util.List;
import java.util.concurrent.*;

final class HistoryPage extends ToolsPage {
    HistoryPage(MainActivity host){super(host);}
    private ListView list;
    private boolean listening;
    private TextView empty;
    private long session;
    private int overviewPosition,overviewOffset,limit=100;
    private volatile int ticket;
    private Button more;
    private final HistoryAdapter adapter=new HistoryAdapter();
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    @Override void create(Bundle state){
        super.create(state);
        if(state!=null){
            session=state.getLong("session");
            overviewPosition=state.getInt("overviewPosition");
            overviewOffset=state.getInt("overviewOffset");
        }
        FrameLayout content=new FrameLayout(this);
        body.addView(content,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f));
        list=new ListView(host);
        list.setDivider(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        list.setDividerHeight(dp(8));
        list.setPadding(0,dp(10),0,dp(12));
        list.setClipToPadding(false);
        list.setVerticalScrollBarEnabled(false);
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent,view,index,id)->{
            if(index<0||index>=adapter.getCount())return;
            ResultsDb.Row row=adapter.getItem(index);
            if(session==0 && row.sessionId>0){
                overviewPosition=list.getFirstVisiblePosition();
                overviewOffset=list.getChildCount()==0?0:list.getChildAt(0).getTop()-list.getPaddingTop();
                session=row.sessionId;
                showPage();
            }
        });
        content.addView(list,new FrameLayout.LayoutParams(-1,-1));
        empty=new TextView(this);empty.setGravity(Gravity.CENTER);empty.setTextColor(NeonStyle.MUTED);
        content.addView(empty,new FrameLayout.LayoutParams(-1,-1));
        list.setEmptyView(empty);
        more=button("Ver más");more.setVisibility(View.GONE);body.addView(more,-1,-2);
        more.setOnClickListener(v->{limit+=100;load();});

    }
    private final android.content.BroadcastReceiver updated=new android.content.BroadcastReceiver(){
        @Override public void onReceive(android.content.Context c,android.content.Intent i){load();}
    };
    @Override void enter(){
        if(listening)return;
        listening=true;
        android.content.IntentFilter f=new android.content.IntentFilter("com.zetacache.app.HISTORY_CHANGED");
        if(android.os.Build.VERSION.SDK_INT>=33)registerReceiver(updated,f,RECEIVER_NOT_EXPORTED);else registerReceiver(updated,f);
        load();
    }
    @Override void leave(){++ticket;if(listening){listening=false;unregisterReceiver(updated);}}
    private void load(){
        heading.setText(session==0?"Historial":"Detalle");
        final long id=session;final int version=++ticket,requested=limit;
        more.setEnabled(false);
        if(adapter.getCount()==0)empty.setText("Cargando historial…");
        worker.execute(()->{
            if(version!=ticket)return;
            List<ResultsDb.Row> rows;
            final boolean hasMore;
            try{
                rows=ResultsDb.get(this).history(id,requested+1);
                hasMore=rows.size()>requested;
                if(hasMore)rows.remove(rows.size()-1);
                if(id==0&&!hasMore){
                    String old=HistoryStore.get(this);
                    if(old!=null&&!old.startsWith("Sin limpiezas")){
                        for(String line:old.split("\n")){
                            if(!line.isEmpty())rows.add(new ResultsDb.Row(-1,"Registro anterior",line,"",-1,-1));
                        }
                    }
                }
            }
            catch(RuntimeException ex){
                android.util.Log.e("HistoryPage","Error al leer el historial",ex);
                runOnUiThread(()->{if(version==ticket&&!isDestroyed()){
                    empty.setText("No se pudo cargar el historial.");more.setText("Reintentar");
                    more.setVisibility(View.VISIBLE);more.setEnabled(true);
                    more.setOnClickListener(v->load());
                }});
                return;
            }
            runOnUiThread(()->{
                if(version!=ticket||isDestroyed())return;
                empty.setText(id==0?"Todavía no hay limpiezas.":"Sin elementos registrados.");
                more.setText("Ver más");more.setEnabled(true);more.setVisibility(hasMore?View.VISIBLE:View.GONE);
                more.setOnClickListener(v->{limit+=100;load();});
                boolean opening=adapter.rows.isEmpty()&&!rows.isEmpty();
                adapter.replace(rows);
                if(opening && id==0 && overviewPosition<rows.size())list.setSelectionFromTop(overviewPosition,overviewOffset);
            });
        });
    }
    private void showPage(){
        limit=100;more.setVisibility(View.GONE);
        adapter.replace(Collections.emptyList());
        empty.setText("");
        load();
    }
    private final class HistoryAdapter extends BaseAdapter {
        private List<ResultsDb.Row> rows=Collections.emptyList();
        void replace(List<ResultsDb.Row> next){rows=next;notifyDataSetChanged();}
        @Override public int getCount(){return rows.size();}
        @Override public ResultsDb.Row getItem(int position){return rows.get(position);}
        @Override public long getItemId(int position){return position;}
        @Override public boolean areAllItemsEnabled(){return false;}
        @Override public boolean isEnabled(int position){return position>=0&&position<rows.size()&&rows.get(position).sessionId>0;}
        @Override public View getView(int position,View recycled,ViewGroup parent){
            HistoryCard card=!(recycled instanceof HistoryCard)?new HistoryCard(host):(HistoryCard)recycled;
            card.bind(getItem(position));
            return card;
        }
    }
    @Override void save(Bundle b){
        super.save(b);b.putLong("session",session);
        b.putInt("overviewPosition",overviewPosition);b.putInt("overviewOffset",overviewOffset);
    }
    @Override void back(){if(session!=0){session=0;showPage();}else super.back();}
    @Override void dispose(){worker.shutdownNow();super.dispose();}
}
