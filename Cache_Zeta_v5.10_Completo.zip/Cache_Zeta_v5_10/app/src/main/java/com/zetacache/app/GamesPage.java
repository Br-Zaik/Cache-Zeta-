package com.zetacache.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowInsets;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.ProgressBar;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Panel de juegos: información, atajos y acceso a No molestar. Sin falsas promesas de FPS. */
final class GamesPage extends ToolsPage {
    GamesPage(MainActivity host){super(host);}
    private static final int BG = NeonStyle.BG;
    private static final int PANEL = NeonStyle.PANEL;
    private static final int TEXT = NeonStyle.TEXT;
    private static final int MUTED = NeonStyle.MUTED;
    private static final int MINT = NeonStyle.CYAN;
    private LinearLayout main, favorites;
    private TextView ramValue, batteryValue, tempValue, storageValue, lowMemoryValue, deviceValue;
    private ProgressBar ramMeter, storageMeter;
    private Button choose;
    private int favoriteGeneration;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private List<GameShortcuts.Launchable> cachedCandidates = new ArrayList<>();
    private boolean candidatesLoading = true;

    @Override void create(Bundle state) {
        super.create(state);
        heading.setText("Juegos");
        buildLayout();
        loadCandidates();
    }
    @Override void dispose() { worker.shutdownNow(); super.dispose(); }
    private void loadCandidates() {
        candidatesLoading=true;
        worker.execute(() -> {
            List<GameShortcuts.Launchable> list;
            try { list=GameShortcuts.candidates(getApplicationContext()); }
            catch(Exception e) { list=new ArrayList<>(); }
            final List<GameShortcuts.Launchable> result=list;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                cachedCandidates=result;
                candidatesLoading=false;
                updateFavorites();
            });
        });
    }
    @Override void enter() {
        
        updateReadings();
        updateFavorites();
    }

    private void buildLayout() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setPadding(0,0,0,dp(12));
        main=vertical();scroll.addView(main);body.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout library=vertical();
        GradientDrawable blue=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF313F65,0xFF222E46,0xFF202B3F});
        blue.setCornerRadius(dp(22));library.setBackground(blue);
        library.setPadding(dp(16),dp(16),dp(16),dp(16));
        LinearLayout head=horizontal();head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView pad=new ImageView(host);
        pad.setImageResource(R.drawable.ic_games);pad.setColorFilter(0xFFB6C9FF);
        head.addView(pad,dp(28),dp(28));
        TextView title=text("Mis juegos",21,TEXT,true);
        title.setPadding(dp(8),0,dp(4),0);
        head.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        choose=button("Elegir",NeonStyle.SELECTED,0xFFC6D5FF);
        choose.setMinWidth(dp(64));choose.setOnClickListener(v->selectGames());
        head.addView(choose,-2,-2);library.addView(head);
        favorites=vertical();addMargin(library,favorites,10);
        addMargin(main,library,6);

        LinearLayout deviceHeader=horizontal();deviceHeader.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout identity=vertical();identity.addView(text("Estado del teléfono",17,TEXT,true));
        deviceValue=text("",12,MUTED,false);identity.addView(deviceValue);
        deviceHeader.addView(identity,new LinearLayout.LayoutParams(0,-2,1));
        Button refresh=button("Actualizar",PANEL,MINT);refresh.setOnClickListener(v->updateReadings());
        deviceHeader.addView(refresh,-2,-2);addMargin(main,deviceHeader,18);

        LinearLayout capacity=horizontal();addMargin(main,capacity,10);
        LinearLayout ram=metricTile(capacity,"RAM libre",0xFF91B0FF,false);
        ramValue=reading(ram);ramMeter=meter(ram,0xFF91B0FF);
        LinearLayout storage=metricTile(capacity,"Espacio libre",0xFF8EDACF,true);
        storageValue=reading(storage);storageMeter=meter(storage,0xFF8EDACF);
        LinearLayout power=horizontal();addMargin(main,power,8);
        batteryValue=reading(metricTile(power,"Batería",0xFFA5DAB0,false));
        tempValue=reading(metricTile(power,"Temperatura",0xFFF4BD8E,true));
        lowMemoryValue=text("",12,0xFFF4BD8E,false);addMargin(main,lowMemoryValue,4);

        Button dnd=button("No molestar    ›",NeonStyle.PANEL,TEXT);
        dnd.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
        dnd.setOnClickListener(v->openDndSettings());addMargin(main,dnd,12);
    }
    private LinearLayout metricTile(LinearLayout row,String label,int accent,boolean second){
        LinearLayout tile=vertical();
        tile.setBaselineAligned(false);
        tile.setPadding(dp(13),dp(12),dp(13),dp(12));
        tile.setBackground(round(PANEL,16));
        LinearLayout.LayoutParams layout=new LinearLayout.LayoutParams(0,-1,1);
        if(second)layout.leftMargin=dp(8);
        row.addView(tile,layout);
        tile.addView(text(label,13,accent,true));
        return tile;
    }
    private TextView reading(LinearLayout tile){
        TextView value=text("—",22,TEXT,true);
        addMargin(tile,value,4);return value;
    }
    private ProgressBar meter(LinearLayout tile,int color){
        ProgressBar bar=new ProgressBar(host,null,android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);bar.setProgressTintList(ColorStateList.valueOf(color));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(6));lp.topMargin=dp(6);
        tile.addView(bar,lp);return bar;
    }
    private void capacity(TextView value,ProgressBar bar,long free,long total){
        value.setText(free>=0?GameInfo.formatGiB(free):"—");
        bar.setVisibility(free>=0&&total>0?View.VISIBLE:View.INVISIBLE);
        if(total>0)bar.setProgress((int)Math.round(free*100.0/total));
    }
    private void updateReadings() {
        worker.execute(()->{
            GameInfo info=GameInfo.read(getApplicationContext());
            runOnUiThread(()->{if(!isDestroyed())displayReadings(info);});
        });
    }
    private void displayReadings(GameInfo i){
        deviceValue.setText(android.os.Build.MANUFACTURER + " " + Build.MODEL
                + " · Android " + Build.VERSION.RELEASE);
        capacity(ramValue,ramMeter,i.ramAvailable,i.ramTotal);
        batteryValue.setText(i.batteryLabel());
        tempValue.setText(i.temperatureLabel());
        capacity(storageValue,storageMeter,i.storageAvailable,i.storageTotal);
        lowMemoryValue.setText("Memoria disponible baja");
        lowMemoryValue.setVisibility(i.memoryLow?View.VISIBLE:View.GONE);
    }

    private void updateFavorites() {
        int generation=++favoriteGeneration;
        favorites.removeAllViews();
        Set<String> saved=GameShortcuts.get(this);
        List<GameShortcuts.Launchable> installed=new ArrayList<>();
        for(GameShortcuts.Launchable game:cachedCandidates){
            if(saved.contains(game.packageName))installed.add(game);
        }
        choose.setText(installed.isEmpty()?"Elegir":"Editar");
        if(installed.isEmpty()){
            favorites.addView(text(candidatesLoading?"Cargando juegos…":"Elige tus juegos para abrirlos desde aquí.",14,0xFFBFCAE0,false));
            return;
        }
        LinearLayout row=null;
        ArrayList<ImageView> icons=new ArrayList<>();
        for(int i=0;i<installed.size();i++){
            if(i%3==0){row=horizontal();addMargin(favorites,row,4);}
            GameShortcuts.Launchable game=installed.get(i);
            LinearLayout tile=vertical();
            tile.setPadding(dp(4),dp(10),dp(4),dp(8));tile.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);
            tile.setBackground(NeonStyle.ripple(round(0xFF34435F,14)));
            tile.setFocusable(true);tile.setContentDescription("Abrir "+game.label);
            tile.setOnClickListener(v->launch(game.packageName));
            ImageView icon=new ImageView(host);
            icon.setImageResource(R.drawable.ic_games);icons.add(icon);tile.addView(icon,dp(40),dp(40));
            TextView name=text(game.label,12,TEXT,true);
            name.setGravity(Gravity.CENTER);name.setMaxLines(2);name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            addMargin(tile,name,6);
            LinearLayout.LayoutParams cell=new LinearLayout.LayoutParams(0,-1,1);cell.setMargins(dp(2),dp(2),dp(2),dp(2));row.addView(tile,cell);
        }
        int missing=(3-installed.size()%3)%3;
        for(int i=0;i<missing;i++)row.addView(new View(host),new LinearLayout.LayoutParams(0,1,1));
        worker.execute(()->{
            for(int i=0;i<installed.size();i++){
                final ImageView view=icons.get(i);
                try{
                    android.graphics.drawable.Drawable icon=getPackageManager().getApplicationIcon(installed.get(i).packageName);
                    runOnUiThread(()->{if(!isDestroyed()&&generation==favoriteGeneration)view.setImageDrawable(icon);});
                }catch(android.content.pm.PackageManager.NameNotFoundException ignored){}
            }
        });
    }

    private void launch(String packageName) {
        try {
            Intent intent=getPackageManager().getLaunchIntentForPackage(packageName);
            if(intent==null) { error("El juego ya no está disponible."); return; }
            startActivity(intent);
        } catch(Exception e) { error("No se pudo abrir esta aplicación."); }
    }

    private void selectGames() {
        if(candidatesLoading) { error("Se está preparando la lista de juegos."); return; }
        List<GameShortcuts.Launchable> list=cachedCandidates;
        if(list.isEmpty()) { error("No se encontraron aplicaciones que puedan abrirse."); return; }
        String[] names=new String[list.size()];
        boolean[] checks=new boolean[list.size()];
        Set<String> chosen = new HashSet<>(GameShortcuts.get(this));
        Set<String> installedPackages=new HashSet<>();
        for(GameShortcuts.Launchable app:list)installedPackages.add(app.packageName);
        chosen.retainAll(installedPackages);
        for(int n=0;n<list.size();n++) {
            GameShortcuts.Launchable app=list.get(n);
            names[n]=(app.isGame ? "🎮  " : "") + app.label;
            checks[n]=chosen.contains(app.packageName);
        }
        new AlertDialog.Builder(this)
                .setTitle("Elegir hasta 6 juegos")
                .setMultiChoiceItems(names,checks,(dialog,index,checked)-> {
                    String pkg=list.get(index).packageName;
                    if(checked) {
                        if(chosen.size()>=GameShortcuts.MAX_FAVORITES) {
                            ((AlertDialog)dialog).getListView().setItemChecked(index,false);
                            error("Puedes guardar hasta 6 juegos.");
                        } else chosen.add(pkg);
                    } else chosen.remove(pkg);
                })
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Guardar",(dialog,which)-> {
                    GameShortcuts.save(this,chosen);
                    updateFavorites();
                }).show();
    }

    private void openDndSettings() {
        // Las marcas cambian esta pantalla. Solo el usuario activa/desactiva No molestar.
        String[] actions={"android.settings.ZEN_MODE_SETTINGS", Settings.ACTION_SOUND_SETTINGS,
                Settings.ACTION_SETTINGS};
        for (String action:actions) {
            try { startActivity(new Intent(action)); return; }
            catch (Exception ignored) { }
        }
        error("No se pudieron abrir los ajustes de sonido.");
    }

    private void error(String message) {
        new AlertDialog.Builder(this).setMessage(message).setPositiveButton("Aceptar",null).show();
    }
    private TextView text(String msg,int sp,int color,boolean bold) {
        TextView x=new TextView(this);x.setText(msg);x.setTextSize(sp);x.setTextColor(color);
        if(bold)x.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return x;
    }
    private Button button(String msg,int color,int fg) {
        Button b=new Button(this);b.setText(msg);b.setTextSize(14);b.setTextColor(fg);
        b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setMinHeight(0);
        b.setPadding(dp(12),dp(13),dp(12),dp(13));b.setBackground(new RippleDrawable(
                ColorStateList.valueOf(0x35ffffff),round(color,14),null));return b;
    }
    private GradientDrawable round(int color,int r) {
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(r));return d;
    }
    private void addMargin(LinearLayout p,View child,int margin) {
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(margin);
        p.addView(child,lp);
    }
    private LinearLayout vertical() {LinearLayout a=new LinearLayout(this);a.setOrientation(1);return a;}
    private LinearLayout horizontal() {return new LinearLayout(this);}
    private int dp(float x) {return Math.round(x*getResources().getDisplayMetrics().density);}
}
