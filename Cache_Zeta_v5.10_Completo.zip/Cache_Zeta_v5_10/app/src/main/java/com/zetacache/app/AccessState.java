package com.zetacache.app;

import android.content.ComponentName;
import android.content.Context;
import android.provider.Settings;

final class AccessState {
    static boolean enabled(Context c){
        String setting=Settings.Secure.getString(c.getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if(setting==null)return false;
        ComponentName service=new ComponentName(c,CacheAccessibilityService.class);
        for(String raw:setting.split(":"))if(service.equals(ComponentName.unflattenFromString(raw)))return true;
        return false;
    }
    static String label(Context c){
        if(CacheAccessibilityService.instance()!=null)return "Activo";
        return enabled(c)?"Activado, sin conexión":"Desactivado";
    }
}
