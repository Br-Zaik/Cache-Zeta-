package com.zetacache.app;

import android.content.Context;
import android.graphics.Typeface;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.widget.TextView;

/** One lightweight text view per visible row, also for deleted media. */
final class HistoryCard extends TextView {
    private static final int MINT=0xFF94DCB7, CORAL=0xFFFFA0A4;

    HistoryCard(Context context){
        super(context);
        float density=getResources().getDisplayMetrics().density;
        int x=Math.round(16*density), y=Math.round(12*density);
        setPadding(x,y,x,y);
        setTextSize(14);
        setTextColor(NeonStyle.TEXT);
        setBackground(NeonStyle.card(context));
    }

    void bind(ResultsDb.Row row){
        SpannableStringBuilder text=new SpannableStringBuilder();
        int titleEnd=append(text,row.title,NeonStyle.TEXT);
        if(titleEnd>0){
            text.setSpan(new StyleSpan(Typeface.BOLD),0,titleEnd,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            text.setSpan(new RelativeSizeSpan(1.14f),0,titleEnd,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        if(!row.subtitle.isEmpty())append(text,"\n"+row.subtitle,NeonStyle.MUTED);
        if(row.sessionId>=0){
            append(text,"\nAntes  "+size(row.before),row.before>=0?MINT:NeonStyle.MUTED);
            append(text,"     Eliminado  "+size(row.removed),row.removed>0?CORAL:NeonStyle.MUTED);
        }
        if(!row.status.isEmpty())append(text,"\n"+row.status,NeonStyle.MUTED);
        setText(text);
    }
    private static String size(long bytes){
        return bytes<0?"—":bytes<1024?bytes+" B":CacheScanner.size(bytes);
    }
    private static int append(SpannableStringBuilder text,String part,int color){
        int start=text.length();text.append(part);
        if(text.length()>start)text.setSpan(new ForegroundColorSpan(color),start,text.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return text.length();
    }
}
