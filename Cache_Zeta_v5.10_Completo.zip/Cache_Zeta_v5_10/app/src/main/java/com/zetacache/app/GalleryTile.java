package com.zetacache.app;

import android.content.Context;
import android.view.Gravity;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.widget.*;

final class GalleryTile extends LinearLayout {
    final ImageView picture;
    final TextView symbol,title,caption;
    final CheckBox mark;
    GalleryTile(ToolsPage page){
        super(page);setOrientation(VERTICAL);setBackground(NeonStyle.solid(page,NeonStyle.PANEL,14,0));
        FrameLayout frame=new FrameLayout(page);addView(frame,-1,page.dp(104));
        symbol=new TextView(page);symbol.setGravity(Gravity.CENTER);symbol.setTextColor(NeonStyle.CYAN);
        symbol.setTextSize(19);frame.addView(symbol,-1,-1);
        picture=new ImageView(page);picture.setScaleType(ImageView.ScaleType.CENTER_CROP);frame.addView(picture,-1,-1);
        mark=new CheckBox(page);mark.setContentDescription("Marcar copia");mark.setFocusable(false);
        mark.setButtonTintList(android.content.res.ColorStateList.valueOf(0xFFBFD0FF));
        mark.setBackground(NeonStyle.solid(page,0xDC1D2639,10,0));
        frame.addView(mark,new FrameLayout.LayoutParams(page.dp(42),page.dp(42),Gravity.TOP|Gravity.END));
        title=new TextView(page);title.setSingleLine();title.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        title.setTextColor(NeonStyle.TEXT);title.setTextSize(14);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        title.setPadding(page.dp(8),page.dp(6),page.dp(8),0);addView(title,-1,-2);
        caption=new TextView(page);caption.setTextColor(NeonStyle.MUTED);caption.setTextSize(12);
        caption.setPadding(page.dp(8),0,page.dp(6),page.dp(7));addView(caption,-1,-2);
    }
    static String format(String name){int dot=name.lastIndexOf('.');String ext=dot<0?"":name.substring(dot+1);
        return ext.isEmpty()||ext.length()>8?"Archivo":ext.toUpperCase(java.util.Locale.ROOT);}
}
