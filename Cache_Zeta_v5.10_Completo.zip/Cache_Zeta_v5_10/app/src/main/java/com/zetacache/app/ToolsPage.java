package com.zetacache.app;

import android.os.Bundle;
import android.graphics.Typeface;
import android.widget.*;

abstract class ToolsPage extends android.content.ContextWrapper {
    final MainActivity host;
    LinearLayout body;
    TextView heading;
    ToolsPage(MainActivity host){super(host);this.host=host;}
    int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    void create(Bundle state){
        body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setBackgroundColor(NeonStyle.BG);
        body.setPadding(dp(16),dp(6),dp(16),dp(4));
        heading=new TextView(this);heading.setTextSize(22);heading.setTextColor(NeonStyle.TEXT);
        heading.setTypeface(null,Typeface.BOLD);heading.setGravity(android.view.Gravity.CENTER_VERTICAL);
        body.addView(heading,-1,dp(46));
    }
    void enter(){}
    void leave(){}
    void save(Bundle state){}
    void dispose(){}
    void back(){host.switchTab(0);}
    boolean isDestroyed(){return host.isDestroyed();}
    boolean isFinishing(){return host.isFinishing();}
    void runOnUiThread(Runnable r){host.runOnUiThread(r);}
    Button button(String text){
        Button b=new Button(this);b.setText(text);b.setTextSize(13);b.setAllCaps(false);b.setTextColor(NeonStyle.CYAN);
        b.setMinHeight(dp(44));b.setMinWidth(0);b.setPadding(dp(7),dp(3),dp(7),dp(3));
        b.setBackground(NeonStyle.ripple(NeonStyle.solid(this,NeonStyle.PANEL,11,0)));return b;
    }
    void action(LinearLayout row,Button button){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(2),dp(4),dp(2),dp(4));row.addView(button,lp);
    }
}
