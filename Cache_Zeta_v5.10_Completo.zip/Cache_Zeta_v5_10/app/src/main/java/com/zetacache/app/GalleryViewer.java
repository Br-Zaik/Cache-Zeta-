package com.zetacache.app;

import android.app.AlertDialog;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.List;

final class GalleryViewer {
    private final DuplicatesPage page;
    private final List<DuplicateIndex.Item> items;
    private final FrameLayout stage;
    private final TextView location;
    private final Button prev,next;
    private final AlertDialog dialog;
    private VideoView video;
    private ImageView photo;
    private int index;
    GalleryViewer(DuplicatesPage page,List<DuplicateIndex.Item> items,int position){
        this.page=page;this.items=items;
        LinearLayout body=new LinearLayout(page);body.setOrientation(LinearLayout.VERTICAL);
        stage=new FrameLayout(page);stage.setBackgroundColor(Color.BLACK);
        int height=Math.min(page.dp(340),page.getResources().getDisplayMetrics().heightPixels/2);
        body.addView(stage,-1,height);
        location=new TextView(page);location.setPadding(page.dp(12),page.dp(8),page.dp(12),0);body.addView(location);
        LinearLayout nav=new LinearLayout(page);body.addView(nav);
        prev=page.button("Anterior");next=page.button("Siguiente");page.action(nav,prev);page.action(nav,next);
        prev.setOnClickListener(v->display(index-1));next.setOnClickListener(v->display(index+1));
        dialog=new AlertDialog.Builder(page).setView(body).setPositiveButton("Cerrar",null).create();
        dialog.setOnDismissListener(d->release());dialog.show();display(position);
    }
    void close(){dialog.dismiss();release();}
    private void release(){
        if(video!=null){video.setOnPreparedListener(null);video.stopPlayback();video=null;}
        if(photo!=null){MediaPictures.clear(photo);photo=null;}
        stage.removeAllViews();
    }
    private void display(int position){
        release();index=position;DuplicateIndex.Item item=items.get(position);
        prev.setEnabled(position>0);next.setEnabled(position+1<items.size());
        location.setText(item.path+"\n"+CacheScanner.size(item.size));
        if(item.kind==1){
            VideoView player=new VideoView(page);video=player;
            stage.addView(player,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));
            MediaController controls=new MediaController(page);controls.setAnchorView(player);player.setMediaController(controls);
            player.setOnPreparedListener(mp->{if(video==player&&dialog.isShowing())player.start();});
            player.setVideoURI(item.uri);
        }else if(item.kind==0){
            photo=new ImageView(page);photo.setScaleType(ImageView.ScaleType.FIT_CENTER);stage.addView(photo,-1,-1);
            MediaPictures.bind(photo,"full/"+item.doc+"/"+item.mtime,()->MediaPictures.photo(page,item.uri));
        }else{
            TextView name=new TextView(page);name.setGravity(Gravity.CENTER);name.setTextColor(Color.WHITE);
            name.setText(item.name);stage.addView(name,-1,-1);
        }
    }
}
