# Privacidad de Caché Zeta

La app procesa los datos en el teléfono. Guarda localmente las mediciones de caché, las selecciones, los favoritos, el índice de duplicados y el historial.

Acceso a datos de uso permite medir la caché de las aplicaciones. La visibilidad de paquetes permite enumerar las apps. Accesibilidad se usa para la limpieza iniciada y confirmada por el usuario. El servicio busca el control «Borrar caché» en la pantalla de Ajustes de cada app.

Duplicados consulta las fotos y los videos autorizados en la galería de Android. Para otros archivos compartidos, en Android 11 o posterior puedes conceder «Acceso a todos los archivos» desde Ajustes. La app guarda localmente nombres, ubicaciones, tamaños y huellas SHA-256. Si Android oculta metadatos, la app puede pedir acceso a los originales para verificar que las copias son idénticas. La eliminación requiere seleccionar copias y confirmarlas. Puedes revocar los permisos en Ajustes de Android. Las sesiones anteriores permanecen en el historial. La app no solicita acceso a Internet.
