package com.zetacache.app;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CancellationException;

public class StorageWalkCheck {
    public static void main(String[] args)throws Exception {
        // The test runner owns and removes this temporary directory.
        Path root=Path.of(args[0]).resolve("storage");
        for(String name:Arrays.asList("Download/a.bin","Android/media/chat/b.bin","Android/data/secret.bin",
                "Android/obb/cache.bin","Android/sandbox/a.bin","Download/.trashed-123-a","Download/.pending-123-b")){
            Path path=root.resolve(name);
            Files.createDirectories(path.getParent());
            Files.write(path,new byte[]{1});
        }
        Files.createSymbolicLink(root.resolve("loop"),root);
        Files.createSymbolicLink(root.resolve("copy"),root.resolve("Download/a.bin"));
        Files.createFile(root.resolve("empty"));
        Set<String> found=new HashSet<>();
        int missed=StorageDocuments.walk(root.toFile(),()->false,file->found.add(root.relativize(file.toPath()).toString()));
        if(missed!=0||!found.equals(Set.of("Download/a.bin","Android/media/chat/b.bin")))throw new AssertionError(found);
        if(StorageDocuments.walk(root.resolve("missing").toFile(),()->false,file->{})!=1)throw new AssertionError("unmounted root");
        try{StorageDocuments.walk(root.toFile(),()->true,file->{});throw new AssertionError("cancel");}
        catch(CancellationException expected){}
        System.out.println("OK: búsqueda de archivos compartidos, ubicaciones privadas, enlaces y cancelación");
    }
}
