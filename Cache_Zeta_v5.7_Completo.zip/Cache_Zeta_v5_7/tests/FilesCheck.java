package com.zetacache.app;

import java.io.*;
import java.util.*;
import java.util.concurrent.CancellationException;

public class FilesCheck {
    static void ok(boolean condition,String name){if(!condition)throw new AssertionError(name);}
    static InputStream stream(byte[] data,int max){
        return new ByteArrayInputStream(data){
            public synchronized int read(byte[] b,int off,int len){return super.read(b,off,Math.min(len,max));}
        };
    }
    public static void main(String[] args)throws Exception{
        byte[] a=new byte[2000000];new Random(53).nextBytes(a);byte[] changed=a.clone();
        changed[changed.length-1]^=1;
        ok(IdenticalFiles.same(stream(a,27),stream(a,8192),a.length,()->false),"mismos bytes en bloques distintos");
        ok(!IdenticalFiles.same(stream(a,1024),stream(changed,12000),a.length,()->false),"último byte distinto");
        ok(!IdenticalFiles.same(stream(a,1024),stream(a,2048),a.length+1L,()->false),"tamaño obsoleto");
        ok(!IdenticalFiles.digest(stream(a,73),()->false).equals(IdenticalFiles.digest(stream(changed,65536),()->false)),"SHA-256");
        try{IdenticalFiles.digest(stream(a,512),()->true);throw new AssertionError("cancelación");}catch(CancellationException expected){}
        List<AppTarget> apps=Arrays.asList(new AppTarget("lo","lo",false,SelectionRules.MIN_BYTES-1),
            new AppTarget("eq","eq",false,SelectionRules.MIN_BYTES),new AppTarget("hi","hi",true,SelectionRules.MIN_BYTES+1),
            new AppTarget("unknown","unknown",false,-1));
        Set<String> picked=new HashSet<>(Arrays.asList("lo","eq","hi","unknown"));
        ok(SelectionRules.select(apps,true,0,0,picked,true).size()==2,"igual o mayor a 5 MB");
        ok(SelectionRules.select(apps,false,0,0,picked,true).size()==1,"solo usuario");
        ok(SelectionRules.select(apps,true,SelectionRules.MANUAL,1,picked,true).size()==2,"manual respeta marcas y mínimo");
        ok(SelectionRules.select(apps,true,SelectionRules.MANUAL,0,picked,false).isEmpty(),"medición obligatoria");
        System.out.println("OK: archivos idénticos, cambios, cancelación y límites de 5 MB");
    }
}
