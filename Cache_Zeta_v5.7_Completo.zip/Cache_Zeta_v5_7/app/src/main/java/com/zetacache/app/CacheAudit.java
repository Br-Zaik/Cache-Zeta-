package com.zetacache.app;

import android.content.Context;
import java.util.*;
import java.util.concurrent.*;

/** The service owns the journal so activity recreation does not discard a cleanup result. */
final class CacheAudit {
    private static final ExecutorService io=Executors.newSingleThreadExecutor();
    private final Context context;
    private final long id;
    private final List<AppTarget> clicked=new ArrayList<>();
    CacheAudit(Context c,List<AppTarget> targets){
        context=c.getApplicationContext();ResultsDb store=ResultsDb.get(c);id=store.begin("Caché de apps");
        store.getWritableDatabase().beginTransaction();
        try{
            for(AppTarget app:targets)store.detail(id,app.packageName,app.label,app.packageName,app.cacheBytes,-1,"Sin procesar");
            store.getWritableDatabase().setTransactionSuccessful();
        }finally{store.getWritableDatabase().endTransaction();}
    }
    void record(AppTarget app,boolean pressed){
        if(pressed)clicked.add(app);
        ResultsDb.get(context).detail(id,app.packageName,app.label,app.packageName,app.cacheBytes,-1,pressed?"Sin verificar":"Omitida");
    }
    void close(boolean interrupted){
        ResultsDb store=ResultsDb.get(context);store.finish(id,interrupted?"Interrumpida":"Terminada");
        CacheSnapshot.invalidate(context);
        List<AppTarget> targets=new ArrayList<>(clicked);
        if(targets.isEmpty())return;
        io.execute(()->{
            List<AppTarget> measured=CacheScanner.measure(context,targets,null);
            for(AppTarget app:measured)store.measured(id,app);
            context.sendBroadcast(new android.content.Intent("com.zetacache.app.HISTORY_CHANGED").setPackage(context.getPackageName()));
        });
    }
}
