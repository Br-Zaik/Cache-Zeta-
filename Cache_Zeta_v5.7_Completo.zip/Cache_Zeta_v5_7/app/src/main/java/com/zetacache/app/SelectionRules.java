package com.zetacache.app;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** Reglas puras y fáciles de probar; nunca confunden datos de usuario con caché. */
public final class SelectionRules {
    public static final long MIN_BYTES=5L*1024*1024;
    public static final int MOST_CACHE = 0;
    public static final int OVER_10 = 1;
    public static final int OVER_50 = 2;
    public static final int OVER_100 = 3;
    public static final int MANUAL = 4;
    private SelectionRules() {}

    public static List<AppTarget> select(List<AppTarget> all, boolean includeSystem,
                                         int filter, int maxCount, Set<String> manuallySelected,
                                         boolean measured) {
        ArrayList<AppTarget> result = new ArrayList<>();
        for (AppTarget app : all) {
            if (!includeSystem && app.system) continue;
            if (!measured || app.cacheBytes < threshold(filter)) continue;
            if (filter == MANUAL && (manuallySelected==null || !manuallySelected.contains(app.packageName))) continue;
            result.add(app);
        }
        result.sort((a, b) -> {
                int c = Long.compare(b.cacheBytes, a.cacheBytes);
                return c != 0 ? c : a.label.compareToIgnoreCase(b.label);
        });
        if (filter != MANUAL && maxCount > 0 && result.size() > maxCount)
            return new ArrayList<>(result.subList(0, maxCount));
        return result;
    }

    public static long threshold(int filter) {
        if (filter == OVER_10) return 10L * 1024L * 1024L;
        if (filter == OVER_50) return 50L * 1024L * 1024L;
        if (filter == OVER_100) return 100L * 1024L * 1024L;
        return MIN_BYTES;
    }

    public static long totalKnownCache(List<AppTarget> apps) {
        long sum = 0;
        for (AppTarget a : apps) if (a.cacheBytes > 0 && Long.MAX_VALUE - sum >= a.cacheBytes)
            sum += a.cacheBytes;
        return sum;
    }
}
