package com.zetacache.app;

import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryIteratorException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayDeque;
import java.util.function.Consumer;

final class StorageDocuments {
    /** Enumerate shared files with only one open directory at a time. */
    static int walk(File storage, IdenticalFiles.Cancel cancel, Consumer<File> visit) {
        Path root=storage.toPath();
        ArrayDeque<Path> directories=new ArrayDeque<>();
        directories.push(root);
        int missed=0;
        while(!directories.isEmpty()){
            IdenticalFiles.check(cancel);
            try(DirectoryStream<Path> entries=Files.newDirectoryStream(directories.pop())){
                for(Path entry:entries){
                    IdenticalFiles.check(cancel);
                    BasicFileAttributes attrs;
                    try{attrs=Files.readAttributes(entry,BasicFileAttributes.class,LinkOption.NOFOLLOW_LINKS);}
                    catch(IOException|SecurityException e){missed++;continue;}
                    if(attrs.isDirectory()){
                        String relative=root.relativize(entry).toString();
                        if(!relative.equalsIgnoreCase("Android/data")&&!relative.equalsIgnoreCase("Android/obb")
                                &&!relative.equalsIgnoreCase("Android/sandbox"))directories.push(entry);
                    }else if(attrs.isRegularFile()&&attrs.size()>0){
                        String name=entry.getFileName().toString();
                        if(!name.startsWith(".trashed-")&&!name.startsWith(".pending-"))visit.accept(entry.toFile());
                    }
                }
            }catch(IOException|DirectoryIteratorException|SecurityException e){missed++;}
        }
        return missed;
    }
}
