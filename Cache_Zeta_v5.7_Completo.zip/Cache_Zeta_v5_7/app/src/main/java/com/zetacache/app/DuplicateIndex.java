package com.zetacache.app;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.net.Uri;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Index of accessible mounted storage. One low-priority worker for all media types. */
final class DuplicateIndex {
    static final String[] TITLES={"Fotos","Videos","Archivos"};
    static final int ALL=-1;
    static final ExecutorService worker=Executors.newSingleThreadExecutor(r->new Thread(()->{
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);r.run();
    },"Indice local"));
    private static final AtomicInteger token=new AtomicInteger();
    static volatile boolean busy;
    static volatile String progress="";
    static final String EVENT="com.zetacache.app.INDEX_CHANGED";
    static synchronized void cancel(){token.incrementAndGet();}
    static SharedPreferences prefs(Context c){return c.getSharedPreferences("duplicate_index",Context.MODE_PRIVATE);}
    static final class Item {
        final String doc,name,path; final Uri uri;final long size,mtime;final int kind;
        Item(String id,Uri u,String n,String p,long s,long m,int k){doc=id;uri=u;name=n;path=p;size=s;mtime=m;kind=k;}
        @Override public String toString(){return name+"\n"+path;}
    }
    static final class Group {
        final String digest,name;final int count;final long bytes;
        Group(String d,String n,int c,long b){digest=d;name=n;count=c;bytes=b;}
        @Override public String toString(){return name+"\n"+count+" copias · "+CacheScanner.size(bytes)+" cada una";}
    }
    static int kind(String mime){
        if(mime!=null&&mime.startsWith("image/"))return 0;
        if(mime!=null&&mime.startsWith("video/"))return 1;return 2;
    }
    private static final int[] queued={-1,-1,-1};
    static synchronized void scan(Context context,int requested,boolean force){
        Context c=context.getApplicationContext();
        if(SessionState.running)return;
        int generation=token.get();
        for(int k=0;k<TITLES.length;k++){
            if((requested!=ALL&&requested!=k)||queued[k]==generation||!DeviceStorage.allowed(c,k))continue;
            final int type=k;queued[k]=generation;busy=true;
            worker.execute(()->{
                try{
                    IdenticalFiles.Cancel stop=()->generation!=token.get()||SessionState.running;
                    IdenticalFiles.check(stop);
                    String scope=DeviceStorage.scope(c,type);
                    if(scope.isEmpty())return;
                    if(!force && scope.equals(prefs(c).getString("scope"+type,"")) &&
                            CacheSnapshot.fresh(prefs(c).getLong("time"+type,0)))return;
                    progress="Buscando "+TITLES[type].toLowerCase(Locale.ROOT)+"…";
                    index(c,type,scope,stop);
                }catch(CancellationException e){progress="Análisis pausado";}
                catch(RuntimeException e){progress="No se pudo analizar "+TITLES[type].toLowerCase(Locale.ROOT);}
                finally{
                    synchronized(DuplicateIndex.class){
                        if(queued[type]==generation)queued[type]=-1;
                        busy=queued[0]>=0||queued[1]>=0||queued[2]>=0;
                    }
                    changed(c);
                }
            });
        }
    }
    private static void changed(Context c){c.sendBroadcast(new Intent(EVENT).setPackage(c.getPackageName()));}
    static void dirty(Context c){SharedPreferences.Editor e=prefs(c).edit();for(int i=0;i<3;i++)e.remove("time"+i);e.apply();}
    private static void index(Context c,int type,String scope,IdenticalFiles.Cancel cancel){
        // Stage directory entries on disk. Large galleries never require a Java object per photo.
        java.io.File stage=new java.io.File(c.getCacheDir(),"duplicate-scan-stage.db");
        SQLiteDatabase.deleteDatabase(stage);
        try(SQLiteDatabase scratch=SQLiteDatabase.openOrCreateDatabase(stage,null)){
            scratch.execSQL("CREATE TABLE files(kind INTEGER,doc TEXT PRIMARY KEY,uri TEXT,name TEXT,size INTEGER,mtime INTEGER,path TEXT)");
            int unread;
            scratch.beginTransaction();
            try(SQLiteStatement save=scratch.compileStatement("INSERT OR IGNORE INTO files VALUES(?,?,?,?,?,?,?)")){
                unread=DeviceStorage.enumerate(c,type,cancel,save);
                scratch.setTransactionSuccessful();
            }finally{scratch.endTransaction();}
            scratch.execSQL("CREATE INDEX sizes ON files(kind,size)");
            SQLiteDatabase db=ResultsDb.get(c).getWritableDatabase();
            boolean reuse=scope.equals(prefs(c).getString("scope"+type,""));
            String candidates="SELECT f.kind,f.doc,f.uri,f.name,f.size,f.mtime FROM files f JOIN "
                +"(SELECT kind,size FROM files GROUP BY kind,size HAVING COUNT(*)>1) g ON f.kind=g.kind AND f.size=g.size";
            // Keep a stable candidate cursor while recording computed hashes into a separate table.
            scratch.execSQL("CREATE TABLE verified(doc TEXT PRIMARY KEY,hash TEXT)");
            scratch.beginTransaction();
            try(Cursor q=scratch.rawQuery(candidates,null);
                SQLiteStatement save=scratch.compileStatement("INSERT INTO verified VALUES(?,?)")){
                while(q.moveToNext()){
                    IdenticalFiles.check(cancel);
                    int k=q.getInt(0);String id=q.getString(1);long size=q.getLong(4),mtime=q.getLong(5);
                    progress=TITLES[k]+" · "+q.getString(3);
                    String hash="";
                    if(reuse&&mtime>0)try(Cursor previous=db.rawQuery("SELECT digest FROM media WHERE kind=? AND doc=? AND size=? AND modified=?",
                            new String[]{""+k,id,""+size,""+mtime})){
                        if(previous.moveToFirst())hash=previous.getString(0);
                    }
                    if(hash.isEmpty()){
                        try(InputStream in=open(c.getContentResolver(),Uri.parse(q.getString(2)))){hash=IdenticalFiles.digest(in,cancel);}
                        catch(IOException|SecurityException|IllegalArgumentException e){unread++;continue;}
                    }
                    save.bindString(1,id);save.bindString(2,hash);save.executeInsert();
                }
                scratch.setTransactionSuccessful();
            } finally {scratch.endTransaction();}
            IdenticalFiles.check(cancel);
            db.beginTransaction();
            try(Cursor q=scratch.rawQuery("SELECT kind,f.doc,uri,name,size,mtime,v.hash,path FROM files f JOIN verified v ON v.doc=f.doc",null);
                SQLiteStatement insert=db.compileStatement("INSERT INTO media VALUES(?,?,?,?,?,?,?,?)")){
                db.delete("media","kind=?",new String[]{""+type});
                while(q.moveToNext()){
                    IdenticalFiles.check(cancel);String id=q.getString(1);
                    insert.bindLong(1,q.getInt(0));insert.bindString(2,id);insert.bindString(3,q.getString(2));
                    insert.bindString(4,q.getString(3));insert.bindString(5,q.getString(7));
                    insert.bindLong(6,q.getLong(4));insert.bindLong(7,q.getLong(5));insert.bindString(8,q.getString(6));
                    insert.executeInsert();
                }
                db.setTransactionSuccessful();
            } finally {db.endTransaction();}
            SharedPreferences.Editor editor=prefs(c).edit();long now=System.currentTimeMillis();
            editor.putString("scope"+type,scope).putLong("time"+type,now).putInt("unread"+type,unread);
            editor.apply();progress="Análisis completado";
        }finally{SQLiteDatabase.deleteDatabase(stage);}
    }
    static InputStream open(ContentResolver r,Uri uri)throws IOException{
        InputStream in=r.openInputStream(uri);if(in==null)throw new FileNotFoundException();return in;
    }
    static List<Group> groups(Context c,int kind){
        List<Group> groups=new ArrayList<>();
        try(Cursor q=ResultsDb.get(c).getReadableDatabase().rawQuery("SELECT digest,MIN(name),COUNT(*),size FROM media WHERE kind=? GROUP BY digest,size HAVING COUNT(*)>1 ORDER BY (COUNT(*)-1)*size DESC",new String[]{""+kind})){
            while(q.moveToNext())groups.add(new Group(q.getString(0),q.getString(1),q.getInt(2),q.getLong(3)));
        }
        return groups;
    }
    static List<Item> copies(Context c,int k,Group group){
        List<Item> items=new ArrayList<>();
        try(Cursor q=ResultsDb.get(c).getReadableDatabase().rawQuery("SELECT doc,uri,name,location,size,modified FROM media WHERE kind=? AND digest=? AND size=? ORDER BY location",
                new String[]{""+k,group.digest,""+group.bytes})){
            while(q.moveToNext())items.add(new Item(q.getString(0),Uri.parse(q.getString(1)),q.getString(2),q.getString(3),q.getLong(4),q.getLong(5),k));
        }
        return items;
    }
    private static InputStream original(Context c,Item item)throws IOException{
        Uri uri=item.uri;
        if(item.kind<2&&android.os.Build.VERSION.SDK_INT>=29)
            uri=android.provider.MediaStore.setRequireOriginal(uri);
        return open(c.getContentResolver(),uri);
    }
    static final class Removal {
        final ArrayList<Uri> approval=new ArrayList<>();
        long session;
        boolean originalUnavailable;
        String message="";
    }
    static Removal remove(Context c,List<Item> items,Set<String> selected){
        Removal result=new Removal();
        Item keep=null;
        for(Item item:items)if(!selected.contains(item.doc)){keep=item;break;}
        if(keep==null||selected.isEmpty())throw new IllegalArgumentException("Conserva al menos una copia.");
        ResultsDb db=ResultsDb.get(c);
        result.session=db.begin("Duplicados · "+TITLES[keep.kind]);
        for(Item item:items){
            if(!selected.contains(item.doc))continue;
            String state="Omitido";
            try{
                boolean equal;
                try(InputStream a=original(c,keep);InputStream b=original(c,item)){
                    equal=IdenticalFiles.same(a,b,item.size,()->false);
                }
                if(equal){
                    if(item.kind<2 && android.os.Build.VERSION.SDK_INT>=30){
                        result.approval.add(item.uri);state="Pendiente de confirmación";
                    }else{
                        boolean deleted;
                        if("file".equals(item.uri.getScheme())){
                            File file=new File(item.uri.getPath());
                            deleted=file.getAbsoluteFile().equals(file.getCanonicalFile()) && file.delete();
                            if(deleted)android.media.MediaScannerConnection.scanFile(c,new String[]{file.getPath()},null,null);
                        }else deleted=c.getContentResolver().delete(item.uri,null,null)>0;
                        if(deleted)state="Eliminado";
                    }
                }
            }catch(UnsupportedOperationException e){
                state="Original no disponible";result.originalUnavailable=true;
            }catch(IOException|RuntimeException ignored){}
            boolean deleted="Eliminado".equals(state);
            db.detail(result.session,item.doc,item.name,item.path,item.size,deleted?0:-1,state);
            if(deleted)db.getWritableDatabase().delete("media","doc=?",new String[]{item.doc});
        }
        if(result.approval.isEmpty())result.message=finishRemoval(c,result.session,false);
        return result;
    }
    static String finishRemoval(Context c,long session,boolean accepted){
        ResultsDb results=ResultsDb.get(c);
        SQLiteDatabase db=results.getWritableDatabase();
        int removed=0,skipped=0;
        db.beginTransaction();
        try(Cursor q=db.rawQuery("SELECT ref,state FROM details WHERE session=?",new String[]{""+session})){
            while(q.moveToNext()){
                String ref=q.getString(0),state=q.getString(1);
                if("Pendiente de confirmación".equals(state)){
                    boolean gone=false;
                    if(accepted){
                        Uri uri=Uri.parse(ref);
                        try{
                            if(android.provider.MediaStore.getExternalVolumeNames(c).contains(android.provider.MediaStore.getVolumeName(uri))){
                                try(Cursor current=c.getContentResolver().query(uri,new String[]{"_id"},null,null,null)){
                                    gone=current!=null&&!current.moveToFirst();
                                }
                            }
                        }catch(RuntimeException ignored){}
                    }
                    state=gone?"Eliminado":accepted?"Sin verificar":"Omitido";
                    db.execSQL("UPDATE details SET afterBytes=?,state=? WHERE session=? AND ref=?",
                            new Object[]{gone?0:-1,state,session,ref});
                    if(gone)db.delete("media","doc=?",new String[]{ref});
                }
                if("Eliminado".equals(state))removed++;else skipped++;
            }
            results.finish(session,skipped==0?"Terminada":"Revisar historial");db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        dirty(c);changed(c);
        return removed+" eliminados"+(skipped==0?"":" · "+skipped+" sin eliminar o verificar");
    }
}
