package com.zetacache.app;

import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Reused by the session list and its detail view. */
final class HistoryCard extends LinearLayout {
    private static final int MINT=0xFF94DCB7, CORAL=0xFFFFA0A4;
    private final TextView title,subtitle,state,before,removed;
    private final ImageView arrow;
    private final LinearLayout metrics;
    private final HistoryActivity page;

    HistoryCard(HistoryActivity page){
        super(page);
        this.page=page;
        setOrientation(VERTICAL);
        setPadding(dp(16),dp(13),dp(16),dp(13));
        setBackground(NeonStyle.card(page));

        LinearLayout header=new LinearLayout(page);
        header.setGravity(Gravity.CENTER_VERTICAL);
        addView(header,-1,-2);
        title=text(16,NeonStyle.TEXT,true);
        header.addView(title,new LayoutParams(0,-2,1));
        arrow=new ImageView(page);
        arrow.setImageResource(R.drawable.ic_arrow);
        arrow.setColorFilter(NeonStyle.MUTED);
        arrow.setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        header.addView(arrow,dp(18),dp(18));

        subtitle=text(13,NeonStyle.MUTED,false);
        subtitle.setPadding(0,dp(3),0,0);
        addView(subtitle,-1,-2);

        metrics=new LinearLayout(page);
        metrics.setPadding(0,dp(12),0,0);
        addView(metrics,-1,-2);
        before=metric("Antes");
        removed=metric("Eliminado");

        state=text(12,NeonStyle.MUTED,false);
        state.setPadding(0,dp(7),0,0);
        addView(state,-1,-2);
    }
    private int dp(int value){return page.dp(value);}
    private TextView text(int size,int color,boolean bold){
        TextView label=new TextView(page);
        label.setTextSize(size);
        label.setTextColor(color);
        label.setIncludeFontPadding(false);
        if(bold)label.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        return label;
    }
    private TextView metric(String caption){
        LinearLayout column=new LinearLayout(page);
        column.setOrientation(VERTICAL);
        metrics.addView(column,new LayoutParams(0,-2,1));
        TextView label=text(12,NeonStyle.MUTED,false);
        label.setText(caption);
        column.addView(label);
        TextView value=text(19,NeonStyle.TEXT,true);
        value.setFontFeatureSettings("tnum");
        value.setPadding(0,dp(2),0,0);
        column.addView(value);
        return value;
    }
    private void amount(TextView label,long bytes,int color){
        label.setText(bytes<0?"—":bytes<1024?bytes+" B":CacheScanner.size(bytes));
        label.setTextColor(bytes<0?NeonStyle.MUTED:color);
    }
    void bind(ResultsDb.Row row){
        title.setText(row.title);
        subtitle.setText(row.subtitle);
        subtitle.setVisibility(row.subtitle.isEmpty()?GONE:VISIBLE);
        arrow.setVisibility(row.sessionId>0?VISIBLE:GONE);
        metrics.setVisibility(row.sessionId<0?GONE:VISIBLE);
        amount(before,row.before,MINT);
        amount(removed,row.removed,row.removed>0?CORAL:NeonStyle.MUTED);
        state.setText(row.status);
        state.setVisibility(row.status.isEmpty()?GONE:VISIBLE);
    }
}
