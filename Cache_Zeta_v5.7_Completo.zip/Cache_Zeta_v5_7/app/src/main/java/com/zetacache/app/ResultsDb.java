package com.zetacache.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

final class ResultsDb extends SQLiteOpenHelper {
    private static ResultsDb instance;
    static synchronized ResultsDb get(Context context) {
        if (instance == null) instance = new ResultsDb(context.getApplicationContext());
        return instance;
    }
    private ResultsDb(Context context) {
        super(context, "cleaning_results.db", null, 2);
        setWriteAheadLoggingEnabled(true);
    }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE sessions(id INTEGER PRIMARY KEY,stamp INTEGER,kind TEXT,state TEXT)");
        db.execSQL("CREATE TABLE details(session INTEGER,ref TEXT,label TEXT,location TEXT,beforeBytes INTEGER,afterBytes INTEGER,state TEXT,PRIMARY KEY(session,ref))");
        db.execSQL("CREATE TABLE media(kind INTEGER,doc TEXT,uri TEXT,name TEXT,location TEXT,size INTEGER,modified INTEGER,digest TEXT,PRIMARY KEY(kind,doc))");
        db.execSQL("CREATE INDEX media_groups ON media(kind,digest,size)");
    }
    @Override public void onOpen(SQLiteDatabase db){
        super.onOpen(db);
        db.execSQL("UPDATE sessions SET state='Interrumpida' WHERE state='En curso'");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) {
        if(oldVersion<2)db.delete("media",null,null);
    }
    long begin(String kind) {
        ContentValues v=new ContentValues();
        v.put("stamp",System.currentTimeMillis()); v.put("kind",kind); v.put("state","En curso");
        return getWritableDatabase().insertOrThrow("sessions",null,v);
    }
    void finish(long id,String state) {
        getWritableDatabase().execSQL("UPDATE sessions SET state=? WHERE id=?",new Object[]{state,id});
    }
    void detail(long id,String ref,String label,String location,long before,long after,String state) {
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO details VALUES(?,?,?,?,?,?,?)",
                new Object[]{id,ref,label,location,before,after,state});
    }
    void measured(long id,AppTarget app) {
        getWritableDatabase().execSQL("UPDATE details SET afterBytes=?,state=? WHERE session=? AND ref=? AND state='Sin verificar'",
                new Object[]{app.cacheBytes,app.cacheBytes<0?"Sin verificar":"Medida",id,app.packageName});
    }
    static final class Row {
        final long sessionId, before, removed;
        final String title, subtitle, status;

        Row(long sessionId,String title,String subtitle,String status,long before,long removed){
            this.sessionId=sessionId;
            this.title=title;
            this.subtitle=subtitle;
            this.status=status;
            this.before=before;
            this.removed=removed;
        }
    }

    private static long amount(Cursor cursor,int column){
        return cursor.isNull(column)?-1:cursor.getLong(column);
    }

    List<Row> history(long session){
        List<Row> rows=new ArrayList<>();
        if(session==0){
            String query="SELECT s.id,s.stamp,s.kind,s.state,COUNT(d.ref),"
                    +"SUM(CASE WHEN d.beforeBytes>=0 THEN d.beforeBytes END),"
                    +"SUM(CASE WHEN d.beforeBytes>=0 AND d.afterBytes>=0 THEN MAX(0,d.beforeBytes-d.afterBytes) END),"
                    +"COUNT(CASE WHEN d.beforeBytes>=0 AND d.afterBytes>=0 THEN 1 END) "
                    +"FROM sessions s LEFT JOIN details d ON s.id=d.session GROUP BY s.id ORDER BY s.id DESC";
            java.text.DateFormat dates=java.text.DateFormat.getDateTimeInstance(
                    java.text.DateFormat.SHORT,java.text.DateFormat.SHORT);
            try(Cursor c=getReadableDatabase().rawQuery(query,null)){
                while(c.moveToNext()){
                    int count=c.getInt(4), verified=c.getInt(7);
                    String kind=c.getString(2),status=c.getString(3);
                    String unit=kind.equals("Caché de apps")?(count==1?" app":" apps"):
                            (count==1?" archivo":" archivos");
                    String when=dates.format(new java.util.Date(c.getLong(1)));
                    if("Terminada".equals(status)){
                        status=verified==count?"":verified==0?"Sin verificar":"Medición parcial";
                    }
                    rows.add(new Row(c.getLong(0),kind,when+"  ·  "+count+unit,status,amount(c,5),amount(c,6)));
                }
            }
        }else{
            String query="SELECT label,location,ref,beforeBytes,afterBytes,state FROM details WHERE session=? ORDER BY rowid";
            try(Cursor c=getReadableDatabase().rawQuery(query,new String[]{Long.toString(session)})){
                while(c.moveToNext()){
                    long before=amount(c,3),after=amount(c,4);
                    String place=c.getString(1),status=c.getString(5);
                    // An app's package ID repeats its identity. File paths distinguish individual copies.
                    String subtitle=place==null||place.equals(c.getString(2))?"":place;
                    if("Eliminado".equals(status)||"Medida".equals(status))status="";
                    long removed=before>=0 && after>=0?Math.max(0,before-after):-1;
                    rows.add(new Row(0,c.getString(0),subtitle,status,before,removed));
                }
            }
        }
        return rows;
    }
}
