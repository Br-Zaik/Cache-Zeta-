package com.zetacache.app;

import java.io.*;
import java.security.*;
import java.util.concurrent.CancellationException;

final class IdenticalFiles {
    interface Cancel {boolean requested();}
    private static final int BLOCK=64*1024;
    private static final char[] HEX="0123456789abcdef".toCharArray();
    static void check(Cancel cancel){if(cancel.requested()||Thread.currentThread().isInterrupted())throw new CancellationException();}
    static String digest(InputStream input,Cancel cancel) throws IOException {
        MessageDigest digest;
        try{digest=MessageDigest.getInstance("SHA-256");}catch(NoSuchAlgorithmException e){throw new AssertionError(e);}
        byte[] buffer=new byte[BLOCK];int n;
        while(true){check(cancel);n=input.read(buffer);if(n<0)break;if(n>0)digest.update(buffer,0,n);}
        byte[] result=digest.digest();StringBuilder value=new StringBuilder(64);
        for(byte b:result)value.append(HEX[(b&255)/16]).append(HEX[b&15]);
        return value.toString();
    }
    private static int block(InputStream stream,byte[] buffer,Cancel cancel)throws IOException{
        int count=0;
        while(count<buffer.length){check(cancel);int n=stream.read(buffer,count,buffer.length-count);if(n<0)break;if(n==0)throw new IOException("Lectura incompleta");count+=n;}
        return count;
    }
    static boolean same(InputStream first,InputStream second,long expected,Cancel cancel)throws IOException{
        byte[] a=new byte[BLOCK],b=new byte[BLOCK]; long total=0;
        while(true){int n=block(first,a,cancel),m=block(second,b,cancel);if(n!=m)return false;
            if(n==0)return total==expected;
            for(int i=0;i<n;i++)if(a[i]!=b[i])return false;
            total+=n;if(total>expected)return false;
        }
    }
}
