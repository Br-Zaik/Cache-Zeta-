package com.zetacache.app;

import android.app.AlertDialog;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.provider.Settings;
import android.Manifest.permission;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;

public final class DuplicatesActivity extends ToolsPage {
    private int kind,revision;
    private TextView status;
    private Button scan,access;
    private long approvalSession;
    private boolean requesting;
    private final BroadcastReceiver volumes=new BroadcastReceiver(){public void onReceive(Context c,Intent i){restartScan();}};
    private ListView list;
    private final Button[] tabs=new Button[3];
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService reader=Executors.newSingleThreadExecutor();
    private final Runnable tick=new Runnable(){public void run(){updateStatus();main.postDelayed(this,1000);}};
    private final BroadcastReceiver updated=new BroadcastReceiver(){public void onReceive(Context c,Intent i){refresh();}};
    private boolean deleting;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);kind=b==null?0:b.getInt("kind");heading.setText("Duplicados");
        if(b!=null){approvalSession=b.getLong("approval");requesting=b.getBoolean("requesting");deleting=approvalSession!=0;}
        LinearLayout types=new LinearLayout(this);body.addView(types);
        for(int i=0;i<tabs.length;i++){
            final int type=i;tabs[i]=button(DuplicateIndex.TITLES[i]);action(types,tabs[i]);
            tabs[i].setOnClickListener(v->{kind=type;showType();});
        }
        LinearLayout actions=new LinearLayout(this);body.addView(actions);
        access=button("Cambiar selección");action(actions,access);access.setOnClickListener(v->requestAccess());
        scan=button("Analizar");action(actions,scan);scan.setOnClickListener(v->{
            if(!DeviceStorage.allowed(this,kind)){requestAccess();return;}
            if(DuplicateIndex.busy)DuplicateIndex.cancel();else DuplicateIndex.scan(this,kind,true);
            updateStatus();
        });
        status=new TextView(this);status.setTextColor(NeonStyle.MUTED);status.setPadding(dp(6),dp(9),dp(6),dp(9));body.addView(status);
        list=new ListView(this);body.addView(list,-1,-1);
    }
    @Override protected void onStart(){
        super.onStart();IntentFilter f=new IntentFilter(DuplicateIndex.EVENT);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(updated,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(updated,f);
        IntentFilter mounts=new IntentFilter();mounts.addAction(Intent.ACTION_MEDIA_MOUNTED);mounts.addAction(Intent.ACTION_MEDIA_UNMOUNTED);
        mounts.addAction(Intent.ACTION_MEDIA_REMOVED);mounts.addDataScheme("file");
        if(Build.VERSION.SDK_INT>=33)registerReceiver(volumes,mounts,Context.RECEIVER_EXPORTED);else registerReceiver(volumes,mounts);
        if(Build.VERSION.SDK_INT>=34 && (DeviceStorage.partial(this,0)||DeviceStorage.partial(this,1))){
            DuplicateIndex.cancel();
            for(int k=0;k<2;k++)if(DeviceStorage.partial(this,k))DuplicateIndex.prefs(this).edit().remove("scope"+k).apply();
        }
        showType();main.post(tick);
    }
    @Override protected void onStop(){unregisterReceiver(volumes);unregisterReceiver(updated);main.removeCallbacks(tick);super.onStop();}
    @Override protected void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);b.putInt("kind",kind);b.putLong("approval",approvalSession);b.putBoolean("requesting",requesting);}
    @Override protected void onDestroy(){reader.shutdownNow();super.onDestroy();}
    private long stamp;
    private int unread,groups;
    private boolean authorized;
    private void updateStatus(){
        boolean limited=DeviceStorage.partial(this,kind);
        access.setVisibility(limited?android.view.View.VISIBLE:android.view.View.GONE);
        access.setEnabled(!deleting&&!requesting);
        scan.setEnabled(!deleting&&!requesting);
        scan.setText(!authorized?"Dar acceso":DuplicateIndex.busy?"Pausar":"Analizar "+DuplicateIndex.TITLES[kind].toLowerCase(Locale.ROOT));
        if(deleting)status.setText("Verificando las copias elegidas…");
        else if(!authorized)status.setText(kind==2&&Build.VERSION.SDK_INT>=30?
                "Permite el acceso a todos los archivos para buscar documentos en el teléfono y la SD.":
                "Permite el acceso para buscar duplicados automáticamente.");
        else if(DuplicateIndex.busy)status.setText(DuplicateIndex.progress.isEmpty()?"Preparando análisis…":DuplicateIndex.progress);
        else if(DuplicateIndex.progress.startsWith("No se pudo")||DuplicateIndex.progress.equals("Análisis pausado"))status.setText(DuplicateIndex.progress);
        else if(stamp==0)status.setText("Listo para analizar");
        else status.setText((groups==0?"Sin duplicados":groups+" grupos")+" · "+
                android.text.format.DateUtils.getRelativeTimeSpanString(stamp)+(limited?" · Solo selección permitida":"")+
                (unread>0?" · "+unread+" sin acceso":""));
    }
    private void showType(){
        authorized=DeviceStorage.allowed(this,kind);
        list.setAdapter(null);stamp=0;groups=0;updateStatus();
        if(!deleting){
            DuplicateIndex.scan(this,kind,false);
            DuplicateIndex.scan(this,DuplicateIndex.ALL,false);
        }
        refresh();
        if(!authorized&&!requesting&&!deleting&&kind<2 && !DuplicateIndex.prefs(this).getBoolean("asked"+kind,false))
            requestAccess();
    }
    private void refresh(){
        final int type=kind,ticket=++revision;
        for(int i=0;i<tabs.length;i++)tabs[i].setBackground(NeonStyle.ripple(NeonStyle.chip(this,i==type)));
        reader.execute(()->{
            String scope=DeviceStorage.scope(this,type);
            boolean current=!scope.isEmpty()&&scope.equals(DuplicateIndex.prefs(this).getString("scope"+type,""));
            List<DuplicateIndex.Group> items=current?DuplicateIndex.groups(this,type):Collections.emptyList();
            long when=current?DuplicateIndex.prefs(this).getLong("time"+type,0):0;
            runOnUiThread(()->{
                if(isDestroyed()||ticket!=revision)return;
                authorized=!scope.isEmpty();groups=items.size();stamp=when;
                unread=DuplicateIndex.prefs(this).getInt("unread"+type,0);updateStatus();
                list.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,items));
                list.setOnItemClickListener((p,v,i,id)->{if(!deleting)showCopies(type,items.get(i));});
            });
        });
    }
    private void invalidateAccess(){
        SharedPreferences.Editor edit=DuplicateIndex.prefs(this).edit();
        for(int k=0;k<3;k++)edit.remove("scope"+k);
        edit.apply();
    }
    private void restartScan(){DuplicateIndex.cancel();showType();}
    private void requestAccess(){
        if(requesting)return;
        if(kind==2 && Build.VERSION.SDK_INT>=30){
            Intent settings=new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,Uri.parse("package:"+getPackageName()));
            try{requesting=true;startActivityForResult(settings,44);}
            catch(ActivityNotFoundException e){
                try{startActivityForResult(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION),44);}
                catch(ActivityNotFoundException noSettings){requesting=false;toast("Abre Acceso especial → Acceso a todos los archivos en Ajustes.");}
            }
            return;
        }
        String primary=Build.VERSION.SDK_INT>=33?DeviceStorage.mediaPermission(kind):permission.READ_EXTERNAL_STORAGE;
        boolean asked=DuplicateIndex.prefs(this).getBoolean("asked"+kind,false);
        if(asked&&!DeviceStorage.allowed(this,kind)&&!shouldShowRequestPermissionRationale(primary)){
            requesting=true;
            startActivityForResult(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())),44);return;
        }
        List<String> permissions=new ArrayList<>();permissions.add(primary);
        if(Build.VERSION.SDK_INT>=34)permissions.add(permission.READ_MEDIA_VISUAL_USER_SELECTED);
        if(Build.VERSION.SDK_INT<30)permissions.add(permission.WRITE_EXTERNAL_STORAGE);
        DuplicateIndex.prefs(this).edit().putBoolean("asked"+kind,true).apply();requesting=true;
        requestPermissions(permissions.toArray(new String[0]),45);
    }
    @Override public void onRequestPermissionsResult(int code,String[] names,int[] values){
        super.onRequestPermissionsResult(code,names,values);
        if(code==45){requesting=false;invalidateAccess();restartScan();}
    }
    @Override protected void onActivityResult(int code,int result,Intent data){
        super.onActivityResult(code,result,data);
        if(code==44){requesting=false;invalidateAccess();restartScan();}
        if(code==46&&approvalSession!=0){
            long session=approvalSession;approvalSession=0;
            DuplicateIndex.worker.execute(()->complete(DuplicateIndex.finishRemoval(getApplicationContext(),session,result==RESULT_OK)));
        }
    }
    private void complete(String message){
        runOnUiThread(()->{if(!isDestroyed()){deleting=false;toast(message);DuplicateIndex.scan(this,DuplicateIndex.ALL,false);refresh();}});
    }
    private void showCopies(int type,DuplicateIndex.Group group){
        reader.execute(()->{
            List<DuplicateIndex.Item> copies=DuplicateIndex.copies(this,type,group);
            runOnUiThread(()->{
                if(isFinishing()||isDestroyed()||kind!=type)return;
                if(copies.size()<2){refresh();return;}
                String[] names=new String[copies.size()];boolean[] marked=new boolean[names.length];
                Set<String> selected=new HashSet<>();
                for(int i=0;i<names.length;i++)names[i]=copies.get(i).toString();
                AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Elige las copias que borrarás")
                    .setMultiChoiceItems(names,marked,(d,i,on)->{
                        String doc=copies.get(i).doc;
                        if(on&&Build.VERSION.SDK_INT>=30&&type<2&&selected.size()>=2000){((AlertDialog)d).getListView().setItemChecked(i,false);toast("Confirma este lote antes de seleccionar más copias.");}
                        else if(on&&selected.size()==copies.size()-1){((AlertDialog)d).getListView().setItemChecked(i,false);toast("Conserva al menos una copia.");}
                        else if(on)selected.add(doc);else selected.remove(doc);
                        ((AlertDialog)d).getButton(-1).setEnabled(!selected.isEmpty());
                    }).setNegativeButton("Cerrar",null).setPositiveButton("Revisar",(d,i)->confirm(copies,selected)).create();
                dialog.show();dialog.getButton(-1).setEnabled(false);
            });
        });
    }
    private void confirm(List<DuplicateIndex.Item> copies,Set<String> selected){
        if(selected.isEmpty()||selected.size()>=copies.size())return;
        StringBuilder message=new StringBuilder("Eliminar definitivamente:\n");
        for(DuplicateIndex.Item item:copies)if(selected.contains(item.doc))message.append("\n").append(item.path);
        new AlertDialog.Builder(this).setTitle("Eliminar "+selected.size()+" copias").setMessage(message)
            .setNegativeButton("Cancelar",null).setPositiveButton("Eliminar",(d,i)->{
                deleting=true;updateStatus();Context c=getApplicationContext();
                DuplicateIndex.cancel();
                DuplicateIndex.worker.execute(()->{
                    try{
                        DuplicateIndex.Removal result=DuplicateIndex.remove(c,copies,selected);
                        if(result.approval.isEmpty()){
                            complete(result.message);
                            if(result.originalUnavailable&&Build.VERSION.SDK_INT>=29)
                                runOnUiThread(()->explainOriginal());
                            return;
                        }
                        runOnUiThread(()->{
                            if(!isFinishing()&&!isDestroyed()){
                                try{
                                    approvalSession=result.session;
                                    startIntentSenderForResult(MediaStore.createDeleteRequest(getContentResolver(),result.approval)
                                            .getIntentSender(),46,null,0,0,0);return;
                                }catch(IntentSender.SendIntentException|RuntimeException ex){approvalSession=0;}
                            }
                            DuplicateIndex.worker.execute(()->complete(DuplicateIndex.finishRemoval(c,result.session,false)));
                        });
                    }catch(RuntimeException e){complete("No se pudo completar. Revisa el historial.");}
                });
            }).show();
    }
    private void explainOriginal(){
        if(isDestroyed()||isFinishing())return;
        AlertDialog.Builder dialog=new AlertDialog.Builder(this).setTitle("Verificar los originales")
                .setMessage("Android no entregó los archivos originales para comparar todos sus bytes, incluidos los metadatos. Las copias sin verificar se conservaron.")
                .setNegativeButton("Cerrar",null);
        if(checkSelfPermission(permission.ACCESS_MEDIA_LOCATION)!=android.content.pm.PackageManager.PERMISSION_GRANTED)
            dialog.setPositiveButton("Permitir acceso",(d,w)->requestPermissions(new String[]{permission.ACCESS_MEDIA_LOCATION},47));
        dialog.show();
    }
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_SHORT).show();}
}
