package com.zetacache.app;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

/** Track genuine entries into the app separately from navigation between its activities. */
public final class ZetaApplication extends Application implements Application.ActivityLifecycleCallbacks {
    private int visible;
    private boolean scanOnReturn;
    private long entry;
    long currentEntry(){return entry;}

    void startAuthorizedScans(){
        if(!scanOnReturn||visible==0||SessionState.running)return;
        scanOnReturn=false;
        DuplicateIndex.scan(this,DuplicateIndex.ALL,true);
    }

    private final Handler main=new Handler(Looper.getMainLooper());
    private final Runnable pauseScan=()->{if(visible==0)DuplicateIndex.cancel();};
    @Override public void onCreate(){super.onCreate();registerActivityLifecycleCallbacks(this);}
    @Override public void onActivityStarted(Activity activity){main.removeCallbacks(pauseScan);
        if(visible++==0){
            entry++;scanOnReturn=true;
            startAuthorizedScans();
        }}
    @Override public void onActivityStopped(Activity activity){if(--visible==0)main.postDelayed(pauseScan,10000);}
    @Override public void onActivityCreated(Activity activity,Bundle state){}
    @Override public void onActivityResumed(Activity activity){}
    @Override public void onActivityPaused(Activity activity){}
    @Override public void onActivitySaveInstanceState(Activity activity,Bundle state){}
    @Override public void onActivityDestroyed(Activity activity){}
}
