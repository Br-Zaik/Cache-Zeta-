package com.zetacache.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Resúmenes locales, sin analítica ni red. */
public final class HistoryStore {
    private HistoryStore() {}
    private static final String PREFS = "cache_zeta_history";

    public static void add(Context context, boolean cancelled, int clicked, int skipped) {
        SharedPreferences pref = context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
        String date = new SimpleDateFormat("dd/MM HH:mm",Locale.getDefault()).format(new Date());
        String entry = date + " · " + (cancelled ? "Interrumpida" : "Terminada")
                + " · Pulsaciones " + clicked + " · Omitidas " + skipped;
        String old = pref.getString("items", "");
        String[] lines = old.split("\\n");
        StringBuilder out = new StringBuilder(entry);
        for (int i = 0; i < Math.min(7, lines.length); i++) {
            if (!lines[i].isEmpty()) out.append('\n').append(lines[i]);
        }
        pref.edit().putString("items", out.toString()).apply();
    }

    public static String get(Context context) {
        return context.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
                .getString("items", "Sin limpiezas registradas.");
    }
}
