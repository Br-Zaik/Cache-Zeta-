package com.zetacache.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Pantalla nativa Lite: sin librerías, sin Internet, sin cargas en el hilo UI. */
public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(10, 16, 32);
    private static final int PANEL = Color.rgb(21, 32, 51);
    private static final int TEXT = Color.rgb(244, 248, 255);
    private static final int MUTED = Color.rgb(161, 178, 199);
    private static final int MINT = Color.rgb(84, 241, 203);
    private static final String PREF = "cache_zeta_lite_v3";
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final List<AppTarget> apps = new ArrayList<>();
    private final Set<String> picked = new HashSet<>();
    private final Set<String> excluded = new HashSet<>();
    private boolean systemApps = false, measured = false, scanning = false, loading = false;
    private boolean awaitingUsage = false, verifyAfter = false, verifying = false;
    private int filter = SelectionRules.MOST_CACHE, limit = 10, scanVersion = 0;
    private boolean scanAttempted = false;
    private String previewSignature = "";
    private List<AppTarget> lastStarted = new ArrayList<>();
    private TextView count, permissionText, analysisText, filterText, selectedInfo, previewText, resultText, progressText;
    private Button scanBtn, usageBtn, accessBtn, cleanBtn, resumeBtn, stopBtn;
    private TextView allChip, userChip;
    private LinearLayout previewRows, limitChips;
    private final Runnable pulse = new Runnable() {
        @Override public void run() { refresh(); ui.postDelayed(this, 750); }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
        excluded.addAll(prefs().getStringSet("excluded", new HashSet<>()));
        picked.addAll(prefs().getStringSet("picked", new HashSet<>()));
        systemApps = prefs().getBoolean("system", false);
        filter = prefs().getInt("filter", SelectionRules.MOST_CACHE);
        limit = prefs().getInt("limit", 10);
        createLayout();
        loadApps();
    }

    @Override protected void onResume() {
        super.onResume();
        ui.removeCallbacks(pulse);
        ui.post(pulse);
        if (!SessionState.running && verifyAfter && !verifying) verifyResults();
        if (!SessionState.running && !scanning && !loading && CacheScanner.hasUsageAccess(this)
                && (!scanAttempted || awaitingUsage)) {
            awaitingUsage = false;
            analyze();
        }
    }
    @Override protected void onPause() { ui.removeCallbacks(pulse); super.onPause(); }
    @Override protected void onDestroy() { worker.shutdownNow(); ui.removeCallbacksAndMessages(null); super.onDestroy(); }
    private SharedPreferences prefs() { return getSharedPreferences(PREF, MODE_PRIVATE); }

    private void loadApps() {
        if (loading) return;
        loading = true;
        worker.execute(() -> {
            List<AppTarget> found;
            try { found = CacheScanner.installed(getApplicationContext()); }
            catch (Exception e) { found = new ArrayList<>(); }
            final List<AppTarget> result = found;
            ui.post(() -> {
                apps.clear(); apps.addAll(result);
                loading = false; measured = false; scanAttempted = false;
                previewSignature = "";
                refresh();
                if (CacheScanner.hasUsageAccess(this) && !SessionState.running) analyze();
            });
        });
    }

    private void analyze() {
        if (scanning || SessionState.running || loading) return;
        if (!CacheScanner.hasUsageAccess(this)) { requestUsage(); return; }
        scanning = true;
        scanAttempted = true;
        int version = ++scanVersion;
        final List<AppTarget> snapshot = new ArrayList<>(apps);
        analysisText.setText("Analizando 0/" + snapshot.size() + "…");
        refresh();
        worker.execute(() -> {
            List<AppTarget> result = CacheScanner.measure(getApplicationContext(), snapshot,
                    (done, total) -> ui.post(() -> {
                        if (version == scanVersion) analysisText.setText("Analizando " + done + "/" + total + "…");
                    }));
            ui.post(() -> {
                if (version != scanVersion || isFinishing()) return;
                apps.clear(); apps.addAll(result);
                scanning = false;
                int known = 0;
                for (AppTarget item : result) if (item.cacheBytes >= 0) known++;
                measured = CacheScanner.hasUsageAccess(this) && result.size() == snapshot.size() && known > 0;
                previewSignature = "";
                analysisText.setText(measured ? "Análisis listo · "+known+" apps con medida" :
                        "Android no devolvió tamaños de caché. Puedes usar selección manual.");
                refresh();
            });
        });
    }

    private List<AppTarget> scoped() {
        ArrayList<AppTarget> output = new ArrayList<>();
        for (AppTarget a : apps) if ((systemApps || !a.system) && !excluded.contains(a.packageName)) output.add(a);
        return output;
    }
    private List<AppTarget> selected() {
        return SelectionRules.select(scoped(), true, filter, limit, picked, measured);
    }

    private void createLayout() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        scroll.setVerticalScrollBarEnabled(false);
        int margin = dp(19);
        scroll.setPadding(margin, dp(12), margin, dp(32));
        scroll.setOnApplyWindowInsetsListener((v, inset) -> {
            int t = 0, b = 0;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets s = inset.getInsets(WindowInsets.Type.systemBars());
                t = s.top; b = s.bottom;
            } else { t = inset.getSystemWindowInsetTop(); b = inset.getSystemWindowInsetBottom(); }
            v.setPadding(margin, t + dp(12), margin, b + dp(32));
            return inset;
        });
        LinearLayout main = vertical(); scroll.addView(main); setContentView(scroll);

        LinearLayout header = horizontal(); header.setGravity(Gravity.CENTER_VERTICAL);
        ImageView icon = new ImageView(this); icon.setImageResource(com.zetacache.app.R.drawable.ic_brand);
        icon.setBackground(round(PANEL, 17)); icon.setPadding(dp(8),dp(8),dp(8),dp(8));
        header.addView(icon, new LinearLayout.LayoutParams(dp(62), dp(62)));
        LinearLayout title = vertical(); title.setPadding(dp(11),0,0,0);
        title.addView(text("CACHÉ ZETA", 21, TEXT, true));
        title.addView(text("v4 LITE · Limpieza + juegos", 12, MINT, false));
        header.addView(title); main.addView(header);

        Button games = button("🎮  JUEGOS · RAM Y BATERÍA", PANEL, MINT);
        games.setOnClickListener(v -> startActivity(new Intent(this, GameActivity.class)));
        addMargin(main,games,15);

        LinearLayout hero = vertical(); hero.setPadding(dp(19),dp(18),dp(19),dp(18));
        hero.setBackground(gradient(Color.rgb(24,63,80),Color.rgb(18,34,56),22));
        addMargin(main, hero, 19);
        hero.addView(text("SOLO CACHÉ · SIN BORRAR TUS DATOS", 11, MINT, true));
        TextView heroTitle = text("Libera espacio.\nSin complicaciones.", 24, TEXT, true);
        addMargin(hero, heroTitle, 9);
        hero.addView(text("Elige qué limpiar y pulsa un botón.", 13, MUTED, false));

        count = text("Buscando aplicaciones…", 14, TEXT, true);
        addMargin(main,count,18);
        permissionText = text("", 12, MUTED, false); main.addView(permissionText);
        addMargin(main, text("1 · Aplicaciones", 16, TEXT, true), 22);
        LinearLayout scopes = horizontal();
        allChip = text("Todas las apps",13,TEXT,true);
        userChip = text("Instaladas por mí",13,TEXT,true);
        addWeight(scopes, allChip, 1, 0); addWeight(scopes, userChip, 1, 8);
        addMargin(main,scopes,10);
        allChip.setOnClickListener(v -> { systemApps=true; prefs().edit().putBoolean("system",true).apply(); refresh(); });
        userChip.setOnClickListener(v -> { systemApps=false; prefs().edit().putBoolean("system",false).apply(); refresh(); });

        addMargin(main, text("2 · Filtro", 16, TEXT, true), 21);
        LinearLayout filterLine = horizontal(); filterLine.setGravity(Gravity.CENTER_VERTICAL);
        filterText = text("Más caché primero",14,TEXT,true);
        filterText.setPadding(dp(14),dp(13),dp(14),dp(13));
        filterText.setBackground(ripple(PANEL,13));
        filterLine.addView(filterText, new LinearLayout.LayoutParams(0,-2,1f));
        filterText.setOnClickListener(v -> showFilters());
        TextView arrow = text("⌄",22,MINT,true); arrow.setGravity(Gravity.CENTER);
        filterLine.addView(arrow,new LinearLayout.LayoutParams(dp(32),-1));
        addMargin(main,filterLine,10);

        addMargin(main,text("3 · Cantidad",16,TEXT,true),20);
        HorizontalScrollView limitsScroll = new HorizontalScrollView(this);
        limitsScroll.setHorizontalScrollBarEnabled(false);
        limitChips = horizontal(); limitsScroll.addView(limitChips);
        addMargin(main,limitsScroll,9);
        createLimits();

        LinearLayout actions = horizontal();
        scanBtn = button("ANALIZAR",PANEL,MINT); scanBtn.setOnClickListener(v -> analyze());
        usageBtn = button("PERMISO MB",PANEL,MINT); usageBtn.setOnClickListener(v -> requestUsage());
        addWeight(actions,scanBtn,1,0); addWeight(actions,usageBtn,1,8);
        addMargin(main,actions,20);
        analysisText = text("",12,MUTED,false); addMargin(main,analysisText,10);

        LinearLayout choices = horizontal();
        TextView pick = text("Elegir apps",13,MINT,true); pick.setGravity(Gravity.CENTER);
        pick.setPadding(dp(11),dp(12),dp(11),dp(12)); pick.setBackground(ripple(PANEL,13));
        pick.setOnClickListener(v -> chooseApps());
        TextView exclude = text("Excluir apps",13,MUTED,true); exclude.setGravity(Gravity.CENTER);
        exclude.setPadding(dp(11),dp(12),dp(11),dp(12)); exclude.setBackground(ripple(PANEL,13));
        exclude.setOnClickListener(v -> chooseExclusions());
        addWeight(choices,pick,1,0); addWeight(choices,exclude,1,8);
        addMargin(main,choices,10);

        LinearLayout list = vertical(); list.setBackground(round(PANEL,17));
        list.setPadding(dp(14),dp(13),dp(14),dp(14));
        selectedInfo = text("",14,TEXT,true); list.addView(selectedInfo);
        previewText = text("",12,MUTED,false); addMargin(list,previewText,5);
        previewRows = vertical(); addMargin(list,previewRows,8);
        addMargin(main,list,18);

        cleanBtn = button("✦  LIMPIAR CACHÉ",MINT,BG);
        cleanBtn.setTextSize(17); cleanBtn.setPadding(dp(15),dp(16),dp(15),dp(16));
        addMargin(main,cleanBtn,16);
        cleanBtn.setOnClickListener(v -> startCleaning(false));

        accessBtn = button("Activar Accesibilidad",PANEL,MINT);
        accessBtn.setOnClickListener(v -> requestAccessibility());
        addMargin(main,accessBtn,9);

        LinearLayout statusBox = vertical(); statusBox.setBackground(round(PANEL,17));
        statusBox.setPadding(dp(15),dp(14),dp(15),dp(14));
        statusBox.addView(text("ESTADO",11,MINT,true));
        progressText = text("Listo",15,TEXT,true); addMargin(statusBox,progressText,6);
        resultText = text("",13,MUTED,false); addMargin(statusBox,resultText,5);
        resumeBtn = button("REANUDAR",PANEL,MINT);
        resumeBtn.setOnClickListener(v -> startCleaning(true));
        addMargin(statusBox,resumeBtn,9);
        stopBtn = button("DETENER",Color.rgb(94,43,57),TEXT);
        stopBtn.setOnClickListener(v -> {
            CacheAccessibilityService service = CacheAccessibilityService.instance();
            if (service != null) service.cancel();
        });
        addMargin(statusBox,stopBtn,7);
        addMargin(main,statusBox,15);
        TextView history = text("Ver historial de limpiezas",12,MINT,true);
        history.setGravity(Gravity.CENTER);
        history.setPadding(dp(10),dp(12),dp(10),dp(12));
        history.setOnClickListener(v->new AlertDialog.Builder(this)
                .setTitle("Historial local")
                .setMessage(HistoryStore.get(this))
                .setPositiveButton("Cerrar",null).show());
        addMargin(main,history,8);
        TextView footer = text("Android 8+ · Sin root · Sin anuncios · Sin Internet",11,MUTED,false);
        footer.setGravity(Gravity.CENTER); addMargin(main,footer,22);
        refresh();
    }

    private void createLimits() {
        limitChips.removeAllViews();
        int[] options = {5,10,20,50,0};
        for (int i : options) {
            TextView chip = text(i == 0 ? "Todas" : String.valueOf(i),13,limit==i ? BG : TEXT,true);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(12),dp(11),dp(12),dp(11));
            chip.setBackground(round(limit==i ? MINT : PANEL,11));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2,-2); lp.rightMargin=dp(8);
            limitChips.addView(chip,lp);
            chip.setOnClickListener(v -> {
                limit=i;
                prefs().edit().putInt("limit",i).apply();
                createLimits(); refresh();
            });
        }
    }

    private void showFilters() {
        String[] labels={"Más caché primero","Más de 10 MB","Más de 50 MB","Más de 100 MB","Elegir aplicaciones"};
        new AlertDialog.Builder(this).setTitle("Filtro de limpieza")
                .setSingleChoiceItems(labels, filter, (dialog, which) -> {
                    filter=which; prefs().edit().putInt("filter",which).apply();
                    dialog.dismiss(); refresh();
                    if (which == SelectionRules.MANUAL) chooseApps();
                }).setNegativeButton("Cancelar",null).show();
    }

    private void chooseApps() {
        if (apps.isEmpty()) { msg("Primero espera a que se detecten las apps."); return; }
        List<AppTarget> candidates = scoped();
        candidates.sort((a,b) -> Long.compare(b.cacheBytes,a.cacheBytes));
        String[] names = new String[candidates.size()];
        boolean[] selected = new boolean[candidates.size()];
        Set<String> working = new HashSet<>(picked);
        for (int i=0;i<candidates.size();i++) {
            AppTarget app = candidates.get(i);
            names[i]=app.label + (app.cacheBytes >= 0 ? " · "+CacheScanner.size(app.cacheBytes) : "");
            selected[i]=working.contains(app.packageName);
        }
        new AlertDialog.Builder(this).setTitle("Elegir aplicaciones")
                .setMultiChoiceItems(names,selected,(d,which,checked)-> {
                    String pkg=candidates.get(which).packageName;
                    if (checked) working.add(pkg); else working.remove(pkg);
                })
                .setNeutralButton("Ninguna",(d,w)-> { picked.clear(); filter=SelectionRules.MANUAL;
                    prefs().edit().putInt("filter",filter)
                            .putStringSet("picked",new HashSet<>(picked)).apply(); refresh(); })
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Guardar",(d,w)-> {
                    picked.clear(); picked.addAll(working);
                    filter=SelectionRules.MANUAL;
                    prefs().edit().putInt("filter",filter)
                            .putStringSet("picked",new HashSet<>(picked)).apply(); refresh();
                }).show();
    }

    private void chooseExclusions() {
        if (apps.isEmpty()) { msg("Todavía no hay aplicaciones."); return; }
        ArrayList<AppTarget> candidates = new ArrayList<>(apps);
        candidates.sort(Comparator.comparing(a->a.label.toLowerCase(Locale.ROOT)));
        String[] names = new String[candidates.size()];
        boolean[] values = new boolean[candidates.size()];
        Set<String> working = new HashSet<>(excluded);
        for(int i=0;i<candidates.size();i++) {
            names[i]=candidates.get(i).label;
            values[i]=working.contains(candidates.get(i).packageName);
        }
        new AlertDialog.Builder(this).setTitle("Nunca limpiar estas apps")
                .setMultiChoiceItems(names,values,(d,index,checked)-> {
                    String pkg=candidates.get(index).packageName;
                    if (checked) working.add(pkg); else working.remove(pkg);
                }).setNegativeButton("Cancelar",null)
                .setPositiveButton("Guardar",(d,w)-> {
                    excluded.clear(); excluded.addAll(working);
                    prefs().edit().putStringSet("excluded",new HashSet<>(excluded)).apply(); refresh();
                }).show();
    }

    private void refresh() {
        if (count==null) return;
        boolean active=CacheAccessibilityService.instance()!=null;
        boolean running=SessionState.running;
        List<AppTarget> items = selected();
        count.setText(apps.size()+" apps detectadas · "+scoped().size()+" en este grupo");
        permissionText.setText("Accesibilidad: "+(active?"activa":"pendiente")
                +"  ·  Medición MB: "+(measured?"lista": "sin analizar"));
        allChip.setBackground(round(systemApps?Color.rgb(37,86,85):PANEL,12));
        userChip.setBackground(round(!systemApps?Color.rgb(37,86,85):PANEL,12));
        allChip.setTextColor(systemApps?MINT:MUTED); userChip.setTextColor(!systemApps?MINT:MUTED);
        filterText.setText(new String[]{"Más caché primero","Más de 10 MB","Más de 50 MB",
                "Más de 100 MB","Elegir aplicaciones"}[Math.max(0,Math.min(filter,4))]);
        scanBtn.setEnabled(!scanning&&!running&&!loading);
        scanBtn.setText(scanning?"ANALIZANDO…":"ANALIZAR");
        usageBtn.setText(CacheScanner.hasUsageAccess(this)?"MB AUTORIZADOS":"PERMISO MB");
        accessBtn.setText(active?"✓ Accesibilidad activada":"Activar Accesibilidad");
        accessBtn.setEnabled(!running);
        cleanBtn.setText(running?"LIMPIEZA EN CURSO":"✦  LIMPIAR CACHÉ");
        cleanBtn.setEnabled(!running&&!scanning&&!loading&&!items.isEmpty());
        selectedInfo.setText(items.size()+" apps listas para limpiar");
        long bytes = SelectionRules.totalKnownCache(items);
        previewText.setText(measured ? "Caché medida en selección: " + CacheScanner.size(bytes)
                + " · Puede variar durante el uso" : "Permite consultar los MB para ordenar por tamaño.");
        StringBuilder sig = new StringBuilder(filter + "/" + limit + "/" + systemApps + "/" + measured);
        for (AppTarget a:items) sig.append('|').append(a.packageName).append(':').append(a.cacheBytes);
        if (!sig.toString().equals(previewSignature)) {
        previewSignature = sig.toString();
        previewRows.removeAllViews();
        for(int i=0;i<Math.min(5,items.size());i++) {
            AppTarget app=items.get(i);
            LinearLayout row = horizontal(); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView name=text((i+1)+". "+app.label,12,TEXT,false); name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            row.addView(name,new LinearLayout.LayoutParams(0,-2,1f));
            TextView size=text(CacheScanner.size(app.cacheBytes),12,MINT,true);
            size.setPadding(dp(8),0,0,0); row.addView(size);
            addMargin(previewRows,row,7);
        }
        if (items.size()>5) previewRows.addView(text("+"+(items.size()-5)+" aplicaciones más",12,MUTED,false));
        }
        if (running) {
            progressText.setText("Procesando " + SessionState.index + " / " + SessionState.total);
            resultText.setText(SessionState.appName + "\nAcciones de caché: "+SessionState.pressed
                    + " · Omitidas: " + SessionState.skipped);
        } else {
            progressText.setText("Listo para comenzar");
            resultText.setText(SessionState.result);
        }
        stopBtn.setVisibility(running?View.VISIBLE:View.GONE);
        resumeBtn.setVisibility(!running&&CleaningCheckpoint.hasRemaining(this)?View.VISIBLE:View.GONE);
    }

    private void startCleaning(boolean resume) {
        if (SessionState.running||scanning||loading) return;
        CacheAccessibilityService service=CacheAccessibilityService.instance();
        if (service==null) { requestAccessibility(); return; }
        if (!resume && filter!=SelectionRules.MANUAL && !measured) {
            new AlertDialog.Builder(this).setTitle("Faltan los MB")
                    .setMessage("Para ordenar por caché necesitas el permiso de datos de uso. "
                            + "Puedes otorgarlo o limpiar sin orden de tamaño.")
                    .setNegativeButton("Cancelar",null)
                    .setNeutralButton("Limpiar sin análisis",(d,w)-> confirmStart(false))
                    .setPositiveButton("Dar permiso",(d,w)->requestUsage()).show();
            return;
        }
        if (resume) {
            List<AppTarget> remaining=CleaningCheckpoint.remaining(this);
            if (remaining.isEmpty()) { msg("No hay tareas pendientes."); refresh(); return; }
            new AlertDialog.Builder(this).setTitle("Reanudar limpieza")
                    .setMessage("Se volverá a abrir la app donde quedó la limpieza. Solo se pulsará Borrar caché.")
                    .setNegativeButton("Cancelar",null)
                    .setPositiveButton("Reanudar",(d,w)-> {
                        CleaningCheckpoint.start(this, remaining);
                        lastStarted=new ArrayList<>(remaining); verifyAfter=CacheScanner.hasUsageAccess(this);
                        service.startCleaning(new ArrayList<>(remaining)); refresh();
                    }).show();
        } else confirmStart(true);
    }

    private void confirmStart(boolean analyzed) {
        CacheAccessibilityService service=CacheAccessibilityService.instance();
        if(service==null) {requestAccessibility();return;}
        List<AppTarget> targets = selected();
        if (targets.isEmpty()) { msg("No hay apps con caché para este filtro."); return; }
        new AlertDialog.Builder(this).setTitle("Limpiar "+targets.size()+" aplicaciones")
                .setMessage("Caché Zeta abrirá los ajustes automáticamente, una app a la vez. "
                        +"Solo pulsará Borrar caché. Mantén el móvil desbloqueado.\n\n"
                        +"Podrás detener y reanudar el recorrido.")
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Empezar",(d,w)-> {
                    CleaningCheckpoint.start(this,targets);
                    lastStarted=new ArrayList<>(targets); verifyAfter=measured; verifying=false;
                    service.startCleaning(new ArrayList<>(targets)); refresh();
                }).show();
    }

    private void verifyResults() {
        if (!CacheScanner.hasUsageAccess(this)||lastStarted.isEmpty()) { verifyAfter=false; return; }
        verifyAfter=false; verifying=true;
        final List<AppTarget> before=new ArrayList<>(lastStarted);
        worker.execute(()-> {
            List<AppTarget> after=CacheScanner.measure(getApplicationContext(),before,null);
            Map<String,Long> afterCache=new HashMap<>();
            for(AppTarget app:after) afterCache.put(app.packageName,app.cacheBytes);
            long reduced=0; int compared=0;
            for(AppTarget app:before) {
                Long end=afterCache.get(app.packageName);
                if(app.cacheBytes>=0&&end!=null&&end>=0) {
                    reduced+=Math.max(0,app.cacheBytes-end); compared++;
                }
            }
            final long bytes=reduced; final int valid=compared;
            ui.post(()-> {
                verifying=false;
                if (valid>0) SessionState.result += "\nCaché reducida estimada: "+CacheScanner.size(bytes)
                        +" en "+valid+" apps medidas (puede cambiar mientras se usan).";
                refresh(); analyze();
            });
        });
    }

    private void requestUsage() {
        new AlertDialog.Builder(this).setTitle("Acceso a datos de uso")
                .setMessage("Permite consultar cuántos MB de caché tiene cada app. "
                        +"Se usa únicamente en tu teléfono para ordenar y filtrar. "
                        +"No recopila ni envía datos por Internet.\n\n"
                        +"Activa Caché Zeta en la pantalla que abrirá Android.")
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Continuar",(d,w)-> {
                    awaitingUsage=true;
                    try { startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); }
                    catch(Exception e){msg("No se pudieron abrir los permisos de uso.");}
                }).show();
    }

    private void requestAccessibility() {
        if (CacheAccessibilityService.instance()!=null) { msg("Accesibilidad ya está activada."); return; }
        new AlertDialog.Builder(this).setTitle("Permiso de Accesibilidad")
                .setMessage("Solo cuando pulses Limpiar caché, el servicio leerá los controles de "
                        +"Ajustes para abrir Almacenamiento y pulsar Borrar caché. "
                        +"Puede ver la pantalla según el aviso de Android, pero no se usa para leer "
                        +"mensajes o contraseñas, ni se transmiten datos.\n\n"
                        +"Podrás detener el recorrido y desactivar el permiso cuando quieras.")
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Acepto",(d,w)-> {
                    try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
                    catch(Exception e){msg("No se pudieron abrir los ajustes de Accesibilidad.");}
                }).show();
    }

    private void msg(String text) { new AlertDialog.Builder(this).setMessage(text).setPositiveButton("Aceptar",null).show(); }
    private TextView text(String str,int sp,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(str); t.setTextSize(sp); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }
    private Button button(String str,int color,int textColor) {
        Button b=new Button(this); b.setText(str); b.setTextSize(14);
        b.setTextColor(textColor); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setAllCaps(false); b.setBackground(ripple(color,14)); b.setMinHeight(0);
        b.setPadding(dp(12),dp(12),dp(12),dp(12)); return b;
    }
    private void addMargin(LinearLayout parent, View child,int dpTop) {
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.topMargin=dp(dpTop); parent.addView(child,lp);
    }
    private void addWeight(LinearLayout parent,View child,float weight,int leftDp) {
        if(child instanceof TextView) {
            ((TextView)child).setGravity(Gravity.CENTER);
            child.setPadding(dp(5),dp(13),dp(5),dp(13));
        }
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,weight);
        lp.leftMargin=dp(leftDp); parent.addView(child,lp);
    }
    private LinearLayout vertical(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout horizontal(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);return v;}
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private GradientDrawable round(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    private GradientDrawable gradient(int a,int b,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});g.setCornerRadius(dp(radius));return g;}
    private RippleDrawable ripple(int color,int radius){return new RippleDrawable(ColorStateList.valueOf(0x35ffffff),round(color,radius),null);}
}
