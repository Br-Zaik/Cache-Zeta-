package com.zetacache.app;

/** Estado temporal, solo en memoria; sin métricas engañosas de MB liberados. */
public final class SessionState {
    private SessionState() {}
    public static volatile boolean running = false;
    public static volatile int total = 0;
    public static volatile int index = 0;
    public static volatile int pressed = 0;
    public static volatile int skipped = 0;
    public static volatile String appName = "";
    public static volatile long cachePlanned = -1L;
    public static volatile String result = "Sin limpiezas todavía.";

    public static void begin(int count) {
        total = count;
        index = 0;
        pressed = 0;
        skipped = 0;
        appName = "Preparando…";
        result = "";
        cachePlanned = -1L;
        running = true;
    }

    public static void finish(boolean cancelled) {
        running = false;
        appName = "";
        result = (cancelled ? "Limpieza detenida. " : "Recorrido terminado. ")
                + "Botones de caché pulsados: " + pressed + ". "
                + "Apps omitidas: " + skipped + ". "
                + "Android puede impedir la limpieza de algunas apps.";
    }
}
