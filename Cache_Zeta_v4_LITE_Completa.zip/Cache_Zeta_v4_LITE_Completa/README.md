# Caché Zeta v4 Lite Completa

App Android nativa (Java, sin bibliotecas externas). Un botón limpia **solo caché** de las apps seleccionadas. Incluye un panel sencillo de juegos con datos reales del teléfono.

## Limpieza
- **Todas las apps** o **Instaladas por mí**.
- **Analizar**: mide caché por app con `StorageStatsManager` (Android 8+, requiere Acceso a datos de uso).
- Más caché primero; filtros **más de 10 / 50 / 100 MB**; **Top 5 / 10 / 20 / 50 / Todas**; selección manual; exclusiones.
- Accesibilidad: abre Ajustes de cada app y reconoce exclusivamente «Borrar caché». Nunca busca «Borrar datos» ni ejecuta borrado de almacenamiento.
- Detener y **reanudar**: guarda localmente la lista pendiente. No reanuda sin un toque del usuario.
- Progreso e historial local; diferencia de caché antes/después identificada como **estimación**, nunca liberación garantizada.

## Juegos (panel separado)
- Consulta **RAM disponible / total**, batería, **temperatura de la batería** (no temperatura del procesador) y almacenamiento libre.
- Guarda hasta **6 juegos favoritos** para abrirlos rápidamente.
- Acceso a ajustes de **No molestar**: el usuario lo activa/desactiva. No requiere permiso adicional.
- No cierra otras apps ni dice acelerar CPU, ping o FPS.

## Compatibilidad y permisos
- Código para **Android 8 a 16** (minSdk 26, compileSdk/targetSdk 36), con UI adaptable. Probado en código, **no probado físicamente en todas las marcas**. Moto, Samsung, Xiaomi, Realme, OPPO, etc. pueden tener Ajustes diferentes; las pantallas desconocidas se omiten.
- `QUERY_ALL_PACKAGES`: localizar apps para filtros/limpieza; **restringido en Google Play**.
- `PACKAGE_USAGE_STATS`: acceso que se concede manualmente en Ajustes para leer cifras de caché.
- `BIND_ACCESSIBILITY_SERVICE`: usuario habilita desde Ajustes tras aviso y consentimiento; automatiza únicamente la ruta de caché.
- **No solicita INTERNET**, almacenamiento general, contactos, SMS, ubicación ni acceso a notificaciones.
- Sin root, sin anuncios, sin registro de cuenta.

## Generar APK mediante GitHub Actions
1. En tu repositorio **Br-Zaik/Cache-Zeta-**, elimina el ZIP de la versión anterior y sube **solo este ZIP**.
2. Conserva `.github/workflows/android.yml` en el repositorio. El workflow detecta un proyecto en carpeta **o un solo ZIP**, instala Java 17, Android SDK 36 y Gradle 8.13, ejecuta pruebas y crea `app-debug.apk`.
3. Abre `Actions → APK Cache Zeta Personal → Run workflow` (o el nombre que tengas en el repositorio), y descarga el artefacto APK si termina en verde.
4. Al abrir la app, concede Accesibilidad. Para filtros por MB, concede también Acceso a datos de uso y pulsa **ANALIZAR**.
5. Prueba primero **Instaladas por mí → 5 → Limpiar**, y verifica manualmente que la caché se redujo en Ajustes. Mantén Play Protect activado.

## Nota de compilación y firma
Este ZIP incluye **código, tests y workflow**, no un APK previamente compilado. Aquí no hay Android SDK para compilar; verifica Actions. Los APK `debug` de diferentes máquinas pueden usar firmas distintas. En caso de error de firma al actualizar, desinstalar la versión anterior borra preferencias locales. Para publicar en Play Store se necesita un **AAB firmado con clave de lanzamiento estable**, aprobación de permisos y pruebas con varias marcas. **El ZIP no garantiza aprobación ni compatibilidad universal.**

Más detalles en `PRIVACIDAD.md` y `docs/PRUEBAS_Y_PLAY.md`.
