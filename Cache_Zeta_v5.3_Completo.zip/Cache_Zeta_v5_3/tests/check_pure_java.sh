#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
javac -encoding UTF-8 -d "$WORK" \
  app/src/main/java/com/zetacache/app/{AppTarget,SelectionRules,UiLabels,SessionState,IdenticalFiles}.java \
  tests/PureJavaCheck.java tests/FilesCheck.java
java -cp "$WORK" PureJavaCheck
java -cp "$WORK" com.zetacache.app.FilesCheck
javac -encoding UTF-8 -d "$WORK" tests/ParseAndroidSources.java
java -cp "$WORK" ParseAndroidSources

python3 tests/check_ui_source.py
