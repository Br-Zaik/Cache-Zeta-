# Privacidad de Caché Zeta

La app procesa los datos en el teléfono. Guarda localmente las mediciones de caché, las selecciones, los favoritos, el índice de duplicados y el historial.

Acceso a datos de uso permite medir la caché de las aplicaciones. La visibilidad de paquetes permite enumerar las apps. Accesibilidad se usa para la limpieza iniciada y confirmada por el usuario. El servicio busca el control «Borrar caché» en la pantalla de Ajustes de cada app.

Duplicados pide acceso persistente a las carpetas locales elegidas en el selector de Android. Lee archivos para comparar su contenido y guarda huellas SHA-256, nombres, tamaños y ubicaciones. La eliminación es definitiva y requiere seleccionar copias y confirmarlas. En Carpetas se puede quitar una ubicación para revocar el acceso que se concedió a esa carpeta. Las sesiones anteriores siguen en el historial. No se solicita permiso de Internet.
