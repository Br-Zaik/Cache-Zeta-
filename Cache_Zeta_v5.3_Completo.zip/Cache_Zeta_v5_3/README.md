# Caché Zeta 5.3

Proyecto Android nativo en Java. Android 8 o posterior (API 26–36 como intervalo de compilación y destino). Para generar el APK, sustituye el ZIP anterior en tu repositorio y usa tu workflow habitual de GitHub Actions.

## Limpieza

El inicio muestra caché medida y almacenamiento. Elige Todas las apps, Instaladas por mí o Sistema, y un mínimo inclusivo de 5, 10, 50 o 100 MB. El mínimo de 5 MB también se aplica a la selección manual y a la reanudación. La selección manual respeta las apps marcadas sin recortarlas al Top. Los tamaños que el sistema no deja medir quedan fuera. Antes de comenzar se vuelven a medir las apps seleccionadas.

Al volver a la app se reutilizan las mediciones recientes durante 15 minutos. Al pasar ese tiempo se actualizan en segundo plano. También se puede pulsar Volver a analizar. Accesibilidad informa si el servicio está activo, si Android aún debe conectarlo o si está desactivado.

## Duplicados

En Duplicados → Carpetas, añade las carpetas locales que quieras comparar, por ejemplo DCIM, Pictures, Movies o una carpeta de la SD. Android controla las ubicaciones que se pueden autorizar. En versiones recientes puede ser necesario elegir subcarpetas. Añade las dos ubicaciones si deseas comparar entre el teléfono y la tarjeta. Secciones independientes para fotos, videos y otros archivos. El análisis manual actúa sobre la sección visible. En las aperturas posteriores, el análisis automático revisa las secciones pendientes con las carpetas ya autorizadas.

Se agrupan archivos no vacíos del mismo tipo por tamaño. Solo los candidatos se leen para calcular SHA-256. La app reutiliza huellas cuando el identificador, el tamaño y la fecha de modificación coinciden. El índice temporal está en disco. Los videos se leen por bloques de 64 KiB. Pausar conserva el último resultado completo. La enumeración de nombres y fechas puede tomar tiempo en una SD grande.

Toca un grupo, marca las copias y revisa sus ubicaciones antes de confirmar la eliminación definitiva. Debe quedar al menos una. La app compara el contenido de cada copia con una conservada justo antes de pedir al proveedor local que la borre. Si la SD no está disponible, cambia el contenido o falla el borrado, el elemento queda omitido. Las imágenes similares, recortadas o recomprimidas se consideran archivos diferentes.

## Historial

Historial abre una pantalla independiente. Cada sesión de caché muestra las apps previstas, omitidas, pendientes o pulsadas. Los MB se calculan a partir de las mediciones anterior y posterior. Sin una segunda medición válida se indica «Sin verificar». En los duplicados se guardan nombre, ubicación, tamaño y resultado. Los registros de versiones anteriores siguen disponibles como resúmenes.

El comportamiento de Accesibilidad depende de los controles que muestre el fabricante en Ajustes. La app omite las pantallas que no identifica.
