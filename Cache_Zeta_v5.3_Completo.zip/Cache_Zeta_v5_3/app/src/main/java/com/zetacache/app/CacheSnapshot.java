package com.zetacache.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.util.List;

final class CacheSnapshot {
    static final long FRESH_MS=15*60*1000L;
    static boolean fresh(long stamp){long age=System.currentTimeMillis()-stamp;return stamp>0 && age>=0 && age<FRESH_MS;}
    static SharedPreferences prefs(Context c){return c.getSharedPreferences("cache_snapshot",Context.MODE_PRIVATE);}
    static void save(Context c,List<AppTarget> apps,long scanGeneration){
        try{
            JSONObject map=new JSONObject();
            for(AppTarget app:apps)map.put(app.packageName,app.cacheBytes);
            synchronized(CacheSnapshot.class){
                if(generation(c)!=scanGeneration)return;
                prefs(c).edit().putString("apps",map.toString()).putLong("stamp",System.currentTimeMillis()).apply();
            }
        }catch(org.json.JSONException ignored){}
    }
    static synchronized long generation(Context c){return prefs(c).getLong("generation",0);}
    static synchronized void invalidate(Context c){prefs(c).edit().putLong("generation",generation(c)+1).remove("stamp").apply();}
    static boolean restore(Context c,List<AppTarget> installed){
        try{
            JSONObject map=new JSONObject(prefs(c).getString("apps","{}"));
            boolean same=map.length()==installed.size();boolean known=false;
            for(int i=0;i<installed.size();i++){
                AppTarget a=installed.get(i);long bytes=map.optLong(a.packageName,-1);
                installed.set(i,a.withCache(bytes));same &= map.has(a.packageName);known |= bytes>=0;
            }
            return known && same && fresh(prefs(c).getLong("stamp",0));
        }catch(org.json.JSONException ignored){return false;}
    }
}
