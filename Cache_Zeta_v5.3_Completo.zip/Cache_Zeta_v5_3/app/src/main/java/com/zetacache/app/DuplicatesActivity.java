package com.zetacache.app;

import android.app.AlertDialog;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.DocumentsContract;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;

public final class DuplicatesActivity extends ToolsPage {
    private int kind,revision;
    private TextView status;
    private Button scan;
    private ListView list;
    private final Button[] tabs=new Button[3];
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService reader=Executors.newSingleThreadExecutor();
    private final Runnable tick=new Runnable(){public void run(){updateStatus();main.postDelayed(this,1000);}};
    private final BroadcastReceiver updated=new BroadcastReceiver(){public void onReceive(Context c,Intent i){refresh();}};
    private boolean deleting;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);kind=b==null?0:b.getInt("kind");heading.setText("Duplicados");
        LinearLayout types=new LinearLayout(this);body.addView(types);
        for(int i=0;i<tabs.length;i++){
            final int type=i;tabs[i]=button(DuplicateIndex.TITLES[i]);action(types,tabs[i]);
            tabs[i].setOnClickListener(v->{kind=type;refresh();});
        }
        LinearLayout actions=new LinearLayout(this);body.addView(actions);
        Button folders=button("Carpetas");action(actions,folders);folders.setOnClickListener(v->folders());
        scan=button("Analizar");action(actions,scan);scan.setOnClickListener(v->{
            if(DuplicateIndex.busy){DuplicateIndex.cancel();return;}
            if(DuplicateIndex.roots(this).isEmpty())chooseFolder();
            else DuplicateIndex.scan(this,kind,true);
            updateStatus();
        });
        status=new TextView(this);status.setTextColor(NeonStyle.MUTED);status.setPadding(dp(6),dp(9),dp(6),dp(9));body.addView(status);
        list=new ListView(this);body.addView(list,-1,-1);
    }
    @Override protected void onStart(){
        super.onStart();IntentFilter f=new IntentFilter(DuplicateIndex.EVENT);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(updated,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(updated,f);
        DuplicateIndex.scan(this,DuplicateIndex.ALL,false);refresh();main.post(tick);
    }
    @Override protected void onStop(){unregisterReceiver(updated);main.removeCallbacks(tick);super.onStop();}
    @Override protected void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);b.putInt("kind",kind);}
    @Override protected void onDestroy(){reader.shutdownNow();super.onDestroy();}
    private long stamp;
    private int unread,groups;
    private boolean authorized;
    private void updateStatus(){
        scan.setEnabled(!deleting);scan.setText(DuplicateIndex.busy?"Pausar":"Analizar "+DuplicateIndex.TITLES[kind].toLowerCase(Locale.ROOT));
        if(deleting)status.setText("Verificando las copias elegidas…");
        else if(DuplicateIndex.busy)status.setText(DuplicateIndex.progress);
        else if(!authorized)status.setText("Añade carpetas del teléfono o de la SD para buscar duplicados.");
        else if(stamp==0)status.setText("Carpetas listas. Pulsa Analizar.");
        else status.setText(groups+" grupos · "+android.text.format.DateUtils.getRelativeTimeSpanString(stamp)+
                    (unread>0?" · "+unread+" sin acceso":""));
        if(!DuplicateIndex.busy&&!deleting&&(DuplicateIndex.progress.startsWith("No se pudo")||DuplicateIndex.progress.equals("Análisis pausado")))status.setText(DuplicateIndex.progress);
    }
    private void refresh(){
        final int type=kind,ticket=++revision;
        for(int i=0;i<tabs.length;i++)tabs[i].setBackground(NeonStyle.ripple(NeonStyle.chip(this,i==type)));
        reader.execute(()->{
            List<DuplicateIndex.Group> items=DuplicateIndex.groups(this,type);
            boolean granted=!DuplicateIndex.roots(this).isEmpty();
            runOnUiThread(()->{
                if(isDestroyed()||ticket!=revision)return;
                authorized=granted;groups=items.size();stamp=DuplicateIndex.prefs(this).getLong("time"+type,0);
                unread=DuplicateIndex.prefs(this).getInt("unread"+type,0);updateStatus();
                list.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,items));
                list.setOnItemClickListener((p,v,i,id)->{if(!deleting)showCopies(type,items.get(i));});
            });
        });
    }
    private void folders(){
        List<Uri> roots=DuplicateIndex.roots(this);
        if(roots.isEmpty()){chooseFolder();return;}
        String[] names=new String[roots.size()];
        for(int i=0;i<names.length;i++)names[i]=DuplicateIndex.folderName(this,DocumentsContract.getTreeDocumentId(roots.get(i)));
        new AlertDialog.Builder(this).setTitle("Carpetas incluidas").setItems(names,(d,i)->
                new AlertDialog.Builder(this).setMessage("¿Dejar de analizar "+names[i]+"?").setNegativeButton("Cancelar",null)
                        .setPositiveButton("Quitar carpeta",(dd,w)->{
                            Uri uri=roots.get(i);
                            for(UriPermission permission:getContentResolver().getPersistedUriPermissions())if(uri.equals(permission.getUri())){
                                int flags=(permission.isReadPermission()?Intent.FLAG_GRANT_READ_URI_PERMISSION:0)|(permission.isWritePermission()?Intent.FLAG_GRANT_WRITE_URI_PERMISSION:0);
                                getContentResolver().releasePersistableUriPermission(uri,flags);break;
                            }
                            resetRoots();
                        }).show())
                .setNegativeButton("Cerrar",null).setPositiveButton("Añadir carpeta",(d,i)->chooseFolder()).show();
    }
    private void chooseFolder(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try{startActivityForResult(i,44);}catch(ActivityNotFoundException ex){toast("El selector de carpetas no está disponible.");}
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req!=44||result!=RESULT_OK||data==null)return;
        Uri uri=data.getData();if(!DuplicateIndex.isLocalTree(uri)){toast("Elige una carpeta local del teléfono o de la SD.");return;}
        int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try{getContentResolver().takePersistableUriPermission(uri,flags);resetRoots();}
        catch(SecurityException ex){toast("Android no concedió acceso a esa carpeta.");}
    }
    private void resetRoots(){
        DuplicateIndex.cancel();DuplicateIndex.dirty(this);
        Context c=getApplicationContext();
        DuplicateIndex.worker.execute(()->{
            ResultsDb.get(c).getWritableDatabase().delete("media",null,null);DuplicateIndex.dirty(c);
            DuplicateIndex.scan(c,DuplicateIndex.ALL,true);
            runOnUiThread(()->{if(!isDestroyed())refresh();});
        });
    }
    private void showCopies(int type,DuplicateIndex.Group group){
        reader.execute(()->{
            List<DuplicateIndex.Item> copies=DuplicateIndex.copies(this,type,group);
            runOnUiThread(()->{
                if(isFinishing()||isDestroyed()||kind!=type)return;
                if(copies.size()<2){refresh();return;}
                String[] names=new String[copies.size()];boolean[] marked=new boolean[names.length];
                Set<String> selected=new HashSet<>();
                for(int i=0;i<names.length;i++)names[i]=copies.get(i).toString();
                AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Elige las copias que borrarás")
                    .setMultiChoiceItems(names,marked,(d,i,on)->{
                        String doc=copies.get(i).doc;
                        if(on&&selected.size()==copies.size()-1){((AlertDialog)d).getListView().setItemChecked(i,false);toast("Conserva al menos una copia.");}
                        else if(on)selected.add(doc);else selected.remove(doc);
                        ((AlertDialog)d).getButton(-1).setEnabled(!selected.isEmpty());
                    }).setNegativeButton("Cerrar",null).setPositiveButton("Revisar",(d,i)->confirm(copies,selected)).create();
                dialog.show();dialog.getButton(-1).setEnabled(false);
            });
        });
    }
    private void confirm(List<DuplicateIndex.Item> copies,Set<String> selected){
        if(selected.isEmpty()||selected.size()>=copies.size())return;
        StringBuilder message=new StringBuilder("Eliminar definitivamente:\n");
        for(DuplicateIndex.Item item:copies)if(selected.contains(item.doc))message.append("\n").append(item.path);
        new AlertDialog.Builder(this).setTitle("Eliminar "+selected.size()+" copias").setMessage(message)
            .setNegativeButton("Cancelar",null).setPositiveButton("Eliminar",(d,i)->{
                deleting=true;updateStatus();Context c=getApplicationContext();
                DuplicateIndex.cancel();
                DuplicateIndex.worker.execute(()->{
                    String result;
                    try{result=DuplicateIndex.remove(c,copies,selected);}catch(RuntimeException e){result="No se pudo completar. Revisa el historial.";}
                    final String text=result;runOnUiThread(()->{if(!isDestroyed()){deleting=false;toast(text);refresh();}});
                });
            }).show();
    }
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_SHORT).show();}
}
