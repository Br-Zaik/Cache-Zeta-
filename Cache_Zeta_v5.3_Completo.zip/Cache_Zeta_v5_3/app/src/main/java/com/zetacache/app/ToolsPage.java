package com.zetacache.app;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.View;
import android.view.WindowInsets;
import android.widget.*;

abstract class ToolsPage extends Activity {
    LinearLayout body;
    TextView heading;
    int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(NeonStyle.BG);
        getWindow().setNavigationBarColor(NeonStyle.BG);
        body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setBackgroundColor(NeonStyle.BG);
        body.setPadding(dp(16),dp(8),dp(16),dp(8)); setContentView(body);
        if(Build.VERSION.SDK_INT>=30){
            getWindow().setDecorFitsSystemWindows(false);
            body.setOnApplyWindowInsetsListener((v,i)->{
                android.graphics.Insets b=i.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                v.setPadding(b.left+dp(16),b.top+dp(8),b.right+dp(16),b.bottom+dp(8));return i;
            });
            body.requestApplyInsets();
        }
        LinearLayout row=new LinearLayout(this);row.setGravity(android.view.Gravity.CENTER_VERTICAL);body.addView(row);
        Button back=button("‹");back.setContentDescription("Volver");back.setOnClickListener(v->onBackPressed());
        row.addView(back,dp(48),dp(48));heading=new TextView(this);heading.setPadding(dp(10),0,0,0);
        heading.setTextSize(22);heading.setTextColor(NeonStyle.TEXT);heading.setTypeface(null,Typeface.BOLD);row.addView(heading);
    }
    Button button(String text){
        Button b=new Button(this);b.setText(text);b.setTextSize(13);b.setAllCaps(false);b.setTextColor(NeonStyle.CYAN);
        b.setMinHeight(dp(44));b.setMinWidth(0);b.setPadding(dp(7),dp(3),dp(7),dp(3));
        b.setBackground(NeonStyle.ripple(NeonStyle.solid(this,NeonStyle.PANEL,11,0)));return b;
    }
    void action(LinearLayout row,Button button){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(2),dp(4),dp(2),dp(4));row.addView(button,lp);
    }
}
