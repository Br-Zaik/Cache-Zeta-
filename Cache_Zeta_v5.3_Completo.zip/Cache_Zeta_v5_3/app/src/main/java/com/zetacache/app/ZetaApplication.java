package com.zetacache.app;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

/** Allow transitions between pages and the folder picker without an idle scan running indefinitely. */
public final class ZetaApplication extends Application implements Application.ActivityLifecycleCallbacks {
    private int visible;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Runnable pauseScan=()->{if(visible==0)DuplicateIndex.cancel();};
    @Override public void onCreate(){super.onCreate();registerActivityLifecycleCallbacks(this);}
    @Override public void onActivityStarted(Activity activity){visible++;main.removeCallbacks(pauseScan);}
    @Override public void onActivityStopped(Activity activity){if(--visible==0)main.postDelayed(pauseScan,10000);}
    @Override public void onActivityCreated(Activity activity,Bundle state){}
    @Override public void onActivityResumed(Activity activity){}
    @Override public void onActivityPaused(Activity activity){}
    @Override public void onActivitySaveInstanceState(Activity activity,Bundle state){}
    @Override public void onActivityDestroyed(Activity activity){}
}
