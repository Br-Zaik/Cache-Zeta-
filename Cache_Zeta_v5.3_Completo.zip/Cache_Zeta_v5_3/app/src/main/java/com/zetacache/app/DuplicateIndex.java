package com.zetacache.app;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.net.Uri;
import android.os.storage.*;
import android.provider.DocumentsContract;
import android.provider.DocumentsContract.Document;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Index of explicitly granted local folders. One low-priority worker for all media types. */
final class DuplicateIndex {
    static final String[] TITLES={"Fotos","Videos","Archivos"};
    static final int ALL=-1;
    private static final String AUTH="com.android.externalstorage.documents";
    private static final String[] COL={Document.COLUMN_DOCUMENT_ID,Document.COLUMN_DISPLAY_NAME,Document.COLUMN_MIME_TYPE,
            Document.COLUMN_SIZE,Document.COLUMN_LAST_MODIFIED};
    static final ExecutorService worker=Executors.newSingleThreadExecutor(r->new Thread(()->{
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);r.run();
    },"Indice local"));
    private static final AtomicInteger token=new AtomicInteger();
    static volatile boolean busy;
    static volatile String progress="";
    static final String EVENT="com.zetacache.app.INDEX_CHANGED";
    static synchronized void cancel(){token.incrementAndGet();}
    static SharedPreferences prefs(Context c){return c.getSharedPreferences("duplicate_index",Context.MODE_PRIVATE);}
    static List<Uri> roots(Context c){
        List<Uri> result=new ArrayList<>();
        for(UriPermission p:c.getContentResolver().getPersistedUriPermissions())
            if(p.isReadPermission() && AUTH.equals(p.getUri().getAuthority()) && DocumentsContract.isTreeUri(p.getUri()))result.add(p.getUri());
        return result;
    }
    static String folderName(Context c,String doc){
        int colon=doc.indexOf(':');if(colon<0)return doc;
        String id=doc.substring(0,colon),volume=id;
        if(id.equalsIgnoreCase("primary")) volume="Memoria interna";
        else {
            StorageManager manager=c.getSystemService(StorageManager.class);
            if(manager!=null)for(StorageVolume v:manager.getStorageVolumes())if(id.equalsIgnoreCase(v.getUuid())){
                volume=v.getDescription(c);break;
            }
        }
        return volume+" / "+doc.substring(colon+1);
    }
    static final class Item {
        final String doc,name,path; final Uri uri;final long size,mtime;final int kind;
        Item(String id,Uri u,String n,String p,long s,long m,int k){doc=id;uri=u;name=n;path=p;size=s;mtime=m;kind=k;}
        @Override public String toString(){return name+"\n"+path;}
    }
    static final class Group {
        final String digest,name;final int count;final long bytes;
        Group(String d,String n,int c,long b){digest=d;name=n;count=c;bytes=b;}
        @Override public String toString(){return name+"\n"+count+" copias · "+CacheScanner.size(bytes)+" cada una";}
    }
    static final class Folder {
        final Uri tree;final String doc;
        Folder(Uri t,String d){tree=t;doc=d;}
    }
    static int kind(String mime){
        if(mime!=null&&mime.startsWith("image/"))return 0;
        if(mime!=null&&mime.startsWith("video/"))return 1;return 2;
    }
    static boolean isLocalTree(Uri uri){return uri!=null&&AUTH.equals(uri.getAuthority())&&DocumentsContract.isTreeUri(uri);}
    static synchronized void scan(Context context,int requested,boolean force){
        Context c=context.getApplicationContext();
        if(busy || SessionState.running || roots(c).isEmpty())return;
        boolean[] types=new boolean[3];boolean any=false;
        for(int i=0;i<types.length;i++){
            types[i]=(requested==ALL||requested==i)&&(force||!CacheSnapshot.fresh(prefs(c).getLong("time"+i,0)));
            any|=types[i];
        }
        if(!any)return;busy=true;progress="Buscando candidatos…";int generation=token.get();
        worker.execute(()->{
            try{index(c,types,()->generation!=token.get()||SessionState.running);}
            catch(CancellationException e){progress="Análisis pausado";}
            catch(RuntimeException e){progress="No se pudo completar el análisis";}
            finally{busy=false;changed(c);}
        });
    }
    private static void changed(Context c){c.sendBroadcast(new Intent(EVENT).setPackage(c.getPackageName()));}
    static void dirty(Context c){SharedPreferences.Editor e=prefs(c).edit();for(int i=0;i<3;i++)e.remove("time"+i);e.apply();}
    private static void index(Context c,boolean[] types,IdenticalFiles.Cancel cancel){
        // Stage directory entries on disk. Large galleries never require a Java object per photo.
        java.io.File stage=new java.io.File(c.getCacheDir(),"duplicate-scan-stage.db");
        SQLiteDatabase.deleteDatabase(stage);
        try(SQLiteDatabase scratch=SQLiteDatabase.openOrCreateDatabase(stage,null)){
            scratch.execSQL("CREATE TABLE files(kind INTEGER,doc TEXT PRIMARY KEY,uri TEXT,name TEXT,size INTEGER,mtime INTEGER)");
            int unread=walk(c,types,cancel,scratch);
            scratch.execSQL("CREATE INDEX sizes ON files(kind,size)");
            SQLiteDatabase db=ResultsDb.get(c).getWritableDatabase();
            String candidates="SELECT f.kind,f.doc,f.uri,f.name,f.size,f.mtime FROM files f JOIN "
                +"(SELECT kind,size FROM files GROUP BY kind,size HAVING COUNT(*)>1) g ON f.kind=g.kind AND f.size=g.size";
            // Keep a stable candidate cursor while recording computed hashes into a separate table.
            scratch.execSQL("CREATE TABLE verified(doc TEXT PRIMARY KEY,hash TEXT)");
            scratch.beginTransaction();
            try(Cursor q=scratch.rawQuery(candidates,null);
                SQLiteStatement save=scratch.compileStatement("INSERT INTO verified VALUES(?,?)")){
                while(q.moveToNext()){
                    IdenticalFiles.check(cancel);
                    int k=q.getInt(0);String id=q.getString(1);long size=q.getLong(4),mtime=q.getLong(5);
                    progress=TITLES[k]+" · "+q.getString(3);
                    String hash="";
                    if(mtime>0)try(Cursor previous=db.rawQuery("SELECT digest FROM media WHERE kind=? AND doc=? AND size=? AND modified=?",
                            new String[]{""+k,id,""+size,""+mtime})){
                        if(previous.moveToFirst())hash=previous.getString(0);
                    }
                    if(hash.isEmpty()){
                        try(InputStream in=open(c.getContentResolver(),Uri.parse(q.getString(2)))){hash=IdenticalFiles.digest(in,cancel);}
                        catch(IOException|SecurityException|IllegalArgumentException e){unread++;continue;}
                    }
                    save.bindString(1,id);save.bindString(2,hash);save.executeInsert();
                }
                scratch.setTransactionSuccessful();
            } finally {scratch.endTransaction();}
            IdenticalFiles.check(cancel);
            db.beginTransaction();
            try(Cursor q=scratch.rawQuery("SELECT kind,f.doc,uri,name,size,mtime,v.hash FROM files f JOIN verified v ON v.doc=f.doc",null);
                SQLiteStatement insert=db.compileStatement("INSERT INTO media VALUES(?,?,?,?,?,?,?,?)")){
                for(int k=0;k<types.length;k++)if(types[k])db.delete("media","kind=?",new String[]{""+k});
                while(q.moveToNext()){
                    IdenticalFiles.check(cancel);String id=q.getString(1);
                    insert.bindLong(1,q.getInt(0));insert.bindString(2,id);insert.bindString(3,q.getString(2));
                    insert.bindString(4,q.getString(3));insert.bindString(5,folderNameCached(c,id));
                    insert.bindLong(6,q.getLong(4));insert.bindLong(7,q.getLong(5));insert.bindString(8,q.getString(6));
                    insert.executeInsert();
                }
                db.setTransactionSuccessful();
            } finally {db.endTransaction();}
            SharedPreferences.Editor editor=prefs(c).edit();long now=System.currentTimeMillis();
            for(int k=0;k<types.length;k++)if(types[k])editor.putLong("time"+k,now).putInt("unread"+k,unread);
            editor.apply();progress="Análisis completado";
        }finally{SQLiteDatabase.deleteDatabase(stage);}
    }
    private static int walk(Context c,boolean[] types,IdenticalFiles.Cancel cancel,SQLiteDatabase scratch){
        ArrayDeque<Folder> queue=new ArrayDeque<>();
        for(Uri root:roots(c))queue.add(new Folder(root,DocumentsContract.getTreeDocumentId(root)));
        Set<String> visited=new HashSet<>();int unread=0;
        scratch.beginTransaction();
        try(SQLiteStatement file=scratch.compileStatement("INSERT OR IGNORE INTO files(kind,doc,uri,name,size,mtime) VALUES(?,?,?,?,?,?)")){
            while(!queue.isEmpty()){
                IdenticalFiles.check(cancel);Folder f=queue.removeFirst();if(!visited.add(f.doc))continue;
                Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(f.tree,f.doc);
                try(Cursor entries=c.getContentResolver().query(children,COL,null,null,null)){
                    if(entries==null){unread++;continue;}
                    while(entries.moveToNext()){
                        IdenticalFiles.check(cancel);
                        String id=entries.getString(0),mime=entries.getString(2);
                        if(Document.MIME_TYPE_DIR.equals(mime)){queue.add(new Folder(f.tree,id));continue;}
                        int k=kind(mime);if(!types[k])continue;
                        if(entries.isNull(3)){unread++;continue;}
                        long size=entries.getLong(3);if(size<=0)continue;
                        file.bindLong(1,k);file.bindString(2,id);
                        file.bindString(3,DocumentsContract.buildDocumentUriUsingTree(f.tree,id).toString());
                        file.bindString(4,entries.isNull(1)?id:entries.getString(1));
                        file.bindLong(5,size);file.bindLong(6,entries.getLong(4));file.executeInsert();
                    }
                }catch(SecurityException|IllegalArgumentException e){unread++;}
            }
            scratch.setTransactionSuccessful();
        }finally{scratch.endTransaction();}
        return unread;
    }
    // Cache volume labels for the duration of the process; paths remain local to the selected tree.
    private static final Map<String,String> labels=new HashMap<>();
    private static String folderNameCached(Context c,String doc){
        int split=doc.indexOf(':');if(split<0)return doc;String id=doc.substring(0,split+1);
        String prefix=labels.get(id);if(prefix==null){prefix=folderName(c,id);labels.put(id,prefix);}
        return prefix+doc.substring(split+1);
    }
    static InputStream open(ContentResolver r,Uri uri)throws IOException{
        InputStream in=r.openInputStream(uri);if(in==null)throw new FileNotFoundException();return in;
    }
    static List<Group> groups(Context c,int kind){
        List<Group> groups=new ArrayList<>();
        try(Cursor q=ResultsDb.get(c).getReadableDatabase().rawQuery("SELECT digest,MIN(name),COUNT(*),size FROM media WHERE kind=? GROUP BY digest,size HAVING COUNT(*)>1 ORDER BY (COUNT(*)-1)*size DESC",new String[]{""+kind})){
            while(q.moveToNext())groups.add(new Group(q.getString(0),q.getString(1),q.getInt(2),q.getLong(3)));
        }
        return groups;
    }
    static List<Item> copies(Context c,int k,Group group){
        List<Item> items=new ArrayList<>();
        try(Cursor q=ResultsDb.get(c).getReadableDatabase().rawQuery("SELECT doc,uri,name,location,size,modified FROM media WHERE kind=? AND digest=? AND size=? ORDER BY location",
                new String[]{""+k,group.digest,""+group.bytes})){
            while(q.moveToNext())items.add(new Item(q.getString(0),Uri.parse(q.getString(1)),q.getString(2),q.getString(3),q.getLong(4),q.getLong(5),k));
        }
        return items;
    }
    static String remove(Context c,List<Item> items,Set<String> selected){
        Item keep=null;
        for(Item item:items)if(!selected.contains(item.doc)){keep=item;break;}
        if(keep==null||selected.isEmpty())return "Selecciona copias y conserva al menos una.";
        ResultsDb db=ResultsDb.get(c);long session=db.begin("Duplicados · "+TITLES[keep.kind]);int removed=0,skipped=0;
        try{
            for(Item item:items){
                if(!selected.contains(item.doc))continue;
                boolean deleted=false;
                try{
                    boolean equal;
                    try(InputStream a=open(c.getContentResolver(),keep.uri);InputStream b=open(c.getContentResolver(),item.uri)){
                        equal=IdenticalFiles.same(a,b,item.size,()->false);
                    }
                    if(equal)deleted=DocumentsContract.deleteDocument(c.getContentResolver(),item.uri);
                }catch(IOException|RuntimeException e){deleted=false;}
                if(deleted){
                    removed++;db.getWritableDatabase().delete("media","kind=? AND doc=?",new String[]{""+item.kind,item.doc});
                }else skipped++;
                db.detail(session,item.doc,item.name,item.path,item.size,deleted?0:-1,deleted?"Eliminado":"Omitido");
            }
        }finally{db.finish(session,skipped==0?"Terminada":"Revisar omitidos");dirty(c);changed(c);}
        return removed+" eliminados · "+skipped+" omitidos";
    }
}
