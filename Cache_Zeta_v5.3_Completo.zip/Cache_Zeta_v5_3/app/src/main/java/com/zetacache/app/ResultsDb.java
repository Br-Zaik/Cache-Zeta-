package com.zetacache.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

final class ResultsDb extends SQLiteOpenHelper {
    private static ResultsDb instance;
    static synchronized ResultsDb get(Context context) {
        if (instance == null) instance = new ResultsDb(context.getApplicationContext());
        return instance;
    }
    private ResultsDb(Context context) {
        super(context, "cleaning_results.db", null, 1);
        setWriteAheadLoggingEnabled(true);
    }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE sessions(id INTEGER PRIMARY KEY,stamp INTEGER,kind TEXT,state TEXT)");
        db.execSQL("CREATE TABLE details(session INTEGER,ref TEXT,label TEXT,location TEXT,beforeBytes INTEGER,afterBytes INTEGER,state TEXT,PRIMARY KEY(session,ref))");
        db.execSQL("CREATE TABLE media(kind INTEGER,doc TEXT,uri TEXT,name TEXT,location TEXT,size INTEGER,modified INTEGER,digest TEXT,PRIMARY KEY(kind,doc))");
        db.execSQL("CREATE INDEX media_groups ON media(kind,digest,size)");
    }
    @Override public void onOpen(SQLiteDatabase db){
        super.onOpen(db);
        db.execSQL("UPDATE sessions SET state='Interrumpida' WHERE state='En curso'");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) {}
    long begin(String kind) {
        ContentValues v=new ContentValues();
        v.put("stamp",System.currentTimeMillis()); v.put("kind",kind); v.put("state","En curso");
        return getWritableDatabase().insertOrThrow("sessions",null,v);
    }
    void finish(long id,String state) {
        getWritableDatabase().execSQL("UPDATE sessions SET state=? WHERE id=?",new Object[]{state,id});
    }
    void detail(long id,String ref,String label,String location,long before,long after,String state) {
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO details VALUES(?,?,?,?,?,?,?)",
                new Object[]{id,ref,label,location,before,after,state});
    }
    void measured(long id,AppTarget app) {
        getWritableDatabase().execSQL("UPDATE details SET afterBytes=?,state=? WHERE session=? AND ref=? AND state='Sin verificar'",
                new Object[]{app.cacheBytes,app.cacheBytes<0?"Sin verificar":"Medida",id,app.packageName});
    }
    static long freed(long before,long after) { return after<0 || before<0 ? 0 : Math.max(0,before-after); }
    static final class Row {
        final long id;
        final String text;
        Row(long id,String text){this.id=id;this.text=text;}
        @Override public String toString(){return text;}
    }
    List<Row> history(long session) {
        List<Row> rows=new ArrayList<>();
        if(session==0){
            String query="SELECT s.id,s.stamp,s.kind,s.state,COUNT(d.ref),SUM(CASE WHEN d.afterBytes>=0 THEN MAX(0,d.beforeBytes-d.afterBytes) END) FROM sessions s LEFT JOIN details d ON s.id=d.session GROUP BY s.id ORDER BY s.id DESC";
            try(Cursor c=getReadableDatabase().rawQuery(query,null)){
                while(c.moveToNext()){
                    String date=java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT,java.text.DateFormat.SHORT).format(new java.util.Date(c.getLong(1)));
                    String size=c.isNull(5)?"Sin medición":CacheScanner.size(c.getLong(5))+" liberados";
                    rows.add(new Row(c.getLong(0),c.getString(2)+" · "+date+"\n"+size+" · "+c.getString(3)+" · "+c.getInt(4)+" elementos"));
                }
            }
        } else try(Cursor c=getReadableDatabase().rawQuery("SELECT label,location,beforeBytes,afterBytes,state FROM details WHERE session=? ORDER BY rowid",new String[]{Long.toString(session)})){
            while(c.moveToNext()){
                long before=c.getLong(2),after=c.getLong(3);
                String status=c.getString(4);
                String amounts=after<0?status:(status.equals("Eliminado")?"Eliminado · "+CacheScanner.size(before):
                        CacheScanner.size(before)+" → "+CacheScanner.size(after)+" · "+CacheScanner.size(freed(before,after))+" liberados");
                rows.add(new Row(session,c.getString(0)+"\n"+amounts+"\n"+c.getString(1)));
            }
        }
        return rows;
    }
}
