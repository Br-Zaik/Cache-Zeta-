package com.zetacache.app;

import android.os.Bundle;
import android.widget.*;
import java.util.List;
import java.util.concurrent.*;

public final class HistoryActivity extends ToolsPage {
    private ListView list;
    private long session;
    private int ticket;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);if(state!=null)session=state.getLong("session");
        list=new ListView(this);body.addView(list,-1,-1);
    }
    private final android.content.BroadcastReceiver updated=new android.content.BroadcastReceiver(){
        @Override public void onReceive(android.content.Context c,android.content.Intent i){load();}
    };
    @Override protected void onStart(){
        super.onStart();
        android.content.IntentFilter f=new android.content.IntentFilter("com.zetacache.app.HISTORY_CHANGED");
        if(android.os.Build.VERSION.SDK_INT>=33)registerReceiver(updated,f,RECEIVER_NOT_EXPORTED);else registerReceiver(updated,f);
    }
    @Override protected void onStop(){unregisterReceiver(updated);super.onStop();}
    @Override protected void onResume(){super.onResume();load();}
    private void load(){
        heading.setText(session==0?"Historial":"Detalle de limpieza");
        final long id=session;final int version=++ticket;
        worker.execute(()->{
            List<ResultsDb.Row> rows=ResultsDb.get(this).history(id);
            if(id==0){
                String old=HistoryStore.get(this);
                if(!old.startsWith("Sin limpiezas")) for(String line:old.split("\n"))rows.add(new ResultsDb.Row(-1,line+"\nRegistro anterior · sin detalle por app"));
            }
            if(rows.isEmpty())rows.add(new ResultsDb.Row(-1,id==0?"Todavía no hay limpiezas.":"Sin elementos registrados."));
            runOnUiThread(()->{
                if(version!=ticket||isDestroyed())return;
                list.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,rows));
                list.setOnItemClickListener((p,v,i,l)->{long selected=rows.get(i).id;if(id==0&&selected>0){session=selected;load();}});
            });
        });
    }
    @Override protected void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);b.putLong("session",session);}
    @Override public void onBackPressed(){if(session!=0){session=0;load();}else super.onBackPressed();}
    @Override protected void onDestroy(){worker.shutdownNow();super.onDestroy();}
}
