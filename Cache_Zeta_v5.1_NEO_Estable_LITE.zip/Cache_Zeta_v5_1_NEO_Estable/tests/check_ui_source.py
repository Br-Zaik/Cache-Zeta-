from pathlib import Path
p=Path('app/src/main/java/com/zetacache/app/MainActivity.java').read_text()
ring=Path('app/src/main/java/com/zetacache/app/CacheRingView.java').read_text()
style=Path('app/src/main/java/com/zetacache/app/NeonStyle.java').read_text()
for label in ('Todas', 'Instaladas por mí', 'Filtro por tamaño', 'Limpiar caché',
              'Seleccionar apps', 'Juegos', 'Historial', 'Top ', 'Sin filtro',
              'Reanudar', 'Accesibilidad'):
    assert label in p, f'Falta: {label}'
assert 'new ScrollView(' not in p, 'El inicio NO debe desplazarse'
assert 'StorageStatsManager' in Path('app/src/main/java/com/zetacache/app/CacheScanner.java').read_text()
assert 'bytes<0' in ring and 'Sin analizar' in ring, 'No mostrar cero antes del análisis'
assert 'GradientDrawable' in style
assert 'isClearCache' in Path('app/src/main/java/com/zetacache/app/CacheAccessibilityService.java').read_text()
print('OK: interfaz fija, rutas y estados de filtros / limpieza')
