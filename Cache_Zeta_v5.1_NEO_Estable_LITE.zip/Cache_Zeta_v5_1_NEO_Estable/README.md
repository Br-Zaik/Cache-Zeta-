# Caché Zeta v5.1 — NEO Estable

Versión de estabilidad y seguridad sobre la v5. Rediseño **real con código nativo Java Android**, tomando como referencia la interfaz azul oscuro y cian elegida. No incluye una captura pegada como falsa pantalla: cada botón funciona con lógica de Android. Conserva el motor de limpieza de la v4.

## Pantalla principal (sin desplazamiento)

- Cabecera Caché Zeta con logo vectorial Z, Ajustes e Información.
- Tarjeta de caché circular **medida**, nunca un 0 MB inventado; toca la tarjeta para **Analizar**.
- Barra de almacenamiento real (usado/total y porcentaje).
- Todas las apps / Instaladas por mí, como antes.
- Filtros por cache: **Sin filtro**, más de **10 / 50 / 100 MB**. Cuando se eligen apps manualmente, el filtro indica Selección manual.
- Top **5 / 10 / 20 / 50 / Todas**. «Todas» está a la derecha del título.
- Un botón grande **Limpiar caché** y **Seleccionar apps**.
- Barra inferior **Limpieza · Juegos · Historial**.
- Diseño adaptable proporcionalmente a la pantalla mediante filas ponderadas; sin `ScrollView` en `MainActivity`.

## Limpieza segura y permisos

**Permisos:** Datos de uso para medir MB de caché; Accesibilidad para pulsar únicamente «Borrar caché» en Ajustes de cada app. El acceso de medición se pide al tocar el indicador o desde Ajustes; el de Accesibilidad, al empezar si falta. Puedes abrirlos desde ⚙.

La limpieza de varias apps sigue siendo **secuencial**, automatizada y cancelable: Android no ofrece una API pública universal para limpiar inmediatamente la caché privada de todas las apps. Existen pantallas distintas según fabricante e idioma: el motor evita pulsar textos peligrosos y omite pantallas desconocidas.

Si la limpieza se interrumpe, «Seleccionar apps» ofrece **Reanudar**. Los ajustes permiten modificar exclusiones, abrir permisos y volver a analizar. El historial muestra sesiones, no inventa MB liberados. Las cifras medidas pueden cambiar mientras se utiliza el dispositivo.

## Correcciones verificables en v5.1

- Si falta Acceso a datos de uso, un filtro por MB **no inventa el Top**: ofrece limpiar **todo el grupo** sin análisis o conceder el permiso. El botón sigue disponible para elegir la alternativa.
- La comprobación posterior de espacio reducido solo compara apps en las que el servicio pulsó el botón de caché; una app omitida no se considera éxito.
- La reanudación respeta las **exclusiones actuales** y el grupo elegido; si no queda ninguna app, descarta la tarea pendiente.
- La pantalla de almacenamiento debe identificar la app actual antes de pulsar el botón, para no actuar sobre una pantalla ajena; algunos fabricantes sin ese rótulo serán omitidos de forma segura.
- Historial y pantalla de estado muestran por qué se interrumpió una limpieza cuando se conoce la causa.
- El indicador circular distingue **Sin analizar** de **0 MB** y dice **Caché medida**, no «caché total universal».

## Juegos

Panel separado de RAM, batería, temperatura de **batería**, almacenamiento y accesos a juegos favoritos. Puede abrir los ajustes de No molestar. No promete aumentar FPS ni subir la potencia del procesador.

## Compilar APK en GitHub Actions

1. Deja **un único ZIP** en la raíz de tu repositorio `Br-Zaik/Cache-Zeta-` (elimina el ZIP anterior). No es necesario extraerlo.
2. Conserva el workflow existente `.github/workflows/android.yml` en el repositorio.
3. Al subir el ZIP, GitHub Actions debe iniciarse automáticamente. También puedes usar «Run workflow».
4. Si termina en verde, descarga el archivo `app-debug.apk` dentro del artefacto.
5. Prueba primero **Instaladas por mí + Sin filtro + Top 5**, y comprueba manualmente la caché de una app concreta antes y después.

El paquete es **código fuente**, no un APK precompilado. Incluye workflow opcional en el ZIP para un repositorio vacío.

## Compatibilidad y límites

`minSdk 26` (Android 8+), `targetSdk 36`. Interfaz adaptable a diferentes tamaños. **No se garantiza equivalencia píxel a píxel** entre Android y la imagen conceptual, ni funcionamiento en todos los fabricantes sin pruebas físicas. En pantallas muy pequeñas o con tamaños de letra enormes puede variar la distribución. Este entorno no dispone del Android SDK: la compilación y prueba en móvil deben realizarse en GitHub Actions y en dispositivos reales.

La app no tiene anuncios, root ni conexión a Internet. Google Play requiere revisar especialmente `QUERY_ALL_PACKAGES` y el uso de Accesibilidad, consentimiento y políticas actuales antes de publicar. Consulta `PRIVACIDAD.md` y `docs/PRUEBAS_Y_PLAY.md`.

## Alcance real y siguiente validación

- **La app no borra datos de usuario**: automatiza solo el botón exacto de caché en Ajustes, tras consentimiento y con botón de detención.
- Limpiar la caché **no aumenta** los FPS ni la potencia del CPU; el panel Juegos informa sobre RAM, batería, temperatura de batería y espacio libre.
- `StorageStatsManager` puede no medir determinadas aplicaciones. Se muestran como «Sin dato» en vez de 0 MB; no se incluyen en Top/umbrales.
- **Sin garantía de Android universal**: faltan pruebas de interfaz en Samsung, Xiaomi/Redmi/POCO, OPPO/Realme, Vivo, Honor y Pixel.
- El ZIP incluye el código completo. **No está compilado ni firmado aquí**: GitHub Actions generará el APK si su SDK y Gradle finalizan correctamente.
- Si aparece una alerta de seguridad de Android, no desactives Play Protect para continuar sin revisar el APK.
