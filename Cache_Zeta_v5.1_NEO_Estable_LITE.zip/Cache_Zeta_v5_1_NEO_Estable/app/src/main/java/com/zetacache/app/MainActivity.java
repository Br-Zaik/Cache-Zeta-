package com.zetacache.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Pantalla principal fija. No ScrollView: pesos proporcionales que se ajustan a la altura
 * disponible y reservan pantallas independientes para ajustes, juegos y selección.
 * Solo UI; el motor de accesibilidad se conserva sin modificaciones.
 */
public final class MainActivity extends Activity {
    private static final int BG=NeonStyle.BG, PANEL=NeonStyle.PANEL;
    private static final int TEXT=NeonStyle.TEXT, MUTED=NeonStyle.MUTED, MINT=NeonStyle.CYAN;
    private static final String PREF="cache_zeta_lite_v3";
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final List<AppTarget> apps=new ArrayList<>();
    private final Set<String> picked=new HashSet<>();
    private final Set<String> excluded=new HashSet<>();
    private boolean systemApps=false,measured=false,scanning=false,loading=false;
    private boolean awaitingUsage=false,verifyAfter=false,verifying=false;
    private int filter=SelectionRules.MOST_CACHE,limit=10,scanVersion=0,scanDone=0;
    private boolean scanAttempted=false;
    private List<AppTarget> lastStarted=new ArrayList<>();
    private TextView count,permissionText,analysisText,selectedInfo,previewText;
    private TextView resultText,progressText,allChip,userChip,topAll;
    private TextView filterTitle,topTitle,storageDetail,storagePct,headerSubtitle;
    private TextView selectBtn;
    private Button cleanBtn;
    private TextView[] thresholdButtons=new TextView[3],topButtons=new TextView[4];
    private CacheRingView ring;
    private ProgressBar storageProgress;
    private GameInfo deviceInfo;
    private String lastChipSignature="";
    private final Runnable pulse=new Runnable() {
        @Override public void run() {
            refresh();
            ui.postDelayed(this,1200);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if(Build.VERSION.SDK_INT>=30) getWindow().setDecorFitsSystemWindows(false);
        excluded.addAll(prefs().getStringSet("excluded",new HashSet<>()));
        picked.addAll(prefs().getStringSet("picked",new HashSet<>()));
        systemApps=prefs().getBoolean("system",false);
        filter=prefs().getInt("filter",SelectionRules.MOST_CACHE);
        limit=prefs().getInt("limit",10);
        deviceInfo=GameInfo.read(this);
        createLayout();
        loadApps();
    }
    @Override protected void onResume() {
        super.onResume();
        deviceInfo=GameInfo.read(this);
        ui.removeCallbacks(pulse);ui.post(pulse);
        if(!SessionState.running && verifyAfter && !verifying) verifyResults();
        if(!SessionState.running && !scanning && !loading && CacheScanner.hasUsageAccess(this)
                && (!scanAttempted || awaitingUsage)) {
            awaitingUsage=false;analyze();
        }
    }
    @Override protected void onPause(){ui.removeCallbacks(pulse);super.onPause();}
    @Override protected void onDestroy(){worker.shutdownNow();ui.removeCallbacksAndMessages(null);super.onDestroy();}
    private SharedPreferences prefs(){return getSharedPreferences(PREF,MODE_PRIVATE);}

    private void loadApps(){
        if(loading) return;
        loading=true;
        worker.execute(()->{
            List<AppTarget> found;
            try{found=CacheScanner.installed(getApplicationContext());}
            catch(Exception e){found=new ArrayList<>();}
            final List<AppTarget> result=found;
            ui.post(()->{
                if(isFinishing() || isDestroyed()) return;
                apps.clear();apps.addAll(result);
                loading=false;measured=false;scanAttempted=false;
                refresh();
                if(CacheScanner.hasUsageAccess(this)&&!SessionState.running)analyze();
            });
        });
    }
    private void analyze(){
        if(scanning||SessionState.running||loading)return;
        if(!CacheScanner.hasUsageAccess(this)){requestUsage();return;}
        scanning=true;scanDone=0;scanAttempted=true;
        int version=++scanVersion;
        final List<AppTarget> snapshot=new ArrayList<>(apps);
        analysisText.setText("Analizando caché…");refresh();
        worker.execute(()->{
            List<AppTarget> result=CacheScanner.measure(getApplicationContext(),snapshot,
                    (done,total)->ui.post(()->{
                        if(version==scanVersion){scanDone=done;analysisText.setText("Analizando "+done+"/"+total);ring.show(-1,true,total==0?0:done*100/total);}
                    }));
            ui.post(()->{
                if(version!=scanVersion||isFinishing()||isDestroyed())return;
                apps.clear();apps.addAll(result);scanning=false;
                int known=0;
                for(AppTarget item:result)if(item.cacheBytes>=0)known++;
                measured=CacheScanner.hasUsageAccess(this)&&result.size()==snapshot.size()&&known>0;
                analysisText.setText(measured?"Medidas: "+known+" apps":"Sin medición de caché");
                refresh();
            });
        });
    }
    private List<AppTarget> scoped(){
        ArrayList<AppTarget> out=new ArrayList<>();
        for(AppTarget a:apps)if((systemApps||!a.system)&&!excluded.contains(a.packageName))out.add(a);
        return out;
    }
    private List<AppTarget> selected(){
        return SelectionRules.select(scoped(),true,filter,limit,picked,measured);
    }

    private void createLayout(){
        LinearLayout root=vertical();
        root.setBackground(NeonStyle.background(this));
        root.setPadding(dp(14),dp(7),dp(14),dp(7));
        if(Build.VERSION.SDK_INT>=30){
            root.setOnApplyWindowInsetsListener((view,insets)->{
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(dp(14),bars.top+dp(4),dp(14),bars.bottom+dp(5));
                return insets;
            });
        }
        setContentView(root);

        // 1. Cabecera corta, como el diseño elegido.
        LinearLayout header=horizontal();header.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo=new ImageView(this);
        logo.setImageResource(R.drawable.ic_brand);
        logo.setPadding(dp(7),dp(7),dp(7),dp(7));
        logo.setBackground(NeonStyle.gradient(this,new int[]{0xFF08273B,0xFF07192B},13,0xFF00CFE0));
        header.addView(logo,new LinearLayout.LayoutParams(dp(49),dp(49)));
        LinearLayout titles=vertical();titles.setPadding(dp(11),0,0,0);
        TextView name=text("Caché Zeta",23,TEXT,true);name.setSingleLine(true);
        titles.addView(name);
        headerSubtitle=text("Limpieza inteligente",11,MUTED,false);titles.addView(headerSubtitle);
        header.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
        TextView settings=iconButton("⚙","Ajustes y permisos");settings.setOnClickListener(v->showMenu());
        TextView info=iconButton("ⓘ","Información y estado");info.setOnClickListener(v->showInfo());
        header.addView(settings,new LinearLayout.LayoutParams(dp(40),dp(40)));
        LinearLayout.LayoutParams infolp=new LinearLayout.LayoutParams(dp(40),dp(40));infolp.leftMargin=dp(8);
        header.addView(info,infolp);
        slot(root,header,0.94f,0);

        // 2. Tarjeta única: caché medida a la izquierda, almacenamiento real a la derecha.
        LinearLayout hero=horizontal();hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setBackground(NeonStyle.hero(this));
        ring=new CacheRingView(this);
        hero.addView(ring,new LinearLayout.LayoutParams(0,-1,1.04f));
        LinearLayout right=vertical();right.setGravity(Gravity.CENTER_VERTICAL);
        right.setPadding(dp(7),dp(3),dp(14),dp(3));
        TextView storageTitle=text("▤  Almacenamiento",14,TEXT,false);
        storageTitle.setSingleLine(true);right.addView(storageTitle);
        storageProgress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        storageProgress.setMax(100);storageProgress.setProgressTintList(ColorStateList.valueOf(MINT));
        storageProgress.setProgressBackgroundTintList(ColorStateList.valueOf(0xFF163E58));
        LinearLayout.LayoutParams barlp=new LinearLayout.LayoutParams(-1,dp(7));barlp.topMargin=dp(12);
        right.addView(storageProgress,barlp);
        LinearLayout spaceLine=horizontal();spaceLine.setGravity(Gravity.CENTER_VERTICAL);
        storageDetail=text("— / —",11,TEXT,false);
        spaceLine.addView(storageDetail,new LinearLayout.LayoutParams(0,-2,1));
        storagePct=text("—",11,TEXT,false);spaceLine.addView(storagePct);
        LinearLayout.LayoutParams splp=new LinearLayout.LayoutParams(-1,-2);splp.topMargin=dp(8);
        right.addView(spaceLine,splp);
        count=text("Buscando apps…",11,MUTED,false);count.setSingleLine(true);
        LinearLayout.LayoutParams countlp=new LinearLayout.LayoutParams(-1,-2);countlp.topMargin=dp(11);
        right.addView(count,countlp);
        analysisText=text("Sin analizar",10,MUTED,false);analysisText.setSingleLine(true);
        right.addView(analysisText);
        hero.addView(right,new LinearLayout.LayoutParams(0,-1,1.05f));
        hero.setOnClickListener(v->{if(!scanning&&!SessionState.running)analyze();});
        hero.setContentDescription("Analizar y consultar la caché");
        slot(root,hero,2.23f,dp(3));

        // 3. Selector de alcance.
        LinearLayout scopes=horizontal();scopes.setGravity(Gravity.CENTER_VERTICAL);
        allChip=text("▦  Todas",14,TEXT,true);
        userChip=text("▦  Instaladas por mí",13,TEXT,true);
        allChip.setGravity(Gravity.CENTER);userChip.setGravity(Gravity.CENTER);
        scopes.addView(allChip,weightLp(1,0));scopes.addView(userChip,weightLp(1,8));
        allChip.setOnClickListener(v->changeScope(true));
        userChip.setOnClickListener(v->changeScope(false));
        slot(root,scopes,0.90f,dp(6));

        // 4. Filtros, visibles siempre.
        LinearLayout filters=vertical();filters.setPadding(dp(10),dp(5),dp(10),dp(7));
        filters.setBackground(NeonStyle.card(this));
        LinearLayout filterHeader=horizontal();filterHeader.setGravity(Gravity.CENTER_VERTICAL);
        filterTitle=text("▽  Filtro por tamaño (caché)",13,TEXT,true);
        filterTitle.setSingleLine(true);
        filterHeader.addView(filterTitle,new LinearLayout.LayoutParams(0,-1,1));
        TextView noFilter=text("Sin filtro",11,MINT,true);noFilter.setGravity(Gravity.CENTER);
        noFilter.setPadding(dp(5),0,dp(2),0);
        filterHeader.addView(noFilter);
        noFilter.setOnClickListener(v->selectFilter(SelectionRules.MOST_CACHE));
        filters.addView(filterHeader,new LinearLayout.LayoutParams(-1,0,.44f));
        LinearLayout filterRow=horizontal();filterRow.setGravity(Gravity.CENTER_VERTICAL);
        int[] amounts={10,50,100};
        for(int i=0;i<3;i++){
            final int f=i+1;
            TextView item=text(amounts[i]+" MB",14,TEXT,false);item.setGravity(Gravity.CENTER);
            thresholdButtons[i]=item;filterRow.addView(item,weightLp(1,i==0?0:7));
            item.setOnClickListener(v->selectFilter(f));
        }
        filters.addView(filterRow,new LinearLayout.LayoutParams(-1,0,.66f));
        slot(root,filters,1.20f,dp(9));

        // 5. Selector independiente Top N con opción 'Todas'.
        LinearLayout top=vertical();top.setPadding(dp(10),dp(5),dp(10),dp(7));
        top.setBackground(NeonStyle.card(this));
        LinearLayout topHeader=horizontal();topHeader.setGravity(Gravity.CENTER_VERTICAL);
        topTitle=text("▱  Cantidad de apps (Top)",13,TEXT,true);
        topTitle.setSingleLine(true);
        topHeader.addView(topTitle,new LinearLayout.LayoutParams(0,-1,1));
        topAll=text("Todas",11,MINT,true);topAll.setGravity(Gravity.CENTER);
        topAll.setPadding(dp(6),0,dp(2),0);topHeader.addView(topAll);
        topAll.setOnClickListener(v->changeLimit(0));
        top.addView(topHeader,new LinearLayout.LayoutParams(-1,0,.44f));
        LinearLayout topRow=horizontal();topRow.setGravity(Gravity.CENTER_VERTICAL);
        int[] amountsTop={5,10,20,50};
        for(int i=0;i<4;i++){
            final int n=amountsTop[i];
            TextView item=text("Top "+n,12,TEXT,false);item.setGravity(Gravity.CENTER);
            topButtons[i]=item;topRow.addView(item,weightLp(1,i==0?0:6));
            item.setOnClickListener(v->changeLimit(n));
        }
        top.addView(topRow,new LinearLayout.LayoutParams(-1,0,.66f));
        slot(root,top,1.14f,dp(9));

        // 6. Acción principal, sin abrir aplicaciones hasta la confirmación del usuario.
        cleanBtn=new Button(this);
        cleanBtn.setText("✧  Limpiar caché   ›");
        cleanBtn.setTextSize(17);cleanBtn.setAllCaps(false);cleanBtn.setTextColor(0xFF052234);
        cleanBtn.setTypeface(Typeface.DEFAULT,Typeface.BOLD);cleanBtn.setMinHeight(0);
        cleanBtn.setStateListAnimator(null);
        cleanBtn.setBackground(NeonStyle.ripple(NeonStyle.primary(this)));
        cleanBtn.setOnClickListener(v->{
            if(SessionState.running){
                CacheAccessibilityService s=CacheAccessibilityService.instance();if(s!=null)s.cancel();
            }else startCleaning(false);
        });
        slot(root,cleanBtn,0.91f,dp(12));

        // 7. Selección manual, o reanudación visible si queda una cola pendiente.
        selectBtn=text("☷  Seleccionar apps    ›",15,TEXT,true);
        selectBtn.setGravity(Gravity.CENTER);selectBtn.setBackground(NeonStyle.ripple(NeonStyle.secondary(this)));
        selectBtn.setOnClickListener(v->{
            if(!SessionState.running && CleaningCheckpoint.hasRemaining(this)) showPendingActions();
            else chooseApps();
        });
        slot(root,selectBtn,0.82f,dp(9));

        // 8. Pestañas sin desplazamiento. Juegos e historial se abren aparte.
        LinearLayout nav=horizontal();nav.setGravity(Gravity.CENTER_VERTICAL);
        nav.setPadding(dp(4),dp(3),dp(4),dp(3));
        nav.setBackground(NeonStyle.gradient(this,new int[]{0xFF09273C,0xFF07182C},17,0xFF185575));
        TextView cleanTab=navItem("⌂","Limpieza",true);
        TextView gamesTab=navItem("♧","Juegos",false);
        TextView historyTab=navItem("◷","Historial",false);
        nav.addView(cleanTab,weightLp(1,0));nav.addView(gamesTab,weightLp(1,4));
        nav.addView(historyTab,weightLp(1,4));
        cleanTab.setOnClickListener(v->showInfo());
        gamesTab.setOnClickListener(v->startActivity(new Intent(this,GameActivity.class)));
        historyTab.setOnClickListener(v->showHistory());
        slot(root,nav,0.98f,dp(12));

        // Etiquetas internas de estado; accesibles desde ⓘ, sin ocupar pantalla principal.
        permissionText=text("",12,MUTED,false);
        selectedInfo=text("",12,TEXT,false);
        previewText=text("",12,MUTED,false);
        progressText=text("",12,TEXT,false);
        resultText=text("",12,MUTED,false);
        refresh();
    }

    private void changeScope(boolean all){
        systemApps=all;prefs().edit().putBoolean("system",all).apply();refresh();
    }
    private void selectFilter(int newFilter){
        filter=newFilter;prefs().edit().putInt("filter",filter).apply();refresh();
    }
    private void changeLimit(int n){
        limit=n;prefs().edit().putInt("limit",n).apply();refresh();
    }
    private void showMenu(){
        String[] actions={"Analizar caché","Permiso de medición (MB)","Permiso de Accesibilidad",
                "Elegir aplicaciones","Excluir aplicaciones","Reanudar limpieza","Historial"};
        new AlertDialog.Builder(this).setTitle("Caché Zeta · Ajustes")
                .setItems(actions,(d,i)->{
                    switch(i){
                        case 0:analyze();break;
                        case 1:requestUsage();break;
                        case 2:requestAccessibility();break;
                        case 3:chooseApps();break;
                        case 4:chooseExclusions();break;
                        case 5:startCleaning(true);break;
                        default:showHistory();break;
                    }
                }).setNegativeButton("Cerrar",null).show();
    }
    private void showInfo(){
        boolean accessible=CacheAccessibilityService.instance()!=null;
        List<AppTarget> items=selected();
        String status=SessionState.running?"Limpieza "+SessionState.index+"/"+SessionState.total
                +"\n"+SessionState.appName:"En espera";
        new AlertDialog.Builder(this).setTitle("Estado de Caché Zeta")
                .setMessage("Apps encontradas: "+apps.size()+"\nSeleccionadas: "+items.size()
                        +"\nMedición MB: "+(measured?"Lista":"Pendiente")
                        +"\nAccesibilidad: "+(accessible?"Activa":"Pendiente")
                        +"\n\n"+status+"\n"+SessionState.result)
                .setNeutralButton("Analizar",(d,w)->analyze())
                .setNegativeButton("Cerrar",null)
                .setPositiveButton(accessible?"Detener":"Permisos",(d,w)->{
                    if(SessionState.running){
                        CacheAccessibilityService s=CacheAccessibilityService.instance();if(s!=null)s.cancel();
                    }else if(!accessible)requestAccessibility();
                }).show();
    }
    private void showHistory(){
        new AlertDialog.Builder(this).setTitle("Historial de limpiezas")
                .setMessage(HistoryStore.get(this)).setPositiveButton("Cerrar",null).show();
    }
    private void showPendingActions(){
        new AlertDialog.Builder(this).setTitle("Limpieza pendiente")
                .setItems(new String[]{"Reanudar limpieza","Elegir otras apps"},(d,i)->{
                    if(i==0)startCleaning(true);else chooseApps();
                }).show();
    }
    private TextView navItem(String glyph,String name,boolean current){
        TextView tab=text(glyph+"\n"+name,11,current?MINT:MUTED,current);
        tab.setGravity(Gravity.CENTER);tab.setLineSpacing(0,0.94f);
        tab.setBackground(current?NeonStyle.chip(this,true):NeonStyle.gradient(this,
                new int[]{0xFF092438,0xFF092438},14,0));
        return tab;
    }
    private TextView iconButton(String glyph,String description){
        TextView icon=text(glyph,22,TEXT,false);
        icon.setGravity(Gravity.CENTER);icon.setContentDescription(description);
        icon.setBackground(NeonStyle.ripple(NeonStyle.secondary(this)));
        return icon;
    }
    private void slot(LinearLayout root,View view,float weight,int topPx){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,0,weight);
        lp.topMargin=topPx;root.addView(view,lp);
    }
    private LinearLayout.LayoutParams weightLp(float weight,int marginDp){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,weight);
        lp.leftMargin=dp(marginDp);return lp;
    }
    private void showFilters() {
        String[] labels={"Más caché primero","Más de 10 MB","Más de 50 MB","Más de 100 MB","Elegir aplicaciones"};
        new AlertDialog.Builder(this).setTitle("Filtro de limpieza")
                .setSingleChoiceItems(labels, filter, (dialog, which) -> {
                    filter=which; prefs().edit().putInt("filter",which).apply();
                    dialog.dismiss(); refresh();
                    if (which == SelectionRules.MANUAL) chooseApps();
                }).setNegativeButton("Cancelar",null).show();
    }

    private void chooseApps() {
        if (apps.isEmpty()) { msg("Primero espera a que se detecten las apps."); return; }
        List<AppTarget> candidates = scoped();
        candidates.sort((a,b) -> Long.compare(b.cacheBytes,a.cacheBytes));
        String[] names = new String[candidates.size()];
        boolean[] selected = new boolean[candidates.size()];
        Set<String> working = new HashSet<>(picked);
        for (int i=0;i<candidates.size();i++) {
            AppTarget app = candidates.get(i);
            names[i]=app.label + (app.cacheBytes >= 0 ? " · "+CacheScanner.size(app.cacheBytes) : "");
            selected[i]=working.contains(app.packageName);
        }
        new AlertDialog.Builder(this).setTitle("Elegir aplicaciones")
                .setMultiChoiceItems(names,selected,(d,which,checked)-> {
                    String pkg=candidates.get(which).packageName;
                    if (checked) working.add(pkg); else working.remove(pkg);
                })
                .setNeutralButton("Ninguna",(d,w)-> { picked.clear(); filter=SelectionRules.MANUAL;
                    prefs().edit().putInt("filter",filter)
                            .putStringSet("picked",new HashSet<>(picked)).apply(); refresh(); })
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Guardar",(d,w)-> {
                    picked.clear(); picked.addAll(working);
                    filter=SelectionRules.MANUAL;
                    prefs().edit().putInt("filter",filter)
                            .putStringSet("picked",new HashSet<>(picked)).apply(); refresh();
                }).show();
    }

    private void chooseExclusions() {
        if (apps.isEmpty()) { msg("Todavía no hay aplicaciones."); return; }
        ArrayList<AppTarget> candidates = new ArrayList<>(apps);
        candidates.sort(Comparator.comparing(a->a.label.toLowerCase(Locale.ROOT)));
        String[] names = new String[candidates.size()];
        boolean[] values = new boolean[candidates.size()];
        Set<String> working = new HashSet<>(excluded);
        for(int i=0;i<candidates.size();i++) {
            names[i]=candidates.get(i).label;
            values[i]=working.contains(candidates.get(i).packageName);
        }
        new AlertDialog.Builder(this).setTitle("Nunca limpiar estas apps")
                .setMultiChoiceItems(names,values,(d,index,checked)-> {
                    String pkg=candidates.get(index).packageName;
                    if (checked) working.add(pkg); else working.remove(pkg);
                }).setNegativeButton("Cancelar",null)
                .setPositiveButton("Guardar",(d,w)-> {
                    excluded.clear(); excluded.addAll(working);
                    prefs().edit().putStringSet("excluded",new HashSet<>(excluded)).apply(); refresh();
                }).show();
    }

    private void refresh(){
        if(count==null)return;
        boolean running=SessionState.running;
        boolean accessible=CacheAccessibilityService.instance()!=null;
        List<AppTarget> scopedApps=scoped();
        List<AppTarget> chosen=selected();
        int nonzero=0;
        for(AppTarget a:scopedApps)if(a.cacheBytes>0)nonzero++;
        count.setText(chosen.size()+" seleccionadas · "+scopedApps.size()+" apps");
        permissionText.setText((accessible?"Accesibilidad activa":"Accesibilidad pendiente")+
                " · "+(measured?"MB medidos":"MB pendientes"));
        if(!scanning)analysisText.setText(measured?nonzero+" apps con caché":"Toca aquí para analizar");
        long sum=SelectionRules.totalKnownCache(scopedApps);
        ring.show(measured?sum:-1,scanning,scanning?(apps.isEmpty()?0:scanDone*100/apps.size()):0);
        if(deviceInfo!=null && deviceInfo.storageTotal>0 && deviceInfo.storageAvailable>=0){
            long used=deviceInfo.storageTotal-deviceInfo.storageAvailable;
            int percent=Math.max(0,Math.min(100,(int)Math.round(used*100.0/deviceInfo.storageTotal)));
            storageProgress.setProgress(percent);
            storageDetail.setText(GameInfo.formatGiB(used)+" / "+GameInfo.formatGiB(deviceInfo.storageTotal));
            storagePct.setText(percent+"%");
        }else{storageProgress.setProgress(0);storageDetail.setText("Sin dato");storagePct.setText("—");}
        String chipSignature=systemApps+"/"+filter+"/"+limit+"/"+picked.size();
        if(!chipSignature.equals(lastChipSignature)){
            lastChipSignature=chipSignature;
            allChip.setBackground(NeonStyle.ripple(NeonStyle.scope(this,systemApps)));
            userChip.setBackground(NeonStyle.ripple(NeonStyle.scope(this,!systemApps)));
            allChip.setTextColor(systemApps?0xFF052C3B:TEXT);
            userChip.setTextColor(!systemApps?0xFF052C3B:TEXT);
            if(filter==SelectionRules.MANUAL)filterTitle.setText("▽  Selección manual ("+picked.size()+")");
            else filterTitle.setText("▽  Filtro por tamaño (caché)");
            for(int i=0;i<thresholdButtons.length;i++){
                boolean active=filter==i+1;
                thresholdButtons[i].setBackground(NeonStyle.ripple(NeonStyle.chip(this,active)));
                thresholdButtons[i].setTextColor(active?TEXT:MUTED);
            }
            int[] tops={5,10,20,50};
            for(int i=0;i<topButtons.length;i++){
                boolean active=limit==tops[i];
                topButtons[i].setBackground(NeonStyle.ripple(NeonStyle.chip(this,active)));
                topButtons[i].setTextColor(active?TEXT:MUTED);
            }
            topAll.setTextColor(limit==0?0xFF21FFF2:MUTED);
            topAll.setText(limit==0?"✓ Todas":"Todas");
        }
        boolean busy=running||loading||scanning;
        boolean canOfferUnmeasured = !measured && filter != SelectionRules.MANUAL
                && !scopedApps.isEmpty();
        cleanBtn.setEnabled(!loading&&!scanning&&(running||!chosen.isEmpty()||canOfferUnmeasured));
        cleanBtn.setAlpha(cleanBtn.isEnabled()?1f:0.72f);
        cleanBtn.setText(running?"■  Detener limpieza":"✧  Limpiar caché    ›");
        boolean pending=!running&&CleaningCheckpoint.hasRemaining(this);
        selectBtn.setText(pending?"↻  Reanudar o seleccionar    ›":"☷  Seleccionar apps    ›");
        selectedInfo.setText(chosen.size()+" apps listas");
        previewText.setText(measured?CacheScanner.size(SelectionRules.totalKnownCache(chosen)):"Sin medición");
        progressText.setText(running?"Procesando "+SessionState.index+"/"+SessionState.total:"En espera");
        resultText.setText(running?SessionState.appName:SessionState.result);
    }
    private void startCleaning(boolean resume) {
        if (SessionState.running||scanning||loading) return;
        CacheAccessibilityService service=CacheAccessibilityService.instance();
        if (service==null) { requestAccessibility(); return; }
        if (!resume && filter!=SelectionRules.MANUAL && !measured) {
            new AlertDialog.Builder(this).setTitle("Faltan los MB")
                    .setMessage("Para ordenar por caché necesitas el permiso de datos de uso. "
                            + "Puedes otorgarlo o limpiar sin orden de tamaño.")
                    .setNegativeButton("Cancelar",null)
                    .setNeutralButton("Limpiar todo el grupo sin analizar",(d,w)-> confirmStart(false))
                    .setPositiveButton("Dar permiso",(d,w)->requestUsage()).show();
            return;
        }
        if (resume) {
            // Respetar las exclusiones actuales incluso en una sesión antigua guardada.
            List<AppTarget> remaining=new ArrayList<>();
            for (AppTarget app : CleaningCheckpoint.remaining(this)) {
                if (!excluded.contains(app.packageName) && (systemApps || !app.system))
                    remaining.add(app);
            }
            if (remaining.isEmpty()) {
                CleaningCheckpoint.clear(this);
                msg("No hay aplicaciones pendientes permitidas."); refresh(); return;
            }
            new AlertDialog.Builder(this).setTitle("Reanudar limpieza")
                    .setMessage("Se volverá a abrir la app donde quedó la limpieza. Solo se pulsará Borrar caché.")
                    .setNegativeButton("Cancelar",null)
                    .setPositiveButton("Reanudar",(d,w)-> {
                        CleaningCheckpoint.start(this, remaining);
                        lastStarted=new ArrayList<>(remaining); verifyAfter=CacheScanner.hasUsageAccess(this);
                        service.startCleaning(new ArrayList<>(remaining)); refresh();
                    }).show();
        } else confirmStart(true);
    }

    private void confirmStart(boolean analyzed) {
        CacheAccessibilityService service=CacheAccessibilityService.instance();
        if(service==null) {requestAccessibility();return;}
        // Sin permiso de uso no se puede conocer el Top N ni filtrar por MB.
        // La alternativa ofrecida recorre TODO el grupo, sin fingir un ranking por caché.
        List<AppTarget> targets = analyzed ? selected() :
                SelectionRules.select(scoped(),true,SelectionRules.MOST_CACHE,0,picked,false);
        if (targets.isEmpty()) { msg("No hay aplicaciones para limpiar."); return; }
        String fallback = analyzed ? "" :
                "Sin medición de MB: se recorrerán todas las apps del grupo, "
                + "sin filtros de tamaño ni Top N.\n\n";
        new AlertDialog.Builder(this).setTitle("Limpiar "+targets.size()+" aplicaciones")
                .setMessage(fallback+"Caché Zeta abrirá los ajustes automáticamente, una app a la vez. "
                        +"Solo pulsará Borrar caché. Mantén el móvil desbloqueado.\n\n"
                        +"Podrás detener y reanudar el recorrido.")
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Empezar",(d,w)-> {
                    CleaningCheckpoint.start(this,targets);
                    lastStarted=new ArrayList<>(targets); verifyAfter=measured; verifying=false;
                    service.startCleaning(new ArrayList<>(targets)); refresh();
                }).show();
    }

    private void verifyResults() {
        if (!CacheScanner.hasUsageAccess(this)||lastStarted.isEmpty()) { verifyAfter=false; return; }
        verifyAfter=false; verifying=true;
        final List<AppTarget> before=new ArrayList<>();
        // No atribuir ahorros a apps omitidas ni a cambios ajenos a nuestra limpieza.
        Set<String> clicked=SessionState.clickedPackages();
        for (AppTarget item : lastStarted) if (clicked.contains(item.packageName)) before.add(item);
        if (before.isEmpty()) { verifying=false; return; }
        worker.execute(()-> {
            List<AppTarget> after=CacheScanner.measure(getApplicationContext(),before,null);
            Map<String,Long> afterCache=new HashMap<>();
            for(AppTarget app:after) afterCache.put(app.packageName,app.cacheBytes);
            long reduced=0; int compared=0;
            for(AppTarget app:before) {
                Long end=afterCache.get(app.packageName);
                if(app.cacheBytes>=0&&end!=null&&end>=0) {
                    reduced+=Math.max(0,app.cacheBytes-end); compared++;
                }
            }
            final long bytes=reduced; final int valid=compared;
            ui.post(()-> {
                verifying=false;
                if (isFinishing() || isDestroyed()) return;
                if (valid>0) SessionState.result += "\nReducción observada: "+CacheScanner.size(bytes)
                        +" en "+valid+" apps pulsadas y medidas. Puede variar por uso posterior.";
                refresh(); analyze();
            });
        });
    }

    private void requestUsage() {
        new AlertDialog.Builder(this).setTitle("Acceso a datos de uso")
                .setMessage("Permite consultar cuántos MB de caché tiene cada app. "
                        +"Se usa únicamente en tu teléfono para ordenar y filtrar. "
                        +"No recopila ni envía datos por Internet.\n\n"
                        +"Activa Caché Zeta en la pantalla que abrirá Android.")
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Continuar",(d,w)-> {
                    awaitingUsage=true;
                    try { startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); }
                    catch(Exception e){msg("No se pudieron abrir los permisos de uso.");}
                }).show();
    }

    private void requestAccessibility() {
        if (CacheAccessibilityService.instance()!=null) { msg("Accesibilidad ya está activada."); return; }
        new AlertDialog.Builder(this).setTitle("Permiso de Accesibilidad")
                .setMessage("Solo cuando pulses Limpiar caché, el servicio leerá los controles de "
                        +"Ajustes para abrir Almacenamiento y pulsar Borrar caché. "
                        +"Puede ver la pantalla según el aviso de Android, pero no se usa para leer "
                        +"mensajes o contraseñas, ni se transmiten datos.\n\n"
                        +"Podrás detener el recorrido y desactivar el permiso cuando quieras.")
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Acepto",(d,w)-> {
                    try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
                    catch(Exception e){msg("No se pudieron abrir los ajustes de Accesibilidad.");}
                }).show();
    }

    private void msg(String message){new AlertDialog.Builder(this).setMessage(message).setPositiveButton("Aceptar",null).show();}
    private TextView text(String str,int sp,int color,boolean bold){
        TextView t=new TextView(this);t.setText(str);t.setTextSize(sp);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }
    private LinearLayout vertical(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout horizontal(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);return v;}
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
