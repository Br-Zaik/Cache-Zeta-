package com.zetacache.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;

/** Fondos con degradados y bordes vectoriales. No requiere imágenes ni librerías. */
public final class NeonStyle {
    public static final int BG=0xFF061425;
    public static final int PANEL=0xFF0B2238;
    public static final int BLUE=0xFF0D3150;
    public static final int TEXT=0xFFF5FAFF;
    public static final int MUTED=0xFFACC1D4;
    public static final int CYAN=0xFF09E9E5;
    public static final int TEAL=0xFF11DCC7;
    public static final int BORDER=0xFF266880;
    private NeonStyle() {}
    public static GradientDrawable background(Context c) {
        return gradient(c,new int[]{0xFF03101E,0xFF07243A,0xFF071426},0,0);
    }
    public static GradientDrawable hero(Context c) {
        return gradient(c,new int[]{0xFF0A3C52,0xFF0C2A46,0xFF071B31},18,BORDER);
    }
    public static GradientDrawable card(Context c) {
        return gradient(c,new int[]{0xFF0C2A41,0xFF0A2036},17,0xFF24566E);
    }
    public static GradientDrawable chip(Context c, boolean selected) {
        return gradient(c,selected?new int[]{0xFF076A7C,0xFF09B4B7,0xFF075770}:
                new int[]{0xFF112B44,0xFF0B1F35},13,selected?CYAN:BORDER);
    }
    public static GradientDrawable scope(Context c,boolean selected) {
        return gradient(c,selected?new int[]{0xFF0AD5D4,0xFF018F9F}:
                new int[]{0xFF102E49,0xFF172D45},14,selected?0xFF76FFFF:0xFF28536F);
    }
    public static GradientDrawable primary(Context c) {
        return gradient(c,new int[]{0xFF20F4E4,0xFF04CDBD,0xFF04DFC9},18,0xFF4FFFF1);
    }
    public static GradientDrawable secondary(Context c) {
        return gradient(c,new int[]{0xFF0B3249,0xFF092138},17,0xFF298EA4);
    }
    public static GradientDrawable gradient(Context c,int[] colors,int radius,int border) {
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,colors);
        d.setCornerRadius(c.getResources().getDisplayMetrics().density*radius);
        if(border!=0) d.setStroke(Math.max(1,Math.round(c.getResources().getDisplayMetrics().density)),border);
        return d;
    }
    public static RippleDrawable ripple(android.graphics.drawable.Drawable d) {
        return new RippleDrawable(ColorStateList.valueOf(0x3FFFFFFF),d,null);
    }
}
