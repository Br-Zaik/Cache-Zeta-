package com.zetacache.app;

import android.content.*;
import android.database.Cursor;
import android.graphics.*;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.LruCache;
import android.util.Size;
import android.widget.ImageView;
import java.io.*;
import java.util.concurrent.*;

final class MediaPictures {
    private static final LruCache<String,Bitmap> cache=new LruCache<String,Bitmap>(6*1024*1024){
        protected int sizeOf(String key,Bitmap bitmap){return bitmap.getByteCount();}
    };
    private static final ThreadPoolExecutor pool=new ThreadPoolExecutor(2,2,20,TimeUnit.SECONDS,
            new LinkedBlockingQueue<>(64),new ThreadPoolExecutor.DiscardOldestPolicy());
    static Bitmap thumbnail(Context c,Uri uri,int kind)throws IOException{
        if(Build.VERSION.SDK_INT>=29)return c.getContentResolver().loadThumbnail(uri,new Size(240,240),null);
        long id=ContentUris.parseId(uri);
        return kind==0?MediaStore.Images.Thumbnails.getThumbnail(c.getContentResolver(),id,1,null):
                MediaStore.Video.Thumbnails.getThumbnail(c.getContentResolver(),id,1,null);
    }
    static Bitmap photo(Context c,Uri uri)throws IOException{
        if(Build.VERSION.SDK_INT>=28)return ImageDecoder.decodeBitmap(ImageDecoder.createSource(c.getContentResolver(),uri),(dec,info,source)->{
            Size size=info.getSize();dec.setTargetSampleSize(Math.max(1,(Math.max(size.getWidth(),size.getHeight())+1199)/1200));
        });
        BitmapFactory.Options opts=new BitmapFactory.Options();opts.inJustDecodeBounds=true;
        try(InputStream in=DuplicateIndex.open(c.getContentResolver(),uri)){BitmapFactory.decodeStream(in,null,opts);}
        opts.inSampleSize=1;while(Math.max(opts.outWidth,opts.outHeight)/opts.inSampleSize>1600)opts.inSampleSize*=2;
        opts.inJustDecodeBounds=false;
        try(InputStream in=DuplicateIndex.open(c.getContentResolver(),uri)){return BitmapFactory.decodeStream(in,null,opts);}
    }
    static void clear(ImageView view){
        if(view.getTag() instanceof Runnable)pool.remove((Runnable)view.getTag());
        view.setTag(null);view.setImageDrawable(null);
    }
    interface Read {Bitmap load()throws IOException;}
    static void bind(ImageView view,String key,Read source){
        clear(view);Bitmap existing=cache.get(key);
        if(existing!=null){view.setImageBitmap(existing);return;}
        Runnable work=new Runnable(){public void run(){
            try{
                Bitmap b=source.load();if(b==null)return;
                if(b.getByteCount()<1024*1024)cache.put(key,b);
                view.post(()->{if(view.getTag()==this)view.setImageBitmap(b);});
            }catch(IOException|RuntimeException ignored){}
        }};
        view.setTag(work);pool.execute(work);
    }
    static void archive(Context c,String digest,DuplicateIndex.Item item,long session){
        if(item.kind==2)return;
        android.database.sqlite.SQLiteDatabase db=ResultsDb.get(c).getWritableDatabase();
        try{
            boolean exists;
            try(Cursor q=db.rawQuery("SELECT 1 FROM previews WHERE id=?",new String[]{digest})){exists=q.moveToFirst();}
            if(!exists){
                Bitmap b=thumbnail(c,item.uri,item.kind);if(b==null)return;
                Bitmap small=android.media.ThumbnailUtils.extractThumbnail(b,192,192);
                ByteArrayOutputStream out=new ByteArrayOutputStream();
                if(!small.compress(Bitmap.CompressFormat.JPEG,75,out))return;
                db.execSQL("INSERT OR IGNORE INTO previews VALUES(?,?)",new Object[]{digest,out.toByteArray()});
            }
            db.execSQL("INSERT OR REPLACE INTO detail_previews VALUES(?,?,?)",new Object[]{session,item.doc,digest});
        }catch(IOException|RuntimeException ignored){}
    }
    static Bitmap archived(Context c,String key){
        try(Cursor q=ResultsDb.get(c).getReadableDatabase().rawQuery("SELECT jpeg FROM previews WHERE id=?",new String[]{key})){
            if(!q.moveToFirst())return null;
            byte[] data=q.getBlob(0);return BitmapFactory.decodeByteArray(data,0,data.length);
        }
    }
}
