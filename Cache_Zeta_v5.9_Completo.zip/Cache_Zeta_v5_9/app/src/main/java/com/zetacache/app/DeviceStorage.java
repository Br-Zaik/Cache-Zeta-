package com.zetacache.app;

import android.Manifest.permission;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteStatement;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;
import java.io.File;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Locale;
import java.util.TreeSet;

final class DeviceStorage {
    private static boolean granted(Context c,String name){
        return c.checkSelfPermission(name)==PackageManager.PERMISSION_GRANTED;
    }
    static boolean manager(){return Build.VERSION.SDK_INT>=30 && Environment.isExternalStorageManager();}
    static boolean partial(Context c,int kind){
        return kind<2 && Build.VERSION.SDK_INT>=34 && !manager() && !granted(c,mediaPermission(kind))
                && granted(c,permission.READ_MEDIA_VISUAL_USER_SELECTED);
    }
    static String mediaPermission(int kind){return kind==0?permission.READ_MEDIA_IMAGES:permission.READ_MEDIA_VIDEO;}
    static boolean allowed(Context c,int kind){
        if(manager())return true;
        if(kind==2 && Build.VERSION.SDK_INT>=30)return false;
        if(Build.VERSION.SDK_INT>=33)return granted(c,mediaPermission(kind))||partial(c,kind);
        return granted(c,permission.READ_EXTERNAL_STORAGE);
    }
    static String scope(Context c,int kind){
        if(!allowed(c,kind))return "";
        TreeSet<String> mounted=new TreeSet<>();
        for(StorageVolume volume:c.getSystemService(StorageManager.class).getStorageVolumes()){
            if(isMounted(volume))mounted.add(volume.isPrimary()?"primary":String.valueOf(volume.getUuid()));
        }
        if(kind<2 && Build.VERSION.SDK_INT>=30){
            for(String name:MediaStore.getExternalVolumeNames(c))mounted.add(name+"="+MediaStore.getVersion(c,name));
        }
        return "device2/"+mounted+"/"+(partial(c,kind)?"limited":"full");
    }
    private static boolean isMounted(StorageVolume v){
        return Environment.MEDIA_MOUNTED.equals(v.getState())||Environment.MEDIA_MOUNTED_READ_ONLY.equals(v.getState());
    }
    private static String label(Context c,StorageVolume v){
        if(v==null)return "Almacenamiento";
        return v.isPrimary()?"Memoria interna":v.getDescription(c);
    }
    private static File rootFor(Context c,StorageVolume volume){
        if(Build.VERSION.SDK_INT>=30)return volume.getDirectory();
        if(volume.isPrimary())return Environment.getExternalStorageDirectory();
        StorageManager sm=c.getSystemService(StorageManager.class);
        for(File dir:c.getExternalFilesDirs(null)){
            if(dir==null || !volume.equals(sm.getStorageVolume(dir)))continue;
            String suffix="/Android/data/"+c.getPackageName()+"/files";
            String path=dir.getAbsolutePath();
            if(path.endsWith(suffix))return new File(path.substring(0,path.length()-suffix.length()));
        }
        return null;
    }
    static int enumerate(Context c,int kind,IdenticalFiles.Cancel cancel,SQLiteStatement save,ScanProgress live){
        return kind==2?documents(c,cancel,save,live):gallery(c,kind,cancel,save,live);
    }
    private static int gallery(Context c,int kind,IdenticalFiles.Cancel cancel,SQLiteStatement save,ScanProgress live){
        boolean scoped=Build.VERSION.SDK_INT>=29;
        Iterable<String> names=scoped?MediaStore.getExternalVolumeNames(c):java.util.Collections.singleton("external");
        StorageManager sm=c.getSystemService(StorageManager.class);
        List<StorageVolume> volumes=sm.getStorageVolumes();
        Map<String,String> legacyRoots=new LinkedHashMap<>();
        if(!scoped)for(StorageVolume v:volumes){
            File root=rootFor(c,v);
            if(root!=null)legacyRoots.put(root.getPath()+"/",label(c,v));
        }
        for(String volume:names){
            Uri collection=kind==0?MediaStore.Images.Media.getContentUri(volume):MediaStore.Video.Media.getContentUri(volume);
            String[] cols={"_id","_display_name","_size",Build.VERSION.SDK_INT>=30?"generation_modified":"date_modified",scoped?"relative_path":"_data"};
            String volumeName="Almacenamiento "+volume;
            if(scoped)for(StorageVolume v:volumes){
                if((v.isPrimary() && "external_primary".equals(volume))||volume.equalsIgnoreCase(v.getUuid())){
                    volumeName=label(c,v);break;
                }
            }
            try(Cursor q=c.getContentResolver().query(collection,cols,"_size>0"+(scoped?" AND is_pending=0":"")
                    +(Build.VERSION.SDK_INT>=30?" AND is_trashed=0":""),null,null)){
                if(q==null)throw new IllegalStateException("Sin catálogo multimedia");
                while(q.moveToNext()){
                    IdenticalFiles.check(cancel);
                    String name=q.getString(1),relative=q.getString(4);
                    Uri uri=ContentUris.withAppendedId(collection,q.getLong(0));
                    String path;
                    if(scoped)path=volumeName+" / "+(relative==null?"":relative)+name;
                    else if(relative!=null){
                        path=relative;
                        for(Map.Entry<String,String> root:legacyRoots.entrySet())if(relative.startsWith(root.getKey())){
                            path=root.getValue()+" / "+relative.substring(root.getKey().length());break;
                        }
                    }else path="Almacenamiento / "+name;
                    live.found(path);
                    insert(save,kind,uri,name,path,q.getLong(2),q.getLong(3));
                }
            }
        }
        return 0;
    }
    private static int documents(Context c,IdenticalFiles.Cancel cancel,SQLiteStatement save,ScanProgress live){
        int missed=0;
        for(StorageVolume v:c.getSystemService(StorageManager.class).getStorageVolumes()){
            if(!isMounted(v))continue;
            File root=rootFor(c,v);
            if(root==null){missed++;continue;}
            String prefix=label(c,v)+" / ";
            live.location=prefix;
            missed+=StorageDocuments.walk(root,cancel,f->{
                live.found(f.getPath());
                String name=f.getName();int dot=name.lastIndexOf('.');
                String mime=dot<0?null:MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substring(dot+1).toLowerCase(Locale.ROOT));
                if(DuplicateIndex.kind(mime)==2){
                    String relative=f.getPath().substring(root.getPath().length()+1);
                    insert(save,2,Uri.fromFile(f),name,prefix+relative,f.length(),f.lastModified());
                }
            });
        }
        return missed;
    }
    private static void insert(SQLiteStatement save,int kind,Uri uri,String name,String path,long size,long modified){
        save.bindLong(1,kind);save.bindString(2,uri.toString());save.bindString(3,uri.toString());
        save.bindString(4,name==null?uri.getLastPathSegment():name);save.bindLong(5,size);
        save.bindLong(6,modified);save.bindString(7,path);save.executeInsert();
    }
}
