package com.zetacache.app;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.net.Uri;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Index of accessible mounted storage. One low-priority worker for all media types. */
final class DuplicateIndex {
    static final String[] TITLES={"Fotos","Videos","Archivos"};
    static final int ALL=-1;
    static final ExecutorService worker=Executors.newSingleThreadExecutor(r->new Thread(()->{
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);r.run();
    },"Indice local"));
    private static final AtomicInteger token=new AtomicInteger();
    static volatile String progress="";
    static volatile ScanProgress live;
    static final String EVENT="com.zetacache.app.INDEX_CHANGED";
    static synchronized void cancel(){token.incrementAndGet();live=null;}
    static SharedPreferences prefs(Context c){return c.getSharedPreferences("duplicate_index",Context.MODE_PRIVATE);}
    static final class Item {
        final String doc,name,path; final Uri uri;final long size,mtime;final int kind;
        Item(String id,Uri u,String n,String p,long s,long m,int k){doc=id;uri=u;name=n;path=p;size=s;mtime=m;kind=k;}
        @Override public String toString(){return name+"\n"+path;}
    }
    static final class Family {
        final String digest;
        final List<Item> items=new ArrayList<>();
        Family(String digest){this.digest=digest;}
        Item keeper(Set<String> marks){
            for(Item item:items)if(!marks.contains(item.doc))return item;
            return null;
        }
        void markCopies(Set<String> marks){
            Item keep=keeper(marks);
            if(keep==null){keep=items.get(0);marks.remove(keep.doc);}
            for(Item item:items)if(item!=keep)marks.add(item.doc);
        }
        boolean toggle(Item item,Set<String> marks){
            if(marks.remove(item.doc))return true;
            marks.add(item.doc);
            if(keeper(marks)!=null)return true;
            marks.remove(item.doc);return false;
        }
    }
    static int kind(String mime){
        if(mime!=null&&mime.startsWith("image/"))return 0;
        if(mime!=null&&mime.startsWith("video/"))return 1;return 2;
    }
    private static final int[] queued={-1,-1,-1};
    static synchronized boolean pending(int type){return queued[type]==token.get();}
    static synchronized void focus(Context c,int type,boolean force){
        boolean other=false;
        for(int i=0;i<3;i++)if(i!=type && pending(i))other=true;
        if(other||force)cancel();
        scan(c,type,force);
    }
    static synchronized void scan(Context context,int requested,boolean force){
        Context c=context.getApplicationContext();
        if(SessionState.running)return;
        int generation=token.get();
        for(int k=0;k<TITLES.length;k++){
            if((requested!=ALL&&requested!=k)||queued[k]==generation||!DeviceStorage.allowed(c,k))continue;
            final int type=k;queued[k]=generation;
            worker.execute(()->{
                boolean published=false;
                try{
                    IdenticalFiles.Cancel stop=()->generation!=token.get()||SessionState.running;
                    IdenticalFiles.check(stop);
                    String scope=DeviceStorage.scope(c,type);
                    if(scope.isEmpty())return;
                    if(!force && scope.equals(prefs(c).getString("scope"+type,"")) &&
                            CacheSnapshot.fresh(prefs(c).getLong("time"+type,0)))return;
                    progress="Buscando "+TITLES[type].toLowerCase(Locale.ROOT)+"…";
                    ScanProgress run=new ScanProgress(type,scope);
                    live=run;
                    index(c,type,scope,stop,run);published=true;
                    live=null;
                }catch(CancellationException e){live=null;progress="Análisis pausado";}
                catch(RuntimeException e){live=null;android.util.Log.e("DuplicateIndex","Error de análisis",e);progress="No se pudo analizar "+TITLES[type].toLowerCase(Locale.ROOT);}
                finally{
                    synchronized(DuplicateIndex.class){
                        if(queued[type]==generation)queued[type]=-1;
                    }
                    if(generation==token.get())changed(c,type,published);
                }
            });
        }
    }
    private static void changed(Context c,int type,boolean published){c.sendBroadcast(new Intent(EVENT).putExtra("published",published).putExtra("kind",type).setPackage(c.getPackageName()));}
    private static void index(Context c,int type,String scope,IdenticalFiles.Cancel cancel,ScanProgress run){
        // Stage directory entries on disk. Large galleries never require a Java object per photo.
        java.io.File stage=new java.io.File(c.getCacheDir(),"duplicate-scan-stage.db");
        SQLiteDatabase.deleteDatabase(stage);
        try(SQLiteDatabase scratch=SQLiteDatabase.openOrCreateDatabase(stage,null)){
            scratch.execSQL("CREATE TABLE files(kind INTEGER,doc TEXT PRIMARY KEY,uri TEXT,name TEXT,size INTEGER,mtime INTEGER,path TEXT)");
            int unread;
            scratch.beginTransaction();
            try(SQLiteStatement save=scratch.compileStatement("INSERT OR IGNORE INTO files VALUES(?,?,?,?,?,?,?)")){
                unread=DeviceStorage.enumerate(c,type,cancel,save,run);
                scratch.setTransactionSuccessful();
            }finally{scratch.endTransaction();}
            scratch.execSQL("CREATE INDEX sizes ON files(kind,size)");
            SQLiteDatabase db=ResultsDb.get(c).getWritableDatabase();
            boolean reuse=scope.equals(prefs(c).getString("scope"+type,""));
            String candidates="SELECT f.kind,f.doc,f.uri,f.name,f.size,f.mtime,f.path FROM files f JOIN "
                +"(SELECT kind,size FROM files GROUP BY kind,size HAVING COUNT(*)>1) g ON f.kind=g.kind AND f.size=g.size ORDER BY f.size,f.doc";
            // Keep a stable candidate cursor while recording computed hashes into a separate table.
            scratch.execSQL("CREATE TABLE verified(doc TEXT PRIMARY KEY,hash TEXT)");
            scratch.beginTransaction();
            try(Cursor q=scratch.rawQuery(candidates,null);
                SQLiteStatement save=scratch.compileStatement("INSERT INTO verified VALUES(?,?)")){
                run.total=q.getCount();
                while(q.moveToNext()){
                    IdenticalFiles.check(cancel);
                    run.done=q.getPosition();
                    int k=q.getInt(0);String id=q.getString(1);long size=q.getLong(4),mtime=q.getLong(5);
                    run.file(q.getString(3),size);
                    progress="Comparando "+TITLES[k].toLowerCase(Locale.ROOT)+"…";
                    String hash="";
                    if(reuse&&mtime>0)try(Cursor previous=db.rawQuery("SELECT digest FROM media WHERE kind=? AND doc=? AND size=? AND modified=?",
                            new String[]{""+k,id,""+size,""+mtime})){
                        if(previous.moveToFirst())hash=previous.getString(0);
                    }
                    if(hash.isEmpty()&&mtime>0)try(Cursor memo=db.rawQuery(
                            "SELECT digest FROM hash_work WHERE kind=? AND doc=? AND size=? AND modified=? AND scope=?",
                            new String[]{""+k,id,""+size,""+mtime,scope})){
                        if(memo.moveToFirst())hash=memo.getString(0);
                    }
                    if(hash.isEmpty()){
                        try(InputStream in=open(c.getContentResolver(),Uri.parse(q.getString(2)))){hash=IdenticalFiles.digest(run.counting(in),cancel);}
                        catch(IOException|SecurityException|IllegalArgumentException e){unread++;continue;}
                        if(mtime>0)db.execSQL("INSERT OR REPLACE INTO hash_work VALUES(?,?,?,?,?,?)",new Object[]{k,id,size,mtime,scope,hash});
                    }
                    save.bindString(1,id);save.bindString(2,hash);save.executeInsert();
                    run.verified(hash,new Item(id,Uri.parse(q.getString(2)),q.getString(3),q.getString(6),size,mtime,k));
                    run.done=q.getPosition()+1;
                }
                scratch.setTransactionSuccessful();
            } finally {scratch.endTransaction();}
            IdenticalFiles.check(cancel);
            run.done=run.total;run.saving=true;
            db.beginTransaction();
            try(Cursor q=scratch.rawQuery("SELECT kind,f.doc,uri,name,size,mtime,v.hash,path FROM files f JOIN verified v ON v.doc=f.doc",null);
                SQLiteStatement insert=db.compileStatement("INSERT INTO media VALUES(?,?,?,?,?,?,?,?)")){
                db.delete("media","kind=?",new String[]{""+type});
                while(q.moveToNext()){
                    IdenticalFiles.check(cancel);String id=q.getString(1);
                    insert.bindLong(1,q.getInt(0));insert.bindString(2,id);insert.bindString(3,q.getString(2));
                    insert.bindString(4,q.getString(3));insert.bindString(5,q.getString(7));
                    insert.bindLong(6,q.getLong(4));insert.bindLong(7,q.getLong(5));insert.bindString(8,q.getString(6));
                    insert.executeInsert();
                }
                db.delete("hash_work","kind=?",new String[]{""+type});
                db.setTransactionSuccessful();
            } finally {db.endTransaction();}
            SharedPreferences.Editor editor=prefs(c).edit();long now=System.currentTimeMillis();
            editor.putString("scope"+type,scope).putLong("time"+type,now).putInt("unread"+type,unread);
            editor.apply();progress="Análisis completado";
        }finally{SQLiteDatabase.deleteDatabase(stage);}
    }
    static InputStream open(ContentResolver r,Uri uri)throws IOException{
        InputStream in=r.openInputStream(uri);if(in==null)throw new FileNotFoundException();return in;
    }
    static List<Family> families(Context c,int type){
        List<Family> out=new ArrayList<>();Family family=null;
        String query="SELECT m.digest,m.doc,m.uri,m.name,m.location,m.size,m.modified FROM media m JOIN "
                +"(SELECT digest,size,COUNT(*) AS n FROM media WHERE kind=? GROUP BY digest,size HAVING COUNT(*)>1) g "
                +"ON m.digest=g.digest AND m.size=g.size WHERE m.kind=? "
                +"ORDER BY (g.n-1)*g.size DESC,m.digest,m.size,m.location,m.doc";
        try(Cursor q=ResultsDb.get(c).getReadableDatabase().rawQuery(query,new String[]{""+type,""+type})){
            while(q.moveToNext()){
                String hash=q.getString(0);long size=q.getLong(5);
                if(family==null||!family.digest.equals(hash)||family.items.get(0).size!=size){
                    family=new Family(hash);out.add(family);
                }
                family.items.add(new Item(q.getString(1),Uri.parse(q.getString(2)),q.getString(3),q.getString(4),size,q.getLong(6),type));
            }
        }
        return out;
    }
    private static InputStream original(Context c,Item item)throws IOException{
        Uri uri=item.uri;
        if(item.kind<2&&android.os.Build.VERSION.SDK_INT>=29)
            uri=android.provider.MediaStore.setRequireOriginal(uri);
        return open(c.getContentResolver(),uri);
    }
    static final class Removal {
        boolean needsApproval;
        long session;
        boolean originalUnavailable;
        String message="";
    }
    static Removal remove(Context c,List<Family> families,Set<String> selected,int type){
        Removal result=new Removal();
        ResultsDb db=ResultsDb.get(c);
        result.session=db.begin("Duplicados · "+TITLES[type]);
        for(Family family:families){
            Item keep=family.keeper(selected);
            if(keep==null)continue;
            verifyGroup(c,db,result,family,keep,selected);
        }
        if(!result.needsApproval)result.message=finishRemoval(c,result.session);
        return result;
    }
    private static void verifyGroup(Context c,ResultsDb db,Removal result,Family family,Item keep,Set<String> selected){
        List<Item> items=family.items;
        for(Item item:items){
            if(!selected.contains(item.doc))continue;
            String state="Omitido";
            try{
                boolean equal;
                try(InputStream a=original(c,keep);InputStream b=original(c,item)){
                    equal=IdenticalFiles.same(a,b,item.size,()->false);
                }
                if(equal){
                    MediaPictures.archive(c,family.digest,item,result.session);
                    if(item.kind<2 && android.os.Build.VERSION.SDK_INT>=30){
                        result.needsApproval=true;state="Pendiente de confirmación";
                    }else{
                        boolean deleted;
                        if("file".equals(item.uri.getScheme())){
                            File file=new File(item.uri.getPath());
                            deleted=file.getAbsoluteFile().equals(file.getCanonicalFile()) && file.delete();
                            if(deleted)android.media.MediaScannerConnection.scanFile(c,new String[]{file.getPath()},null,null);
                        }else deleted=c.getContentResolver().delete(item.uri,null,null)>0;
                        if(deleted)state="Eliminado";
                    }
                }
            }catch(UnsupportedOperationException e){
                state="Original no disponible";result.originalUnavailable=true;
            }catch(IOException|RuntimeException ignored){}
            boolean deleted="Eliminado".equals(state);
            db.detail(result.session,item.doc,item.name,item.path,item.size,deleted?0:-1,state);
            if(deleted)db.getWritableDatabase().delete("media","doc=?",new String[]{item.doc});
        }
    }
    // Journal the exact chunk included in the Android consent window, including across rotation.
    static ArrayList<Uri> nextApproval(Context c,long session){
        SQLiteDatabase db=ResultsDb.get(c).getWritableDatabase();
        ArrayList<Uri> chunk=new ArrayList<>();db.beginTransaction();
        try(Cursor q=db.rawQuery("SELECT ref FROM details WHERE session=? AND state='Pendiente de confirmación' ORDER BY rowid LIMIT 500",new String[]{""+session})){
            while(q.moveToNext())chunk.add(Uri.parse(q.getString(0)));
            for(Uri uri:chunk)db.execSQL("UPDATE details SET state='En confirmación' WHERE session=? AND ref=?",new Object[]{session,uri.toString()});
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        return chunk;
    }
    static void resolveChunk(Context c,long session,boolean accepted){
        SQLiteDatabase db=ResultsDb.get(c).getWritableDatabase();
        ArrayList<String> pending=new ArrayList<>();
        try(Cursor q=db.rawQuery("SELECT ref FROM details WHERE session=? AND state='En confirmación'",new String[]{""+session})){
            while(q.moveToNext())pending.add(q.getString(0));
        }
        Set<String> gone=new HashSet<>();
        if(accepted){
            Map<Uri,List<Uri>> collections=new HashMap<>();
            for(String ref:pending){
                Uri uri=Uri.parse(ref);
                collections.computeIfAbsent(ContentUris.removeId(uri),key->new ArrayList<>()).add(uri);
            }
            for(Map.Entry<Uri,List<Uri>> entry:collections.entrySet()){
                Uri collection=entry.getKey();
                try{
                    if(!android.provider.MediaStore.getExternalVolumeNames(c).contains(android.provider.MediaStore.getVolumeName(collection)))continue;
                    List<Uri> uris=entry.getValue();String[] ids=new String[uris.size()];
                    for(int i=0;i<ids.length;i++)ids[i]=Long.toString(ContentUris.parseId(uris.get(i)));
                    String where="_id IN ("+String.join(",",Collections.nCopies(ids.length,"?"))+")";
                    try(Cursor q=c.getContentResolver().query(collection,new String[]{"_id"},where,ids,null)){
                        if(q==null)continue;
                        Set<Long> existing=new HashSet<>();while(q.moveToNext())existing.add(q.getLong(0));
                        for(Uri uri:uris)if(!existing.contains(ContentUris.parseId(uri)))gone.add(uri.toString());
                    }
                }catch(RuntimeException ignored){}
            }
        }
        db.beginTransaction();
        try{
            for(String ref:pending){
                boolean deleted=gone.contains(ref);
                db.execSQL("UPDATE details SET state=?,afterBytes=? WHERE session=? AND ref=?",
                        new Object[]{deleted?"Eliminado":accepted?"Sin verificar":"Omitido",deleted?0:-1,session,ref});
                if(deleted)db.delete("media","doc=?",new String[]{ref});
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    static String finishRemoval(Context c,long session){
        ResultsDb results=ResultsDb.get(c);
        SQLiteDatabase db=results.getWritableDatabase();
        int removed=0,skipped=0;
        db.beginTransaction();
        try(Cursor q=db.rawQuery("SELECT ref,state FROM details WHERE session=?",new String[]{""+session})){
            while(q.moveToNext()){
                String ref=q.getString(0),state=q.getString(1);
                if("Pendiente de confirmación".equals(state)||"En confirmación".equals(state)){
                    state="Omitido";
                    db.execSQL("UPDATE details SET state=? WHERE session=? AND ref=?",new Object[]{state,session,ref});
                }
                if("Eliminado".equals(state))removed++;else skipped++;
            }
            db.execSQL("DELETE FROM detail_previews WHERE session=? AND ref IN (SELECT ref FROM details WHERE session=? AND state!='Eliminado')",new Object[]{session,session});
            db.execSQL("DELETE FROM previews WHERE id NOT IN (SELECT preview FROM detail_previews)");
            results.finish(session,skipped==0?"Terminada":"Revisar historial");db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        changed(c,ALL,true);
        c.sendBroadcast(new Intent("com.zetacache.app.HISTORY_CHANGED").setPackage(c.getPackageName()));
        return removed+" eliminados"+(skipped==0?"":" · "+skipped+" sin eliminar o verificar");
    }
}
