import com.zetacache.app.AppTarget;
import com.zetacache.app.SelectionRules;
import com.zetacache.app.UiLabels;
import com.zetacache.app.SessionState;
import java.util.*;

public final class PureJavaCheck {
  private static void ok(boolean condition, String message) {
    if(!condition) throw new AssertionError(message);
  }
  public static void main(String[] args) {
    List<AppTarget> apps=Arrays.asList(
      new AppTarget("app.high","Juego",false,220*1048576L),
      new AppTarget("app.mid","Facebook",false,38*1048576L),
      new AppTarget("app.small","Mini",false,5*1048576L),
      new AppTarget("system.one","Sistema",true,400*1048576L),
      new AppTarget("unknown","Sin datos",false,-1L)
    );
    List<AppTarget> top=SelectionRules.select(apps,false,0,2,Collections.emptySet(),true);
    ok(top.size()==2,"Top 2");
    ok(top.get(0).packageName.equals("app.high"),"Orden por tamaño");
    ok(top.get(1).packageName.equals("app.mid"),"Exclusión sistema");
    List<AppTarget> all=SelectionRules.select(apps,true,0,2,Collections.emptySet(),true);
    ok(all.get(0).system,"Todas incluye sistema");
    List<AppTarget> greater=SelectionRules.select(apps,true,2,0,Collections.emptySet(),true);
    ok(greater.size()==2,"Más de 50MB");
    List<AppTarget> manual=SelectionRules.select(apps,false,4,0,
      new HashSet<>(Arrays.asList("unknown","app.mid")),true);
    ok(manual.size()==2,"Manual permite valores desconocidos");
    ok(SelectionRules.select(apps,false,1,0,Collections.emptySet(),false).isEmpty(),
      "Sin datos no inventa MB");
    List<AppTarget> fallback=SelectionRules.select(apps,false,0,0,Collections.emptySet(),false);
    ok(fallback.size()==4,"Sin permiso se recorren todas las apps de usuario, no un Top falso");
    SessionState.begin(2);
    SessionState.clicked("app.high");
    ok(SessionState.clickedPackages().contains("app.high"),"Seguimiento de pulsaciones");
    ok(!SessionState.clickedPackages().contains("app.mid"),"Omitidas no verificadas");
    SessionState.begin(1);
    ok(SessionState.clickedPackages().isEmpty(),"Reinicio seguimiento");
    ok(UiLabels.isClearCache("Borrar memoria caché"),"Texto seguro ES");
    ok(UiLabels.isClearCache("Clear cache"),"Texto seguro EN");
    ok(UiLabels.isClearCache("清除缓存"),"Texto seguro ZH");
    String[] dangerous={"Borrar datos","Liberar espacio","Clear storage", "Clear data",
      "Clear data and cache","清除数据","Eliminar", "Confirmar"};
    for (String label: dangerous) ok(!UiLabels.isClearCache(label),"Nunca pulsar: "+label);
    System.out.println("OK: selección, top N, filtros, seguridad textual y sistema/usuario");
  }
}
