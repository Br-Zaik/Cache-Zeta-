import javax.tools.*;
import com.sun.source.util.JavacTask;
import java.nio.file.*;
import java.io.*;
import java.util.*;
import java.util.stream.*;
/** Verifica sintaxis de Java aun si no hay Android SDK en la máquina que audita. */
public final class ParseAndroidSources {
  public static void main(String[] args) throws Exception {
    JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
    if(compiler==null) throw new AssertionError("Falta JDK");
    List<File> files;
    try(Stream<Path> paths=Files.walk(Paths.get("app/src"))) {
      files=paths.filter(x->x.toString().endsWith(".java"))
         .map(Path::toFile).collect(Collectors.toList());
    }
    DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
    try(StandardJavaFileManager manager=compiler.getStandardFileManager(diagnostics,null,null)) {
      Iterable<? extends JavaFileObject> units=manager.getJavaFileObjectsFromFiles(files);
      JavacTask task=(JavacTask)compiler.getTask(new StringWriter(),manager,diagnostics,
          Arrays.asList("-proc:none","-encoding","UTF-8"),null,units);
      task.parse();
    }
    long errors=diagnostics.getDiagnostics().stream()
      .filter(x->x.getKind()==Diagnostic.Kind.ERROR).count();
    if(errors>0) {
      for(Diagnostic<? extends JavaFileObject> e:diagnostics.getDiagnostics())
        if(e.getKind()==Diagnostic.Kind.ERROR) System.err.println(e);
      throw new AssertionError("Errores de sintaxis Java: "+errors);
    }
    System.out.println("OK: sintaxis de "+files.size()+" archivos Java Android");
  }
}
