package com.zetacache.app;

/** Metadatos locales. cacheBytes = -1 si Android no permite medirla. */
public final class AppTarget {
    public final String packageName;
    public final String label;
    public final boolean system;
    public final long cacheBytes;

    public AppTarget(String packageName, String label, boolean system) {
        this(packageName, label, system, -1L);
    }
    public AppTarget(String packageName, String label, boolean system, long cacheBytes) {
        this.packageName = packageName;
        this.label = label;
        this.system = system;
        this.cacheBytes = cacheBytes;
    }
    public AppTarget withCache(long bytes) {
        return new AppTarget(packageName, label, system, bytes);
    }
}
