package com.zetacache.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowInsets;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Panel de juegos: información, atajos y acceso a No molestar. Sin falsas promesas de FPS. */
public final class GameActivity extends Activity {
    private static final int BG = NeonStyle.BG;
    private static final int PANEL = NeonStyle.PANEL;
    private static final int TEXT = NeonStyle.TEXT;
    private static final int MUTED = NeonStyle.MUTED;
    private static final int MINT = NeonStyle.CYAN;
    private LinearLayout main, favorites;
    private TextView ramValue, batteryValue, tempValue, storageValue, lowMemoryValue, deviceValue;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private List<GameShortcuts.Launchable> cachedCandidates = new ArrayList<>();
    private boolean candidatesLoading = true;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
        buildLayout();
        loadCandidates();
    }
    @Override protected void onDestroy() { worker.shutdownNow(); super.onDestroy(); }
    private void loadCandidates() {
        candidatesLoading=true;
        worker.execute(() -> {
            List<GameShortcuts.Launchable> list;
            try { list=GameShortcuts.candidates(getApplicationContext()); }
            catch(Exception e) { list=new ArrayList<>(); }
            final List<GameShortcuts.Launchable> result=list;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                cachedCandidates=result;
                candidatesLoading=false;
                updateFavorites();
            });
        });
    }
    @Override protected void onResume() {
        super.onResume();
        updateReadings();
        updateFavorites();
    }

    private void buildLayout() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        final int side=dp(18);
        scroll.setPadding(side,dp(17),side,dp(25));
        scroll.setOnApplyWindowInsetsListener((v,insets) -> {
            int top,bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());
                top=bars.top;bottom=bars.bottom;
            } else {
                top=insets.getSystemWindowInsetTop();bottom=insets.getSystemWindowInsetBottom();
            }
            v.setPadding(side,top+dp(17),side,bottom+dp(25));
            return insets;
        });
        main = vertical(); scroll.addView(main); setContentView(scroll);

        Button back = button("‹  Volver a limpieza",PANEL,MINT);
        back.setOnClickListener(v -> finish());
        addMargin(main,back,0);
        addMargin(main,text("MODO JUEGO",23,TEXT,true),20);
        addMargin(main,text("Información real y accesos rápidos, sin falsos aceleradores.",13,MUTED,false),6);

        LinearLayout card = vertical();
        card.setPadding(dp(17),dp(15),dp(17),dp(17));
        card.setBackground(round(PANEL,18));
        card.addView(text("ESTADO DEL TELÉFONO",12,MINT,true));
        deviceValue=text("",12,MUTED,false); addMargin(card,deviceValue,8);
        ramValue=metric(card,"RAM disponible");
        batteryValue=metric(card,"Batería");
        tempValue=metric(card,"Temperatura de batería");
        storageValue=metric(card,"Almacenamiento libre");
        lowMemoryValue=text("",12,MUTED,false); addMargin(card,lowMemoryValue,11);
        Button refresh = button("ACTUALIZAR",NeonStyle.SELECTED,MINT);
        refresh.setOnClickListener(v -> updateReadings());
        addMargin(card,refresh,14);
        addMargin(main,card,18);

        addMargin(main,text("MIS JUEGOS",17,TEXT,true),22);
        addMargin(main,text("Elige hasta seis apps para abrirlas rápidamente.",12,MUTED,false),5);
        favorites=vertical(); addMargin(main,favorites,10);
        Button choose = button("ELEGIR JUEGOS",PANEL,MINT);
        choose.setOnClickListener(v -> selectGames());
        addMargin(main,choose,8);

        addMargin(main,text("SIN INTERRUPCIONES",17,TEXT,true),23);
        addMargin(main,text("Abre No molestar y actívalo si deseas silenciar avisos mientras juegas.",12,MUTED,false),5);
        Button dnd = button("ABRIR NO MOLESTAR",PANEL,MINT);
        dnd.setOnClickListener(v -> openDndSettings());
        addMargin(main,dnd,10);

        TextView footer = text("No cierra apps, no libera RAM artificialmente ni modifica el procesador.",11,MUTED,false);
        footer.setGravity(Gravity.CENTER); addMargin(main,footer,24);
    }

    private TextView metric(LinearLayout parent, String title) {
        LinearLayout line=horizontal(); line.setGravity(Gravity.CENTER_VERTICAL);
        TextView label=text(title,13,MUTED,false);
        line.addView(label,new LinearLayout.LayoutParams(0,-2,1));
        TextView value=text("—",14,TEXT,true);
        value.setGravity(Gravity.END);
        line.addView(value,new LinearLayout.LayoutParams(-2,-2));
        addMargin(parent,line,13);
        return value;
    }

    private void updateReadings() {
        GameInfo i=GameInfo.read(this);
        deviceValue.setText(android.os.Build.MANUFACTURER + " " + Build.MODEL
                + " · Android " + Build.VERSION.RELEASE);
        ramValue.setText(i.memoryLabel());
        batteryValue.setText(i.batteryLabel());
        tempValue.setText(i.temperatureLabel());
        storageValue.setText(i.storageLabel());
        lowMemoryValue.setText(i.memoryLow ? "Android indica memoria baja en este momento."
                : "RAM disponible no significa RAM desperdiciada.");
    }

    private void updateFavorites() {
        favorites.removeAllViews();
        Set<String> favoritesSet = GameShortcuts.get(this);
        List<GameShortcuts.Launchable> installed = cachedCandidates;
        int shown=0;
        for (GameShortcuts.Launchable game:installed) {
            if (!favoritesSet.contains(game.packageName)) continue;
            Button b=button("▶  " + game.label,PANEL,TEXT);
            b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            b.setOnClickListener(v -> launch(game.packageName));
            addMargin(favorites,b,7);
            shown++;
        }
        if(shown==0) favorites.addView(text(candidatesLoading ? "Buscando juegos…"
                : "Aún no has elegido juegos.",13,MUTED,false));
    }

    private void launch(String packageName) {
        try {
            Intent intent=getPackageManager().getLaunchIntentForPackage(packageName);
            if(intent==null) { error("El juego ya no está disponible."); return; }
            startActivity(intent);
        } catch(Exception e) { error("No se pudo abrir esta aplicación."); }
    }

    private void selectGames() {
        if(candidatesLoading) { error("Se está preparando la lista de juegos."); return; }
        List<GameShortcuts.Launchable> list=cachedCandidates;
        if(list.isEmpty()) { error("No se encontraron aplicaciones que puedan abrirse."); return; }
        String[] names=new String[list.size()];
        boolean[] checks=new boolean[list.size()];
        Set<String> chosen = new HashSet<>(GameShortcuts.get(this));
        for(int n=0;n<list.size();n++) {
            GameShortcuts.Launchable app=list.get(n);
            names[n]=(app.isGame ? "🎮  " : "") + app.label;
            checks[n]=chosen.contains(app.packageName);
        }
        new AlertDialog.Builder(this)
                .setTitle("Elegir hasta 6 juegos")
                .setMultiChoiceItems(names,checks,(dialog,index,checked)-> {
                    String pkg=list.get(index).packageName;
                    if(checked) {
                        if(chosen.size()>=GameShortcuts.MAX_FAVORITES) {
                            ((AlertDialog)dialog).getListView().setItemChecked(index,false);
                            error("Puedes guardar hasta 6 juegos.");
                        } else chosen.add(pkg);
                    } else chosen.remove(pkg);
                })
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Guardar",(dialog,which)-> {
                    GameShortcuts.save(this,chosen);
                    updateFavorites();
                }).show();
    }

    private void openDndSettings() {
        // Las marcas cambian esta pantalla. Solo el usuario activa/desactiva No molestar.
        String[] actions={"android.settings.ZEN_MODE_SETTINGS", Settings.ACTION_SOUND_SETTINGS,
                Settings.ACTION_SETTINGS};
        for (String action:actions) {
            try { startActivity(new Intent(action)); return; }
            catch (Exception ignored) { }
        }
        error("No se pudieron abrir los ajustes de sonido.");
    }

    private void error(String message) {
        new AlertDialog.Builder(this).setMessage(message).setPositiveButton("Aceptar",null).show();
    }
    private TextView text(String msg,int sp,int color,boolean bold) {
        TextView x=new TextView(this);x.setText(msg);x.setTextSize(sp);x.setTextColor(color);
        if(bold)x.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return x;
    }
    private Button button(String msg,int color,int fg) {
        Button b=new Button(this);b.setText(msg);b.setTextSize(14);b.setTextColor(fg);
        b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setMinHeight(0);
        b.setPadding(dp(12),dp(13),dp(12),dp(13));b.setBackground(new RippleDrawable(
                ColorStateList.valueOf(0x35ffffff),round(color,14),null));return b;
    }
    private GradientDrawable round(int color,int r) {
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(r));return d;
    }
    private void addMargin(LinearLayout p,View child,int margin) {
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(margin);
        p.addView(child,lp);
    }
    private LinearLayout vertical() {LinearLayout a=new LinearLayout(this);a.setOrientation(1);return a;}
    private LinearLayout horizontal() {return new LinearLayout(this);}
    private int dp(float x) {return Math.round(x*getResources().getDisplayMetrics().density);}
}
