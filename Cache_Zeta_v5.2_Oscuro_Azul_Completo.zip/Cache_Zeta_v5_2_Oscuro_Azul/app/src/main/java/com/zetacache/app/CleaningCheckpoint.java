package com.zetacache.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Cola local recuperable. No se vuelve a ejecutar automáticamente tras un cierre. */
public final class CleaningCheckpoint {
    private static final String NAME = "cache_zeta_checkpoint_v3";
    private CleaningCheckpoint() {}
    private static SharedPreferences preferences(Context ctx) {
        return ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    public static void start(Context ctx, List<AppTarget> queue) {
        JSONArray arr = new JSONArray();
        for (AppTarget item : queue) {
            JSONObject obj = new JSONObject();
            try {
                obj.put("pkg", item.packageName);
                obj.put("label", item.label);
                obj.put("system", item.system);
                obj.put("cache", item.cacheBytes);
                arr.put(obj);
            } catch (Exception ignored) { }
        }
        preferences(ctx).edit().putString("queue", arr.toString())
                .putInt("next", 0).putInt("total", queue.size()).commit();
    }

    public static void advance(Context ctx, int next) {
        preferences(ctx).edit().putInt("next", next).commit();
    }

    /** Comprobación O(1): no interpreta 300 elementos cada vez que se actualiza la interfaz. */
    public static boolean hasRemaining(Context ctx) {
        SharedPreferences pref = preferences(ctx);
        String data=pref.getString("queue", "");
        if (data == null || data.isEmpty()) return false;
        int total = pref.getInt("total", -1);
        return total < 0 ? !remaining(ctx).isEmpty() : pref.getInt("next", 0) < total;
    }

    public static List<AppTarget> remaining(Context ctx) {
        ArrayList<AppTarget> result = new ArrayList<>();
        SharedPreferences prefs = preferences(ctx);
        String raw = prefs.getString("queue", "");
        if (raw == null || raw.isEmpty()) return result;
        try {
            JSONArray array = new JSONArray(raw);
            int next = Math.min(Math.max(0, prefs.getInt("next", 0)), array.length());
            for (int i = next; i < array.length(); i++) {
                JSONObject x = array.getJSONObject(i);
                result.add(new AppTarget(x.getString("pkg"), x.getString("label"),
                        x.optBoolean("system"), x.optLong("cache", -1L)));
            }
        } catch (Exception ignored) {
            clear(ctx);
        }
        return result;
    }

    public static void clear(Context ctx) { preferences(ctx).edit().clear().commit(); }
}
