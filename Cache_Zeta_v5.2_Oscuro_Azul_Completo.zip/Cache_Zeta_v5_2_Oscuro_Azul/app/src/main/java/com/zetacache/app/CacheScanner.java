package com.zetacache.app;

import android.Manifest;
import android.app.AppOpsManager;
import android.app.usage.StorageStats;
import android.app.usage.StorageStatsManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Process;
import android.os.storage.StorageManager;
import android.os.Build;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Medición local real en hilo secundario. No usa red, ni accede a datos de otras apps. */
public final class CacheScanner {
    private CacheScanner() {}

    public interface Progress { void onProgress(int done, int total); }

    public static boolean hasUsageAccess(Context context) {
        AppOpsManager ops = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
        if (ops == null) return false;
        try {
            int mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(), context.getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) { return false; }
    }

    public static List<AppTarget> installed(Context context) {
        PackageManager pm = context.getPackageManager();
        List<ApplicationInfo> packages = pm.getInstalledApplications(0);
        ArrayList<AppTarget> result = new ArrayList<>();
        for (ApplicationInfo info : packages) {
            String pkg = info.packageName;
            if (!info.enabled || pkg.equals(context.getPackageName()) || pkg.equals("android")
                    || pkg.equals("com.android.settings") || pkg.equals("com.samsung.android.settings")) continue;
            boolean system = (info.flags & (ApplicationInfo.FLAG_SYSTEM
                    | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0;
            CharSequence label = info.loadLabel(pm);
            result.add(new AppTarget(pkg, label == null || label.length() == 0 ? pkg : label.toString(), system));
        }
        return result;
    }

    public static List<AppTarget> measure(Context context, List<AppTarget> apps,
                                          Progress progress) {
        ArrayList<AppTarget> result = new ArrayList<>(apps.size());
        StorageStatsManager manager = (StorageStatsManager)
                context.getSystemService(Context.STORAGE_STATS_SERVICE);
        if (!hasUsageAccess(context) || manager == null) {
            // Nunca perder la lista de apps cuando se revoca el permiso durante un análisis.
            for (AppTarget app : apps) result.add(app.withCache(-1L));
            return result;
        }
        PackageManager pm = context.getPackageManager();
        int index = 0;
        for (AppTarget app : apps) {
            long bytes = -1L;
            try {
                ApplicationInfo info = pm.getApplicationInfo(app.packageName, 0);
                UUID volume = info.storageUuid == null ? StorageManager.UUID_DEFAULT : info.storageUuid;
                StorageStats stats = manager.queryStatsForPackage(volume,
                        app.packageName, Process.myUserHandle());
                bytes = Math.max(0L, stats.getCacheBytes());
            } catch (Exception | LinkageError ignored) {
                // Volumen no disponible / permisos / fabricante. No mostrar 0 falso.
            }
            result.add(app.withCache(bytes));
            index++;
            if (progress != null && (index % 8 == 0 || index == apps.size()))
                progress.onProgress(index, apps.size());
        }
        return result;
    }

    public static String size(long bytes) {
        if (bytes < 0) return "Sin dato";
        if (bytes < 1024 * 1024) return String.format(java.util.Locale.getDefault(), "%.0f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024L * 1024L) return String.format(java.util.Locale.getDefault(), "%.1f MB", bytes / 1048576.0);
        return String.format(java.util.Locale.getDefault(), "%.2f GB", bytes / 1073741824.0);
    }
}
