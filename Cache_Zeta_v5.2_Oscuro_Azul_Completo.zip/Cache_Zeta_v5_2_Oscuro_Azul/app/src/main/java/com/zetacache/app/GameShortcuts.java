package com.zetacache.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Accesos directos guardados solo en este teléfono; nunca mata otras aplicaciones. */
public final class GameShortcuts {
    private static final String NAME = "cache_zeta_games_v4";
    public static final int MAX_FAVORITES = 6;
    private GameShortcuts() { }

    public static final class Launchable {
        public final String packageName, label;
        public final boolean isGame;
        Launchable(String packageName, String label, boolean isGame) {
            this.packageName=packageName; this.label=label; this.isGame=isGame;
        }
    }

    public static List<Launchable> candidates(Context context) {
        PackageManager pm = context.getPackageManager();
        List<Launchable> items = new ArrayList<>();
        for (ApplicationInfo info : pm.getInstalledApplications(0)) {
            if (!info.enabled || info.packageName.equals(context.getPackageName())) continue;
            if ((info.flags & ApplicationInfo.FLAG_SYSTEM) != 0
                    && (info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0) continue;
            if (pm.getLaunchIntentForPackage(info.packageName) == null) continue;
            CharSequence label = info.loadLabel(pm);
            items.add(new Launchable(info.packageName,
                    label == null || label.length() == 0 ? info.packageName : label.toString(),
                    info.category == ApplicationInfo.CATEGORY_GAME));
        }
        items.sort(Comparator.comparing((Launchable x) -> !x.isGame)
                .thenComparing(x -> x.label.toLowerCase(Locale.ROOT)));
        return items;
    }

    public static Set<String> get(Context context) {
        return new HashSet<>(context.getSharedPreferences(NAME,Context.MODE_PRIVATE)
                .getStringSet("favorite_games", Collections.emptySet()));
    }
    public static void save(Context context, Set<String> selected) {
        context.getSharedPreferences(NAME,Context.MODE_PRIVATE).edit()
                .putStringSet("favorite_games", new HashSet<>(selected)).apply();
    }
}
