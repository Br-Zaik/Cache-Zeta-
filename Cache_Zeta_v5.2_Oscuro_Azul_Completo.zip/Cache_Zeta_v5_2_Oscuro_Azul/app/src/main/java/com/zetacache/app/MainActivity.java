package com.zetacache.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Pantalla principal fija. No ScrollView: posiciones adaptables que se ajustan a la altura
 * disponible y reservan pantallas independientes para ajustes, juegos y selección.
 * Solo UI; el motor de accesibilidad se conserva sin modificaciones.
 */
public final class MainActivity extends Activity {
    private static final int BG=NeonStyle.BG, PANEL=NeonStyle.PANEL;
    private static final int TEXT=NeonStyle.TEXT, MUTED=NeonStyle.MUTED, MINT=NeonStyle.CYAN;
    private static final String PREF="cache_zeta_lite_v3";
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final List<AppTarget> apps=new ArrayList<>();
    private final Set<String> picked=new HashSet<>();
    private final Set<String> excluded=new HashSet<>();
    private boolean systemApps=false,measured=false,scanning=false,loading=false;
    private boolean awaitingUsage=false,verifyAfter=false,verifying=false;
    private int filter=SelectionRules.MOST_CACHE,limit=10,scanVersion=0,scanDone=0;
    private boolean scanAttempted=false;
    private List<AppTarget> lastStarted=new ArrayList<>();
    private TextView count,permissionText,analysisText,selectedInfo,previewText;
    private TextView resultText,progressText,allChip,userChip,topAll;
    private TextView filterTitle,topTitle,storageDetail,storagePct,storageTotal,cacheValue,cacheLabel,noFilter;
    private TextView selectBtn;
    private Button cleanBtn;
    private TextView[] thresholdButtons=new TextView[3],topButtons=new TextView[4];
    private String lastCacheValue="";
    private ProgressBar storageProgress;
    private GameInfo deviceInfo;
    private String lastChipSignature="";
    private final Runnable pulse=new Runnable() {
        @Override public void run() {
            refresh();
            ui.postDelayed(this,1200);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if(Build.VERSION.SDK_INT>=30) getWindow().setDecorFitsSystemWindows(false);
        excluded.addAll(prefs().getStringSet("excluded",new HashSet<>()));
        picked.addAll(prefs().getStringSet("picked",new HashSet<>()));
        systemApps=prefs().getBoolean("system",false);
        filter=prefs().getInt("filter",SelectionRules.MOST_CACHE);
        limit=prefs().getInt("limit",10);
        deviceInfo=GameInfo.read(this);
        createLayout();
        loadApps();
    }
    @Override protected void onResume() {
        super.onResume();
        deviceInfo=GameInfo.read(this);
        ui.removeCallbacks(pulse);ui.post(pulse);
        if(!SessionState.running && verifyAfter && !verifying) verifyResults();
        if(!SessionState.running && !scanning && !loading && CacheScanner.hasUsageAccess(this)
                && (!scanAttempted || awaitingUsage)) {
            awaitingUsage=false;analyze();
        }
    }
    @Override protected void onPause(){ui.removeCallbacks(pulse);super.onPause();}
    @Override protected void onDestroy(){worker.shutdownNow();ui.removeCallbacksAndMessages(null);super.onDestroy();}
    private SharedPreferences prefs(){return getSharedPreferences(PREF,MODE_PRIVATE);}

    private void loadApps(){
        if(loading) return;
        loading=true;
        worker.execute(()->{
            List<AppTarget> found;
            try{found=CacheScanner.installed(getApplicationContext());}
            catch(Exception e){found=new ArrayList<>();}
            final List<AppTarget> result=found;
            ui.post(()->{
                if(isFinishing() || isDestroyed()) return;
                apps.clear();apps.addAll(result);
                loading=false;measured=false;scanAttempted=false;
                refresh();
                if(CacheScanner.hasUsageAccess(this)&&!SessionState.running)analyze();
            });
        });
    }
    private void analyze(){
        if(scanning||SessionState.running||loading)return;
        if(!CacheScanner.hasUsageAccess(this)){requestUsage();return;}
        scanning=true;scanDone=0;scanAttempted=true;
        int version=++scanVersion;
        final List<AppTarget> snapshot=new ArrayList<>(apps);
        analysisText.setText("Analizando caché…");refresh();
        worker.execute(()->{
            List<AppTarget> result=CacheScanner.measure(getApplicationContext(),snapshot,
                    (done,total)->ui.post(()->{
                        if(version==scanVersion){scanDone=done;analysisText.setText("Analizando "+done+"/"+total);showCache(-1,true,total==0?0:done*100/total);}
                    }));
            ui.post(()->{
                if(version!=scanVersion||isFinishing()||isDestroyed())return;
                apps.clear();apps.addAll(result);scanning=false;
                int known=0;
                for(AppTarget item:result)if(item.cacheBytes>=0)known++;
                measured=CacheScanner.hasUsageAccess(this)&&result.size()==snapshot.size()&&known>0;
                analysisText.setText(measured?"Medidas: "+known+" apps":"Sin medición de caché");
                refresh();
            });
        });
    }
    private List<AppTarget> scoped(){
        ArrayList<AppTarget> out=new ArrayList<>();
        for(AppTarget a:apps)if((systemApps||!a.system)&&!excluded.contains(a.packageName))out.add(a);
        return out;
    }
    private List<AppTarget> selected(){
        return SelectionRules.select(scoped(),true,filter,limit,picked,measured);
    }

    private void createLayout(){
        DesignLayout root=new DesignLayout(this);
        root.setBackgroundColor(BG);
        if(Build.VERSION.SDK_INT>=30){
            root.setOnApplyWindowInsetsListener((view,insets)->{
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(bars.left,bars.top,bars.right,bars.bottom);
                return insets;
            });
        }
        setContentView(root);
        root.requestApplyInsets();

        TextView title=label("Limpieza",24,TEXT,true,Gravity.START);
        root.place(title,20,47,235,39);
        ImageView info=imageButton(R.drawable.ic_info,MUTED,"Información y estado");
        info.setOnClickListener(v->showInfo());root.place(info,282,40,44,44);
        ImageView settings=imageButton(R.drawable.ic_settings,TEXT,"Ajustes y permisos");
        settings.setOnClickListener(v->showMenu());root.place(settings,331,40,44,44);

        panel(root,20,107,352,157,NeonStyle.hero(this));
        cacheValue=label("—",50,TEXT,false,Gravity.START);
        root.place(cacheValue,43,133,238,55);
        cacheLabel=label("Sin analizar",12,MUTED,false,Gravity.START);
        root.place(cacheLabel,44,190,236,24);
        ImageView sparkle=new ImageView(this);sparkle.setImageDrawable(icon(R.drawable.ic_clean,MINT,28));
        sparkle.setScaleType(ImageView.ScaleType.CENTER);
        sparkle.setBackground(NeonStyle.solid(this,0xFF344665,19,0));
        sparkle.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        root.place(sparkle,291,134,58,58);
        analysisText=label("Volver a analizar",11,MINT,false,Gravity.START);
        analysisText.setCompoundDrawables(icon(R.drawable.ic_refresh,MINT,15),null,null,null);
        analysisText.setCompoundDrawablePadding(dp(7));
        analysisText.setBackground(NeonStyle.ripple(NeonStyle.solid(this,Color.TRANSPARENT,8,0)));
        analysisText.setOnClickListener(v->analyze());
        analysisText.setContentDescription("Volver a analizar la caché");
        analysisText.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        root.place(analysisText,44,218,240,40);

        TextView storageTitle=label("Almacenamiento",13,TEXT,false,Gravity.START);
        storageTitle.setCompoundDrawables(icon(R.drawable.ic_disk,MUTED,18),null,null,null);
        storageTitle.setCompoundDrawablePadding(dp(8));root.place(storageTitle,20,281,270,26);
        storagePct=label("—",13,TEXT,true,Gravity.END);root.place(storagePct,315,281,57,26);
        storageProgress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        storageProgress.setMax(100);
        android.graphics.drawable.ClipDrawable fill=new android.graphics.drawable.ClipDrawable(
                NeonStyle.solid(this,MINT,3,0),Gravity.LEFT,android.graphics.drawable.ClipDrawable.HORIZONTAL);
        android.graphics.drawable.LayerDrawable progressDrawable=new android.graphics.drawable.LayerDrawable(
                new Drawable[]{NeonStyle.solid(this,NeonStyle.SOFT,3,0),fill});
        progressDrawable.setId(0,android.R.id.background);progressDrawable.setId(1,android.R.id.progress);
        storageProgress.setProgressDrawable(progressDrawable);
        storageProgress.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        root.place(storageProgress,20,313,352,6);
        storageDetail=label("Sin dato",11,MUTED,false,Gravity.START);root.place(storageDetail,20,324,245,22);
        storageTotal=label("—",11,MUTED,false,Gravity.END);root.place(storageTotal,272,324,100,22);

        panel(root,20,360,352,48,NeonStyle.solid(this,NeonStyle.SOFT,13,0));
        allChip=label("Todas las apps",12,MUTED,true,Gravity.CENTER);
        userChip=label("Instaladas por mí",12,TEXT,true,Gravity.CENTER);
        allChip.setOnClickListener(v->changeScope(true));userChip.setOnClickListener(v->changeScope(false));
        root.place(allChip,24,364,170,40);root.place(userChip,198,364,170,40);

        panel(root,20,429,352,202,NeonStyle.card(this));
        filterTitle=label("Tamaño de caché",13,TEXT,true,Gravity.START);
        root.place(filterTitle,36,439,230,36);
        noFilter=label("Sin filtro",11,MINT,true,Gravity.END);
        noFilter.setOnClickListener(v->selectFilter(SelectionRules.MOST_CACHE));
        root.place(noFilter,273,436,83,38);
        int[] amounts={10,50,100};
        for(int i=0;i<3;i++){
            final int f=i+1;
            TextView item=label(amounts[i]+" MB",12,TEXT,false,Gravity.CENTER);
            item.setOnClickListener(v->selectFilter(f));thresholdButtons[i]=item;
            root.place(item,36+i*(328f/3f),472,304f/3f,44);
        }
        topTitle=label("Cantidad de apps",13,TEXT,true,Gravity.START);root.place(topTitle,36,533,230,36);
        topAll=label("Todas",11,MINT,true,Gravity.END);topAll.setOnClickListener(v->changeLimit(0));
        root.place(topAll,282,530,74,38);
        int[] amountsTop={5,10,20,50};
        for(int i=0;i<4;i++){
            final int n=amountsTop[i];TextView item=label("Top "+n,12,TEXT,false,Gravity.CENTER);
            item.setOnClickListener(v->changeLimit(n));topButtons[i]=item;
            root.place(item,36+i*82,566,74,44);
        }

        count=label("Buscando apps…",11,TEXT,false,Gravity.CENTER);
        root.place(count,20,632,352,27);
        cleanBtn=new Button(this);cleanBtn.setAllCaps(false);cleanBtn.setTextSize(16);
        cleanBtn.setTextColor(NeonStyle.ON_ACCENT);cleanBtn.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        cleanBtn.setMinHeight(0);cleanBtn.setMinimumHeight(0);cleanBtn.setMinWidth(0);cleanBtn.setMinimumWidth(0);
        cleanBtn.setPadding(dp(19),0,dp(15),0);cleanBtn.setIncludeFontPadding(false);
        cleanBtn.setSingleLine(true);cleanBtn.setEllipsize(TextUtils.TruncateAt.END);
        cleanBtn.setStateListAnimator(null);cleanBtn.setBackground(NeonStyle.ripple(NeonStyle.primary(this)));
        cleanBtn.setCompoundDrawables(icon(R.drawable.ic_clean,NeonStyle.ON_ACCENT,22),null,
                icon(R.drawable.ic_arrow,NeonStyle.ON_ACCENT,18),null);
        cleanBtn.setOnClickListener(v->{
            if(SessionState.running){CacheAccessibilityService service=CacheAccessibilityService.instance();if(service!=null)service.cancel();}
            else startCleaning(false);
        });root.place(cleanBtn,20,665,352,54);
        selectBtn=label("Seleccionar apps",13,TEXT,true,Gravity.CENTER);
        selectBtn.setPadding(dp(20),0,dp(16),0);
        selectBtn.setCompoundDrawables(icon(R.drawable.ic_list,TEXT,20),null,icon(R.drawable.ic_arrow,MUTED,17),null);
        selectBtn.setBackground(NeonStyle.ripple(NeonStyle.secondary(this)));
        selectBtn.setOnClickListener(v->{
            if(!SessionState.running&&CleaningCheckpoint.hasRemaining(this))showPendingActions();else chooseApps();
        });root.place(selectBtn,20,730,352,46);

        panel(root,20,777,352,1,NeonStyle.solid(this,NeonStyle.BORDER,0,0));
        panel(root,51,785,56,27,NeonStyle.solid(this,NeonStyle.SELECTED,14,0));
        int[] icons={R.drawable.ic_clean,R.drawable.ic_games,R.drawable.ic_history};
        String[] names={"Limpieza","Juegos","Historial"};
        for(int i=0;i<3;i++){
            final int tab=i;int cx=79+117*i;
            ImageView symbol=new ImageView(this);symbol.setImageDrawable(icon(icons[i],i==0?MINT:MUTED,22));
            symbol.setScaleType(ImageView.ScaleType.FIT_CENTER);
            symbol.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);root.place(symbol,cx-11,788,22,22);
            TextView caption=label(names[i],10,i==0?MINT:MUTED,i==0,Gravity.CENTER);
            caption.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);root.place(caption,cx-50,813,100,20);
            View hit=new View(this);hit.setContentDescription(names[i]);hit.setSelected(i==0);hit.setFocusable(true);
            hit.setBackground(NeonStyle.ripple(NeonStyle.solid(this,Color.TRANSPARENT,12,0)));
            hit.setOnClickListener(v->{if(tab==1)startActivity(new Intent(this,GameActivity.class));else if(tab==2)showHistory();});
            root.place(hit,20+i*117,781,117,53);
        }
        permissionText=text("",12,MUTED,false);selectedInfo=text("",12,TEXT,false);
        previewText=text("",12,MUTED,false);progressText=text("",12,TEXT,false);resultText=text("",12,MUTED,false);
        refresh();
    }

    private void panel(DesignLayout parent,float x,float y,float w,float h,Drawable background){
        View panel=new View(this);panel.setBackground(background);
        panel.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);parent.place(panel,x,y,w,h);
    }
    private Drawable icon(int resource,int color,int size){
        Drawable d=getDrawable(resource).mutate();d.setTint(color);d.setBounds(0,0,dp(size),dp(size));return d;
    }
    private ImageView imageButton(int resource,int color,String description){
        ImageView image=new ImageView(this);image.setImageDrawable(icon(resource,color,22));
        image.setPadding(dp(11),dp(11),dp(11),dp(11));image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setContentDescription(description);image.setFocusable(true);
        image.setBackground(NeonStyle.ripple(NeonStyle.solid(this,Color.TRANSPARENT,12,0)));return image;
    }
    private TextView label(String value,int sp,int color,boolean bold,int gravity){
        TextView label=text(value,sp,color,bold);label.setGravity(gravity|Gravity.CENTER_VERTICAL);
        label.setIncludeFontPadding(false);label.setSingleLine(true);label.setEllipsize(TextUtils.TruncateAt.END);
        label.setPadding(0,0,0,0);return label;
    }
    private void showCache(long bytes,boolean scanning,int percent){
        String value=scanning?percent+" %":bytes<0?"—":CacheScanner.size(bytes);
        if(!lastCacheValue.equals(value)){
            lastCacheValue=value;
            SpannableString styled=new SpannableString(value);
            int space=value.lastIndexOf(' ');
            styled.setSpan(new StyleSpan(Typeface.BOLD),0,space>0?space:value.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if(space>0){
                styled.setSpan(new RelativeSizeSpan(.40f),space,value.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                
            }
            cacheValue.setText(styled);
        }
        cacheLabel.setText(scanning?"Analizando caché…":bytes<0?"Sin analizar":"Caché detectada");
        cacheValue.setContentDescription(scanning?"Análisis: "+percent+" por ciento":bytes<0?"Caché sin analizar":"Caché detectada: "+value);
    }

    private void changeScope(boolean all){
        systemApps=all;prefs().edit().putBoolean("system",all).apply();refresh();
    }
    private void selectFilter(int newFilter){
        filter=newFilter;prefs().edit().putInt("filter",filter).apply();refresh();
    }
    private void changeLimit(int n){
        limit=n;prefs().edit().putInt("limit",n).apply();refresh();
    }
    private void showMenu(){
        String[] actions={"Analizar caché","Permiso de medición (MB)","Permiso de Accesibilidad",
                "Elegir aplicaciones","Excluir aplicaciones","Reanudar limpieza","Historial"};
        new AlertDialog.Builder(this).setTitle("Caché Zeta · Ajustes")
                .setItems(actions,(d,i)->{
                    switch(i){
                        case 0:analyze();break;
                        case 1:requestUsage();break;
                        case 2:requestAccessibility();break;
                        case 3:chooseApps();break;
                        case 4:chooseExclusions();break;
                        case 5:startCleaning(true);break;
                        default:showHistory();break;
                    }
                }).setNegativeButton("Cerrar",null).show();
    }
    private void showInfo(){
        boolean accessible=CacheAccessibilityService.instance()!=null;
        List<AppTarget> items=selected();
        String status=SessionState.running?"Limpieza "+SessionState.index+"/"+SessionState.total
                +"\n"+SessionState.appName:"En espera";
        new AlertDialog.Builder(this).setTitle("Estado de Caché Zeta")
                .setMessage("Apps encontradas: "+apps.size()+"\nSeleccionadas: "+items.size()
                        +"\nMedición MB: "+(measured?"Lista":"Pendiente")
                        +"\nAccesibilidad: "+(accessible?"Activa":"Pendiente")
                        +"\n\n"+status+"\n"+SessionState.result)
                .setNeutralButton("Analizar",(d,w)->analyze())
                .setNegativeButton("Cerrar",null)
                .setPositiveButton(accessible?"Detener":"Permisos",(d,w)->{
                    if(SessionState.running){
                        CacheAccessibilityService s=CacheAccessibilityService.instance();if(s!=null)s.cancel();
                    }else if(!accessible)requestAccessibility();
                }).show();
    }
    private void showHistory(){
        new AlertDialog.Builder(this).setTitle("Historial de limpiezas")
                .setMessage(HistoryStore.get(this)).setPositiveButton("Cerrar",null).show();
    }
    private void showPendingActions(){
        new AlertDialog.Builder(this).setTitle("Limpieza pendiente")
                .setItems(new String[]{"Reanudar limpieza","Elegir otras apps"},(d,i)->{
                    if(i==0)startCleaning(true);else chooseApps();
                }).show();
    }
    private void showFilters() {
        String[] labels={"Más caché primero","Más de 10 MB","Más de 50 MB","Más de 100 MB","Elegir aplicaciones"};
        new AlertDialog.Builder(this).setTitle("Filtro de limpieza")
                .setSingleChoiceItems(labels, filter, (dialog, which) -> {
                    filter=which; prefs().edit().putInt("filter",which).apply();
                    dialog.dismiss(); refresh();
                    if (which == SelectionRules.MANUAL) chooseApps();
                }).setNegativeButton("Cancelar",null).show();
    }

    private void chooseApps() {
        if (apps.isEmpty()) { msg("Primero espera a que se detecten las apps."); return; }
        List<AppTarget> candidates = scoped();
        candidates.sort((a,b) -> Long.compare(b.cacheBytes,a.cacheBytes));
        String[] names = new String[candidates.size()];
        boolean[] selected = new boolean[candidates.size()];
        Set<String> working = new HashSet<>(picked);
        for (int i=0;i<candidates.size();i++) {
            AppTarget app = candidates.get(i);
            names[i]=app.label + (app.cacheBytes >= 0 ? " · "+CacheScanner.size(app.cacheBytes) : "");
            selected[i]=working.contains(app.packageName);
        }
        new AlertDialog.Builder(this).setTitle("Elegir aplicaciones")
                .setMultiChoiceItems(names,selected,(d,which,checked)-> {
                    String pkg=candidates.get(which).packageName;
                    if (checked) working.add(pkg); else working.remove(pkg);
                })
                .setNeutralButton("Ninguna",(d,w)-> { picked.clear(); filter=SelectionRules.MANUAL;
                    prefs().edit().putInt("filter",filter)
                            .putStringSet("picked",new HashSet<>(picked)).apply(); refresh(); })
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Guardar",(d,w)-> {
                    picked.clear(); picked.addAll(working);
                    filter=SelectionRules.MANUAL;
                    prefs().edit().putInt("filter",filter)
                            .putStringSet("picked",new HashSet<>(picked)).apply(); refresh();
                }).show();
    }

    private void chooseExclusions() {
        if (apps.isEmpty()) { msg("Todavía no hay aplicaciones."); return; }
        ArrayList<AppTarget> candidates = new ArrayList<>(apps);
        candidates.sort(Comparator.comparing(a->a.label.toLowerCase(Locale.ROOT)));
        String[] names = new String[candidates.size()];
        boolean[] values = new boolean[candidates.size()];
        Set<String> working = new HashSet<>(excluded);
        for(int i=0;i<candidates.size();i++) {
            names[i]=candidates.get(i).label;
            values[i]=working.contains(candidates.get(i).packageName);
        }
        new AlertDialog.Builder(this).setTitle("Nunca limpiar estas apps")
                .setMultiChoiceItems(names,values,(d,index,checked)-> {
                    String pkg=candidates.get(index).packageName;
                    if (checked) working.add(pkg); else working.remove(pkg);
                }).setNegativeButton("Cancelar",null)
                .setPositiveButton("Guardar",(d,w)-> {
                    excluded.clear(); excluded.addAll(working);
                    prefs().edit().putStringSet("excluded",new HashSet<>(excluded)).apply(); refresh();
                }).show();
    }

    private void refresh(){
        if(count==null)return;
        boolean running=SessionState.running;
        boolean accessible=CacheAccessibilityService.instance()!=null;
        List<AppTarget> scopedApps=scoped();
        List<AppTarget> chosen=selected();
        int nonzero=0;
        for(AppTarget a:scopedApps)if(a.cacheBytes>0)nonzero++;
        SpannableString selection=new SpannableString("•  "+chosen.size()+" apps seleccionadas     de "+scopedApps.size());
        selection.setSpan(new android.text.style.ForegroundColorSpan(MINT),0,1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        int detail=selection.toString().lastIndexOf("de ");
        if(detail>=0)selection.setSpan(new android.text.style.ForegroundColorSpan(MUTED),detail,selection.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        count.setText(selection);
        permissionText.setText((accessible?"Accesibilidad activa":"Accesibilidad pendiente")+
                " · "+(measured?"MB medidos":"MB pendientes"));
        if(!scanning)analysisText.setText(loading?"Buscando aplicaciones…":running?"Limpieza en curso":"Volver a analizar");
        analysisText.setEnabled(!scanning&&!loading&&!running);
        long sum=SelectionRules.totalKnownCache(scopedApps);
        showCache(measured?sum:-1,scanning,scanning?(apps.isEmpty()?0:scanDone*100/apps.size()):0);
        if(deviceInfo!=null && deviceInfo.storageTotal>0 && deviceInfo.storageAvailable>=0){
            long used=deviceInfo.storageTotal-deviceInfo.storageAvailable;
            int percent=Math.max(0,Math.min(100,(int)Math.round(used*100.0/deviceInfo.storageTotal)));
            storageProgress.setProgress(percent);
            storageDetail.setText(GameInfo.formatGiB(used)+" usados");
            storageTotal.setText(GameInfo.formatGiB(deviceInfo.storageTotal));
            storagePct.setText(percent+"%");
        }else{storageProgress.setProgress(0);storageDetail.setText("Sin dato");storageTotal.setText("—");storagePct.setText("—");}
        String chipSignature=systemApps+"/"+filter+"/"+limit+"/"+picked.size();
        if(!chipSignature.equals(lastChipSignature)){
            lastChipSignature=chipSignature;
            allChip.setBackground(NeonStyle.ripple(NeonStyle.scope(this,systemApps)));
            userChip.setBackground(NeonStyle.ripple(NeonStyle.scope(this,!systemApps)));
            allChip.setTextColor(systemApps?TEXT:MUTED);allChip.setSelected(systemApps);
            userChip.setTextColor(!systemApps?TEXT:MUTED);userChip.setSelected(!systemApps);
            if(filter==SelectionRules.MANUAL)filterTitle.setText("Selección manual ("+picked.size()+")");
            else filterTitle.setText("Tamaño de caché");
            for(int i=0;i<thresholdButtons.length;i++){
                boolean active=filter==i+1;
                thresholdButtons[i].setBackground(NeonStyle.ripple(NeonStyle.chip(this,active)));
                thresholdButtons[i].setTextColor(active?MINT:TEXT);
                thresholdButtons[i].setTypeface(Typeface.DEFAULT,active?Typeface.BOLD:Typeface.NORMAL);
                thresholdButtons[i].setSelected(active);
            }
            int[] tops={5,10,20,50};
            for(int i=0;i<topButtons.length;i++){
                boolean active=limit==tops[i];
                topButtons[i].setBackground(NeonStyle.ripple(NeonStyle.chip(this,active)));
                topButtons[i].setTextColor(active?MINT:TEXT);
                topButtons[i].setTypeface(Typeface.DEFAULT,active?Typeface.BOLD:Typeface.NORMAL);
                topButtons[i].setSelected(active);
            }
            topAll.setTextColor(MINT);topAll.setSelected(limit==0);
            noFilter.setSelected(filter==SelectionRules.MOST_CACHE);
            topAll.setText(limit==0?"✓ Todas":"Todas");
        }
        boolean busy=running||loading||scanning;
        boolean canOfferUnmeasured = !measured && filter != SelectionRules.MANUAL
                && !scopedApps.isEmpty();
        cleanBtn.setEnabled(!loading&&!scanning&&(running||!chosen.isEmpty()||canOfferUnmeasured));
        cleanBtn.setAlpha(cleanBtn.isEnabled()?1f:0.72f);
        cleanBtn.setText(running?"Detener limpieza":"Limpiar caché");
        boolean pending=!running&&CleaningCheckpoint.hasRemaining(this);
        selectBtn.setText(pending?"Reanudar o seleccionar":"Seleccionar apps");
        selectedInfo.setText(chosen.size()+" apps listas");
        previewText.setText(measured?CacheScanner.size(SelectionRules.totalKnownCache(chosen)):"Sin medición");
        progressText.setText(running?"Procesando "+SessionState.index+"/"+SessionState.total:"En espera");
        resultText.setText(running?SessionState.appName:SessionState.result);
    }
    private void startCleaning(boolean resume) {
        if (SessionState.running||scanning||loading) return;
        CacheAccessibilityService service=CacheAccessibilityService.instance();
        if (service==null) { requestAccessibility(); return; }
        if (!resume && filter!=SelectionRules.MANUAL && !measured) {
            new AlertDialog.Builder(this).setTitle("Faltan los MB")
                    .setMessage("Para ordenar por caché necesitas el permiso de datos de uso. "
                            + "Puedes otorgarlo o limpiar sin orden de tamaño.")
                    .setNegativeButton("Cancelar",null)
                    .setNeutralButton("Limpiar todo el grupo sin analizar",(d,w)-> confirmStart(false))
                    .setPositiveButton("Dar permiso",(d,w)->requestUsage()).show();
            return;
        }
        if (resume) {
            // Respetar las exclusiones actuales incluso en una sesión antigua guardada.
            List<AppTarget> remaining=new ArrayList<>();
            for (AppTarget app : CleaningCheckpoint.remaining(this)) {
                if (!excluded.contains(app.packageName) && (systemApps || !app.system))
                    remaining.add(app);
            }
            if (remaining.isEmpty()) {
                CleaningCheckpoint.clear(this);
                msg("No hay aplicaciones pendientes permitidas."); refresh(); return;
            }
            new AlertDialog.Builder(this).setTitle("Reanudar limpieza")
                    .setMessage("Se volverá a abrir la app donde quedó la limpieza. Solo se pulsará Borrar caché.")
                    .setNegativeButton("Cancelar",null)
                    .setPositiveButton("Reanudar",(d,w)-> {
                        CleaningCheckpoint.start(this, remaining);
                        lastStarted=new ArrayList<>(remaining); verifyAfter=CacheScanner.hasUsageAccess(this);
                        service.startCleaning(new ArrayList<>(remaining)); refresh();
                    }).show();
        } else confirmStart(true);
    }

    private void confirmStart(boolean analyzed) {
        CacheAccessibilityService service=CacheAccessibilityService.instance();
        if(service==null) {requestAccessibility();return;}
        // Sin permiso de uso no se puede conocer el Top N ni filtrar por MB.
        // La alternativa ofrecida recorre TODO el grupo, sin fingir un ranking por caché.
        List<AppTarget> targets = analyzed ? selected() :
                SelectionRules.select(scoped(),true,SelectionRules.MOST_CACHE,0,picked,false);
        if (targets.isEmpty()) { msg("No hay aplicaciones para limpiar."); return; }
        String fallback = analyzed ? "" :
                "Sin medición de MB: se recorrerán todas las apps del grupo, "
                + "sin filtros de tamaño ni Top N.\n\n";
        new AlertDialog.Builder(this).setTitle("Limpiar "+targets.size()+" aplicaciones")
                .setMessage(fallback+"Caché Zeta abrirá los ajustes automáticamente, una app a la vez. "
                        +"Solo pulsará Borrar caché. Mantén el móvil desbloqueado.\n\n"
                        +"Podrás detener y reanudar el recorrido.")
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Empezar",(d,w)-> {
                    CleaningCheckpoint.start(this,targets);
                    lastStarted=new ArrayList<>(targets); verifyAfter=measured; verifying=false;
                    service.startCleaning(new ArrayList<>(targets)); refresh();
                }).show();
    }

    private void verifyResults() {
        if (!CacheScanner.hasUsageAccess(this)||lastStarted.isEmpty()) { verifyAfter=false; return; }
        verifyAfter=false; verifying=true;
        final List<AppTarget> before=new ArrayList<>();
        // No atribuir ahorros a apps omitidas ni a cambios ajenos a nuestra limpieza.
        Set<String> clicked=SessionState.clickedPackages();
        for (AppTarget item : lastStarted) if (clicked.contains(item.packageName)) before.add(item);
        if (before.isEmpty()) { verifying=false; return; }
        worker.execute(()-> {
            List<AppTarget> after=CacheScanner.measure(getApplicationContext(),before,null);
            Map<String,Long> afterCache=new HashMap<>();
            for(AppTarget app:after) afterCache.put(app.packageName,app.cacheBytes);
            long reduced=0; int compared=0;
            for(AppTarget app:before) {
                Long end=afterCache.get(app.packageName);
                if(app.cacheBytes>=0&&end!=null&&end>=0) {
                    reduced+=Math.max(0,app.cacheBytes-end); compared++;
                }
            }
            final long bytes=reduced; final int valid=compared;
            ui.post(()-> {
                verifying=false;
                if (isFinishing() || isDestroyed()) return;
                if (valid>0) SessionState.result += "\nReducción observada: "+CacheScanner.size(bytes)
                        +" en "+valid+" apps pulsadas y medidas. Puede variar por uso posterior.";
                refresh(); analyze();
            });
        });
    }

    private void requestUsage() {
        new AlertDialog.Builder(this).setTitle("Acceso a datos de uso")
                .setMessage("Permite consultar cuántos MB de caché tiene cada app. "
                        +"Se usa únicamente en tu teléfono para ordenar y filtrar. "
                        +"No recopila ni envía datos por Internet.\n\n"
                        +"Activa Caché Zeta en la pantalla que abrirá Android.")
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Continuar",(d,w)-> {
                    awaitingUsage=true;
                    try { startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); }
                    catch(Exception e){msg("No se pudieron abrir los permisos de uso.");}
                }).show();
    }

    private void requestAccessibility() {
        if (CacheAccessibilityService.instance()!=null) { msg("Accesibilidad ya está activada."); return; }
        new AlertDialog.Builder(this).setTitle("Permiso de Accesibilidad")
                .setMessage("Solo cuando pulses Limpiar caché, el servicio leerá los controles de "
                        +"Ajustes para abrir Almacenamiento y pulsar Borrar caché. "
                        +"Puede ver la pantalla según el aviso de Android, pero no se usa para leer "
                        +"mensajes o contraseñas, ni se transmiten datos.\n\n"
                        +"Podrás detener el recorrido y desactivar el permiso cuando quieras.")
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Acepto",(d,w)-> {
                    try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
                    catch(Exception e){msg("No se pudieron abrir los ajustes de Accesibilidad.");}
                }).show();
    }

    private void msg(String message){new AlertDialog.Builder(this).setMessage(message).setPositiveButton("Aceptar",null).show();}
    private TextView text(String str,int sp,int color,boolean bold){
        TextView t=new TextView(this);t.setText(str);t.setTextSize(sp);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }
    private LinearLayout vertical(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout horizontal(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);return v;}
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
