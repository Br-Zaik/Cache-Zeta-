package com.zetacache.app;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/** Estado temporal, solo en memoria; sin métricas engañosas de MB liberados. */
public final class SessionState {
    private SessionState() {}
    public static volatile boolean running = false;
    public static volatile int total = 0;
    public static volatile int index = 0;
    public static volatile int pressed = 0;
    public static volatile int skipped = 0;
    public static volatile String appName = "";
    public static volatile long cachePlanned = -1L;
    public static volatile String result = "Sin limpiezas todavía.";
    public static volatile String stopReason = "";
    private static final Set<String> clicked = Collections.synchronizedSet(new HashSet<>());

    public static void clicked(String packageName) {
        if (packageName != null && !packageName.isEmpty()) clicked.add(packageName);
        pressed++;
    }
    public static Set<String> clickedPackages() {
        synchronized (clicked) { return new HashSet<>(clicked); }
    }

    public static void begin(int count) {
        total = count;
        stopReason = "";
        index = 0;
        pressed = 0;
        clicked.clear();
        skipped = 0;
        appName = "Preparando…";
        result = "";
        cachePlanned = -1L;
        running = true;
    }

    public static void finish(boolean cancelled) {
        running = false;
        appName = "";
        String cause = stopReason.isEmpty() ? "" : stopReason + ". ";
        result = (cancelled ? "Limpieza detenida. " + cause : "Recorrido terminado. ")
                + "Botones de caché pulsados: " + pressed + ". "
                + "Apps omitidas: " + skipped + ". "
                + "Android puede impedir la limpieza de algunas apps.";
    }
}
