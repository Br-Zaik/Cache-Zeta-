package com.zetacache.app;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/** Native views arranged from the approved 392 x 850 design, excluding system bars.
 * One layout adapts to the available window; no bitmaps, WebView or frame animations.
 */
public final class DesignLayout extends ViewGroup {
    private static final float WIDTH=392f, HEIGHT=802f;
    private final List<Item> items=new ArrayList<>();
    private static final class Item {
        final View view;
        final float x,y,w,h,sp;
        final int[] iconWidths=new int[4],iconHeights=new int[4];
        Item(View v,float x,float y,float w,float h,float sp) {
            view=v;this.x=x;this.y=y-32;this.w=w;this.h=h;this.sp=sp;
            if(v instanceof TextView) {
                Drawable[] icons=((TextView)v).getCompoundDrawables();
                for(int i=0;i<4;i++)if(icons[i]!=null){
                    iconWidths[i]=icons[i].getBounds().width();
                    iconHeights[i]=icons[i].getBounds().height();
                }
            }
        }
    }
    public DesignLayout(Context c){super(c);setClipToPadding(true);}
    public void place(View v,float x,float y,float w,float h) {
        float sp=v instanceof TextView ? ((TextView)v).getTextSize()/getResources().getDisplayMetrics().scaledDensity : 0;
        items.add(new Item(v,x,y,w,h,sp));
        addView(v,new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
    }
    @Override protected void onMeasure(int widthSpec,int heightSpec) {
        int width=MeasureSpec.getSize(widthSpec),height=MeasureSpec.getSize(heightSpec);
        setMeasuredDimension(width,height);
        float sx=Math.max(1,width-getPaddingLeft()-getPaddingRight())/WIDTH;
        float sy=Math.max(1,height-getPaddingTop()-getPaddingBottom())/HEIGHT;
        float density=getResources().getDisplayMetrics().density;
        float textScale=Math.min(sx,Math.max(sy,sx*.86f))/density;
        for(Item item:items) {
            if(item.view instanceof TextView) {
                TextView text=(TextView)item.view;
                float px=TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP,item.sp*textScale,getResources().getDisplayMetrics());
                if(Math.abs(text.getTextSize()-px)>.1f)text.setTextSize(TypedValue.COMPLEX_UNIT_PX,px);
                Drawable[] icons=text.getCompoundDrawables();
                for(int i=0;i<4;i++)if(icons[i]!=null)icons[i].setBounds(0,0,
                        Math.round(item.iconWidths[i]*textScale),Math.round(item.iconHeights[i]*textScale));
            }
            item.view.measure(MeasureSpec.makeMeasureSpec(Math.max(1,Math.round(item.w*sx)),MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(Math.max(1,Math.round(item.h*sy)),MeasureSpec.EXACTLY));
        }
    }
    @Override protected void onLayout(boolean changed,int l,int t,int r,int b) {
        float sx=Math.max(1,getWidth()-getPaddingLeft()-getPaddingRight())/WIDTH;
        float sy=Math.max(1,getHeight()-getPaddingTop()-getPaddingBottom())/HEIGHT;
        for(Item item:items){
            int x=getPaddingLeft()+Math.round(item.x*sx),y=getPaddingTop()+Math.round(item.y*sy);
            item.view.layout(x,y,x+item.view.getMeasuredWidth(),y+item.view.getMeasuredHeight());
        }
    }
}
