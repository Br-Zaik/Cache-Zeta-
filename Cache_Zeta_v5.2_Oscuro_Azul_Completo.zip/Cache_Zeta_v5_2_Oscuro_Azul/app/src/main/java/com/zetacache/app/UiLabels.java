package com.zetacache.app;

import java.text.Normalizer;
import java.util.Locale;

/** Coincidencias exactas de acciones permitidas. Nunca incluye 'borrar datos'. */
public final class UiLabels {
    private UiLabels() {}

    static String norm(CharSequence original) {
        if (original == null) return "";
        return Normalizer.normalize(original.toString(), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .toLowerCase(Locale.ROOT)
                .replace('&', 'y')
                .replaceAll("\\s+", " ")
                .trim();
    }

    public static boolean isStorage(CharSequence label) {
        String text = norm(label);
        return text.equals("almacenamiento")
                || text.equals("almacenamiento y cache")
                || text.equals("uso de almacenamiento")
                || text.equals("storage")
                || text.equals("storage y cache")
                || text.equals("storage & cache")
                || text.equals("storage and cache")
                || text.equals("storage usage")
                || text.equals("espacio de almacenamiento y cache")
                || text.equals("almacenamiento y memoria cache")
                || text.equals("storage and cached data")
                || text.equals("存储和缓存")
                || text.equals("存储空间")
                || text.equals("ストレージとキャッシュ")
                || text.equals("저장공간 및 캐시")
                || text.equals("хранилище и кеш")
                || text.equals("uso de memoria")
                || text.equals("almacenamiento y datos")
                || text.equals("armazenamento")
                || text.equals("armazenamento e cache")
                || text.equals("stockage")
                || text.equals("speicher")
                || text.equals("memoria e cache");
    }

    public static boolean isClearCache(CharSequence label) {
        String text = norm(label);
        return text.equals("borrar memoria cache")
                || text.equals("borrar cache")
                || text.equals("eliminar cache")
                || text.equals("clear cache")
                || text.equals("limpiar cache")
                || text.equals("vaciar cache")
                || text.equals("limpar cache")
                || text.equals("limpar memoria cache")
                || text.equals("vider le cache")
                || text.equals("cache leeren")
                || text.equals("svuota cache")
                || text.equals("очистить кеш")
                || text.equals("очистить кэш")
                || text.equals("清除缓存")
                || text.equals("キャッシュを削除")
                || text.equals("캐시 삭제");
    }

    public static boolean isDangerous(CharSequence label) {
        String t = norm(label);
        return t.equals("borrar datos") || t.equals("borrar almacenamiento")
                || t.equals("liberar espacio") || t.equals("clear data")
                || t.equals("clear storage") || t.equals("erase data")
                || t.equals("effacer les donnees") || t.equals("limpar dados")
                || t.equals("daten loschen") || t.equals("cancella dati")
                || t.equals("borrar todos los datos")
                || t.equals("eliminar datos")
                || t.equals("delete app data")
                || t.equals("clear all data")
                || t.equals("clear data and cache")
                || t.equals("清除数据")
                || t.equals("データを削除")
                || t.equals("데이터 삭제");
    }
}
