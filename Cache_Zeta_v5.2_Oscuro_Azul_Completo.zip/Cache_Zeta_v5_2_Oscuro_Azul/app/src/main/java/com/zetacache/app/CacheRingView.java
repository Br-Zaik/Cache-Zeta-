package com.zetacache.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.view.View;

/** Indicador vectorial ligero: el arco no simula porcentajes de caché. */
public final class CacheRingView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private long bytes = -1;
    private boolean scanning = false;
    private int progress = 0;

    public CacheRingView(Context context) { super(context); }

    public void show(long cacheBytes, boolean loading, int percent) {
        int nextProgress = Math.max(0, Math.min(100, percent));
        if(bytes==cacheBytes && scanning==loading && progress==nextProgress)return;
        bytes = cacheBytes;
        scanning = loading;
        progress = nextProgress;
        String value = scanning ? "Analizando" : bytes < 0 ? "Sin analizar" : CacheScanner.size(bytes);
        setContentDescription("Caché medida: " + value);
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w=getWidth(), h=getHeight();
        if (w<=0 || h<=0) return;
        float scale = getResources().getDisplayMetrics().density;
        float cx=w/2, cy=h/2;
        float radius=Math.min(w,h)*0.39f;
        float stroke=Math.max(scale*7, radius*0.115f);
        RectF circle=new RectF(cx-radius,cy-radius,cx+radius,cy+radius);
        paint.reset(); paint.setAntiAlias(true); paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeWidth(stroke);
        paint.setColor(Color.rgb(21,68,90)); canvas.drawArc(circle, -90, 360,false,paint);
        float sweep=scanning?Math.max(6, progress*3.0f):300f;
        paint.setColor(0x5535F0E4); paint.setStrokeWidth(stroke+scale*5);
        canvas.drawArc(circle,-90,sweep,false,paint);
        paint.setShader(new SweepGradient(cx,cy,new int[]{0xFF0B81BF,0xFF00E4EF,0xFF25FFD8,0xFF0B81BF},null));
        paint.setStrokeWidth(stroke); canvas.save();canvas.rotate(-90,cx,cy);
        canvas.drawArc(circle,0,sweep,false,paint);canvas.restore();paint.setShader(null);

        // Pequeño pictograma de almacenamiento, trazado nativo sin imagen pesada.
        float iconY=cy-radius*0.45f, iw=radius*0.29f, ih=radius*0.15f;
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(1.6f*scale,radius*0.035f));
        paint.setColor(0xFF10E5E9);
        canvas.drawOval(cx-iw,iconY-ih,cx+iw,iconY+ih,paint);
        canvas.drawArc(cx-iw,iconY+ih*.1f,cx+iw,iconY+ih*2.2f,0,180,false,paint);
        canvas.drawLine(cx-iw,iconY,cx-iw,iconY+ih*1.4f,paint);
        canvas.drawLine(cx+iw,iconY,cx+iw,iconY+ih*1.4f,paint);

        paint.setStyle(Paint.Style.FILL);paint.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        paint.setTextAlign(Paint.Align.CENTER);paint.setColor(0xFFF5FBFF);
        String value;
        if(scanning) value=progress+"%";
        else if(bytes<0) value="—";
        else value=CacheScanner.size(bytes);
        float font=radius*0.37f;
        if(value.length()>7) font=radius*0.28f;
        font=Math.min(font,26*scale);
        paint.setTextSize(font);
        canvas.drawText(value,cx,cy+radius*0.19f,paint);
        paint.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
        paint.setColor(0xFFB7D0E1);paint.setTextSize(Math.min(radius*.23f,12*scale));
        canvas.drawText(scanning?"Analizando":bytes<0?"Sin analizar":"Caché medida",cx,cy+radius*0.49f,paint);
    }
}
