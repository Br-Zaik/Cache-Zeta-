package com.zetacache.app;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Environment;
import android.os.StatFs;

import java.util.Locale;

/** Datos reales del teléfono. Solo consulta APIs públicas; no libera RAM artificialmente. */
public final class GameInfo {
    public final long ramAvailable, ramTotal;
    public final boolean memoryLow;
    public final long storageAvailable, storageTotal;
    public final int batteryPercent;
    public final float batteryCelsius;

    GameInfo(long ramAvailable, long ramTotal, boolean memoryLow,
             long storageAvailable, long storageTotal,
             int batteryPercent, float batteryCelsius) {
        this.ramAvailable = ramAvailable;
        this.ramTotal = ramTotal;
        this.memoryLow = memoryLow;
        this.storageAvailable = storageAvailable;
        this.storageTotal = storageTotal;
        this.batteryPercent = batteryPercent;
        this.batteryCelsius = batteryCelsius;
    }

    public static GameInfo read(Context context) {
        long available = -1, total = -1;
        boolean low = false;
        try {
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null) {
                ActivityManager.MemoryInfo memory = new ActivityManager.MemoryInfo();
                am.getMemoryInfo(memory);
                available = memory.availMem;
                total = memory.totalMem;
                low = memory.lowMemory;
            }
        } catch (Exception ignored) { }
        long freeStorage = -1, totalStorage = -1;
        try {
            StatFs fs = new StatFs(Environment.getDataDirectory().getAbsolutePath());
            freeStorage = fs.getAvailableBytes();
            totalStorage = fs.getTotalBytes();
        } catch (Exception ignored) { }
        int percent = -1;
        float celsius = Float.NaN;
        try {
            Intent battery = context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (battery != null) {
                int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                if (level >= 0 && scale > 0) percent = Math.round(level * 100f / scale);
                int temp = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
                if (temp != Integer.MIN_VALUE) celsius = temp / 10f;
            }
        } catch (Exception ignored) { }
        return new GameInfo(available, total, low, freeStorage, totalStorage, percent, celsius);
    }

    public String memoryLabel() {
        if (ramAvailable < 0 || ramTotal <= 0) return "No disponible";
        return formatGiB(ramAvailable) + " de " + formatGiB(ramTotal);
    }
    public String storageLabel() {
        if (storageAvailable < 0 || storageTotal <= 0) return "No disponible";
        return formatGiB(storageAvailable) + " de " + formatGiB(storageTotal);
    }
    public String batteryLabel() { return batteryPercent < 0 ? "No disponible" : batteryPercent + "%"; }
    public String temperatureLabel() {
        return Float.isNaN(batteryCelsius) ? "No disponible"
                : String.format(Locale.getDefault(), "%.1f °C", batteryCelsius);
    }
    static String formatGiB(long bytes) {
        if (bytes < 0) return "No disponible";
        return String.format(Locale.getDefault(), "%.1f GB", bytes / 1073741824d);
    }
}
