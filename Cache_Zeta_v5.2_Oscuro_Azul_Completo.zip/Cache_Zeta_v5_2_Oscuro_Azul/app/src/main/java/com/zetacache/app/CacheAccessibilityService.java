package com.zetacache.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.content.pm.ApplicationInfo;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Automatización determinista de dos botones dentro de Ajustes.
 * Jamás pulsa Borrar datos, Liberar espacio o botones de confirmación genéricos.
 * No ejecuta nada sin el toque explícito del usuario en Empezar.
 */
public final class CacheAccessibilityService extends AccessibilityService {
    private static volatile CacheAccessibilityService activeInstance;
    private static final long LAUNCH_SETTLE_MS = 650;
    private static final long SCREEN_TIMEOUT_MS = 10500;
    private static final long NEXT_APP_PAUSE_MS = 470;

    private enum Stage { IDLE, APP_INFO, STORAGE, TRANSITION }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<AppTarget> targets = new ArrayList<>();
    private Stage stage = Stage.IDLE;
    private int position = -1;
    private long stageStarted, launchedAt, lastScan, outsideSettingsSince;
    private String settingsPackage = "";
    private boolean gesturePending = false;
    private boolean triedScroll = false;
    private int retries = 0;
    private WindowManager windowManager;
    private LinearLayout overlay;
    private TextView overlayLabel;

    private final Runnable heartbeat = new Runnable() {
        @Override public void run() {
            if (!SessionState.running) return;
            checkCurrentScreen();
            if (SessionState.running) handler.postDelayed(this, 420);
        }
    };

    public static CacheAccessibilityService instance() { return activeInstance; }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        activeInstance = this;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!SessionState.running) return;
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                || event.getEventType() == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            long now = SystemClock.elapsedRealtime();
            if (now - lastScan >= 360) checkCurrentScreen();
        }
    }

    @Override public void onInterrupt() {
        if (!SessionState.running) return;
        SessionState.stopReason = "Accesibilidad interrumpida por Android";
        finishSession(true);
    }

    @Override public void onDestroy() {
        if (SessionState.running) {
            SessionState.stopReason = "Servicio cerrado por Android";
            SessionState.finish(true);
            HistoryStore.add(this, true, SessionState.pressed, SessionState.skipped);
        }
        stage = Stage.IDLE;
        handler.removeCallbacksAndMessages(null);
        removeOverlay();
        if (activeInstance == this) activeInstance = null;
        super.onDestroy();
    }

    /** Invocado desde el botón de la app; nunca automáticamente al activar el servicio. */
    public void startCleaning(List<AppTarget> selected) {
        if (SessionState.running || selected == null || selected.isEmpty()) return;
        targets.clear();
        targets.addAll(selected);
        position = -1;
        lastScan = 0;
        settingsPackage = "";
        outsideSettingsSince = 0;
        gesturePending = false;
        triedScroll = false;
        SessionState.begin(targets.size());
        makeOverlay();
        openNext();
        handler.removeCallbacks(heartbeat);
        handler.postDelayed(heartbeat, 480);
    }

    public void cancel() {
        if (!SessionState.running) return;
        SessionState.stopReason = "Detenida manualmente";
        finishSession(true);
    }

    private void openNext() {
        if (!SessionState.running) return;
        position++;
        if (position >= targets.size()) { finishSession(false); return; }
        CleaningCheckpoint.advance(this, position);
        retries = 0;
        openCurrent();
    }

    private void openCurrent() {
        if (!SessionState.running || position < 0 || position >= targets.size()) return;
        AppTarget target = targets.get(position);
        SessionState.index = position + 1;
        SessionState.appName = target.label;
        updateOverlay();
        stage = Stage.APP_INFO;
        stageStarted = SystemClock.elapsedRealtime();
        launchedAt = stageStarted;
        outsideSettingsSince = 0;
        triedScroll = false;
        gesturePending = false;
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + target.packageName));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            ResolveInfo handlerInfo = getPackageManager().resolveActivity(intent, 0);
            settingsPackage = "";
            // Nunca confiar en una app de terceros que se haga pasar por Ajustes.
            if (handlerInfo != null && handlerInfo.activityInfo != null
                    && handlerInfo.activityInfo.applicationInfo != null) {
                int flags = handlerInfo.activityInfo.applicationInfo.flags;
                if ((flags & (ApplicationInfo.FLAG_SYSTEM
                        | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0)
                    settingsPackage = handlerInfo.activityInfo.packageName;
            }
            startActivity(intent);
        } catch (Exception ignored) { skipCurrent(); }
    }

    private void checkCurrentScreen() {
        if (!SessionState.running || stage == Stage.IDLE || stage == Stage.TRANSITION || gesturePending) return;
        long now = SystemClock.elapsedRealtime();
        lastScan = now;
        if (now - launchedAt < LAUNCH_SETTLE_MS) return;
        if (now - stageStarted > SCREEN_TIMEOUT_MS) {
            // Pantallas lentas: un reintento por app; después omitir, no detener toda la cola.
            if (retries++ == 0) openCurrent(); else skipCurrent();
            return;
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || !isSettings(root)) {
            // Si el usuario sale de Ajustes, no seguimos navegando sin él.
            if (now - launchedAt > 2000) {
                if (outsideSettingsSince == 0) outsideSettingsSince = now;
                else if (now - outsideSettingsSince > 5500) {
                    SessionState.stopReason = "Se salió de los Ajustes";
                    finishSession(true);
                }
            }
            return;
        }
        outsideSettingsSince = 0;

        if (stage == Stage.APP_INFO) {
            // No tocar ninguna otra app: comprobar la cabecera del paquete abierto.
            if (!containsCurrentAppLabel(root)) return;
            AccessibilityNodeInfo storage = findMatchingNode(root, true);
            if (storage != null) {
                if (!activate(storage,
                        () -> {
                            if (!SessionState.running || stage != Stage.APP_INFO) return;
                            stage = Stage.STORAGE;
                            stageStarted = SystemClock.elapsedRealtime();
                        }, this::skipCurrent)) skipCurrent();
            } else if (!triedScroll && now - stageStarted > 1800) {
                triedScroll = true;
                scrollForward(root);
            }
        } else if (stage == Stage.STORAGE) {
            // En el teléfono probado el almacenamiento incluye el nombre de la app.
            // Evita pulsar Borrar caché en la página de otra app si el SO cambió de ventana.
            if (!containsCurrentAppLabel(root)) return;
            AccessibilityNodeInfo clearCache = findMatchingNode(root, false);
            if (clearCache != null) {
                if (!activate(clearCache,
                        () -> {
                            if (!SessionState.running || stage != Stage.STORAGE) return;
                            // Cuenta acciones de pulsación, no bytes liberados.
                            SessionState.clicked(targets.get(position).packageName);
                            nextSoon();
                        }, this::skipCurrent)) skipCurrent();
            }
        }
    }

    private boolean isSettings(AccessibilityNodeInfo root) {
        CharSequence pkgValue = root.getPackageName();
        if (pkgValue == null) return false;
        String pkg = pkgValue.toString().toLowerCase(Locale.ROOT);
        if (pkg.equals(getPackageName())) return false;
        // Para uso personal solo aceptar Ajustes real o su manejador resuelto.
        return pkg.equals("com.android.settings")
                || pkg.equals("com.samsung.android.settings")
                || (!settingsPackage.isEmpty() && pkg.equals(settingsPackage));
    }

    private boolean containsCurrentAppLabel(AccessibilityNodeInfo root) {
        if (position < 0 || position >= targets.size()) return false;
        AppTarget target = targets.get(position);
        String wanted = UiLabels.norm(target.label);
        String packageName = UiLabels.norm(target.packageName);
        ArrayDeque<AccessibilityNodeInfo> nodes = new ArrayDeque<>();
        nodes.add(root);
        int seen = 0;
        while (!nodes.isEmpty() && seen++ < 400) {
            AccessibilityNodeInfo node = nodes.removeFirst();
            if (node.isVisibleToUser()) {
                String text = UiLabels.norm(node.getText());
                String desc = UiLabels.norm(node.getContentDescription());
                if (text.equals(wanted) || desc.equals(wanted)
                        || text.equals(packageName) || desc.equals(packageName)) return true;
            }
            addChildren(nodes, node);
        }
        return false;
    }

    private AccessibilityNodeInfo findMatchingNode(AccessibilityNodeInfo root, boolean storage) {
        ArrayDeque<AccessibilityNodeInfo> nodes = new ArrayDeque<>();
        nodes.add(root);
        int visited = 0;
        while (!nodes.isEmpty() && visited++ < 350) {
            AccessibilityNodeInfo node = nodes.removeFirst();
            if (node.isVisibleToUser()) {
                CharSequence name = node.getText();
                CharSequence desc = node.getContentDescription();
                if (storage ? (UiLabels.isStorage(name) || UiLabels.isStorage(desc))
                            : (UiLabels.isClearCache(name) || UiLabels.isClearCache(desc))) {
                    return node;
                }
            }
            addChildren(nodes, node);
        }
        return null;
    }

    private void addChildren(ArrayDeque<AccessibilityNodeInfo> list, AccessibilityNodeInfo node) {
        for (int i = 0; i < node.getChildCount() && i < 45; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) list.addLast(child);
        }
    }

    /** Primero pulsa el botón accesible; si no existe, intenta toque por coordenadas.
     * Nunca usa coordenadas fijas: solo el rectángulo del nodo de texto exacto.
     */
    private boolean activate(AccessibilityNodeInfo start, Runnable success, Runnable failure) {
        if (!start.isEnabled() || !start.isVisibleToUser()) return false;
        AccessibilityNodeInfo node = start;
        for (int level = 0; level < 5 && node != null; level++) {
            if (node.isClickable()) {
                if (!node.isEnabled()) return false;
                // No pulsar un contenedor que englobe Borrar datos / Liberar espacio.
                if (containsUnsafeAction(node)) break;
                if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    success.run();
                    return true;
                }
            }
            node = node.getParent();
        }
        Rect rect = new Rect();
        start.getBoundsInScreen(rect);
        if (rect.isEmpty() || rect.centerX() < 0 || rect.centerY() < 0) return false;
        Path path = new Path();
        path.moveTo(rect.centerX(), rect.centerY());
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 95)).build();
        gesturePending = true;
        boolean accepted = dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription desc) {
                gesturePending = false;
                success.run();
            }
            @Override public void onCancelled(GestureDescription desc) {
                gesturePending = false;
                failure.run();
            }
        }, handler);
        if (!accepted) gesturePending = false;
        return accepted;
    }

    private boolean containsUnsafeAction(AccessibilityNodeInfo ancestor) {
        ArrayDeque<AccessibilityNodeInfo> nodes = new ArrayDeque<>();
        nodes.add(ancestor);
        int seen = 0;
        while (!nodes.isEmpty() && seen++ < 90) {
            AccessibilityNodeInfo node = nodes.removeFirst();
            if (UiLabels.isDangerous(node.getText()) || UiLabels.isDangerous(node.getContentDescription()))
                return true;
            addChildren(nodes, node);
        }
        return false;
    }

    /** Un solo intento de scroll: algunos fabricantes sitúan almacenamiento al final. */
    private void scrollForward(AccessibilityNodeInfo root) {
        ArrayDeque<AccessibilityNodeInfo> nodes = new ArrayDeque<>();
        nodes.add(root);
        int scanned = 0;
        while (!nodes.isEmpty() && scanned++ < 350) {
            AccessibilityNodeInfo node = nodes.removeFirst();
            if (node.isScrollable() && node.isVisibleToUser()
                    && node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) return;
            addChildren(nodes, node);
        }
    }

    private void skipCurrent() {
        if (!SessionState.running || stage == Stage.TRANSITION) return;
        SessionState.skipped++;
        nextSoon();
    }

    private void nextSoon() {
        stage = Stage.TRANSITION; // evita varios clics durante animaciones
        updateOverlay();
        handler.postDelayed(this::openNext, NEXT_APP_PAUSE_MS);
    }

    private void finishSession(boolean cancelled) {
        handler.removeCallbacksAndMessages(null);
        stage = Stage.IDLE;
        gesturePending = false;
        targets.clear();
        SessionState.finish(cancelled);
        HistoryStore.add(this, cancelled, SessionState.pressed, SessionState.skipped);
        if (!cancelled) CleaningCheckpoint.clear(this);
        removeOverlay();
        Intent showApp = new Intent(this, MainActivity.class);
        showApp.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try { startActivity(showApp); } catch (Exception ignored) { }
    }

    private void makeOverlay() {
        removeOverlay();
        try {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            overlay = new LinearLayout(this);
            overlay.setOrientation(LinearLayout.HORIZONTAL);
            overlay.setGravity(Gravity.CENTER_VERTICAL);
            overlay.setPadding(dp(15), dp(9), dp(9), dp(9));
            GradientDrawable background = new GradientDrawable();
            background.setColor(Color.rgb(14, 27, 43));
            background.setCornerRadius(dp(22));
            background.setStroke(dp(1), Color.rgb(57, 110, 108));
            overlay.setBackground(background);
            overlay.setElevation(dp(12));
            overlayLabel = new TextView(this);
            overlayLabel.setTextColor(Color.WHITE);
            overlayLabel.setTextSize(12);
            overlayLabel.setMaxLines(2);
            overlayLabel.setText("Caché Zeta");
            LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(0, -2, 1f);
            overlay.addView(overlayLabel, labelParams);
            TextView stop = new TextView(this);
            stop.setText("DETENER");
            stop.setTextSize(12);
            stop.setTextColor(Color.rgb(10, 16, 32));
            stop.setTypeface(null, 1);
            stop.setPadding(dp(14), dp(12), dp(14), dp(12));
            stop.setGravity(Gravity.CENTER);
            stop.setContentDescription("Detener limpieza de caché");
            GradientDrawable stopBackground = new GradientDrawable();
            stopBackground.setColor(Color.rgb(84, 241, 203));
            stopBackground.setCornerRadius(dp(14));
            stop.setBackground(stopBackground);
            stop.setOnClickListener(v -> cancel());
            LinearLayout.LayoutParams stopParams = new LinearLayout.LayoutParams(-2, -2);
            stopParams.leftMargin = dp(15);
            overlay.addView(stop, stopParams);
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    getResources().getDisplayMetrics().widthPixels - dp(30), -2,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            params.y = dp(38);
            windowManager.addView(overlay, params);
            updateOverlay();
        } catch (Exception ignored) {
            removeOverlay();
        }
    }

    private void updateOverlay() {
        if (overlayLabel != null) {
            overlayLabel.setText("Caché Zeta · " + SessionState.index + "/" + SessionState.total
                    + "\n" + SessionState.appName);
        }
    }

    private void removeOverlay() {
        if (overlay != null && windowManager != null) {
            try { windowManager.removeView(overlay); } catch (Exception ignored) { }
        }
        overlay = null;
        overlayLabel = null;
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
