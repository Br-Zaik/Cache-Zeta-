package com.zetacache.app;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Reglas puras y fáciles de probar; nunca confunden datos de usuario con caché. */
public final class SelectionRules {
    public static final int MOST_CACHE = 0;
    public static final int OVER_10 = 1;
    public static final int OVER_50 = 2;
    public static final int OVER_100 = 3;
    public static final int MANUAL = 4;
    private SelectionRules() {}

    public static List<AppTarget> select(List<AppTarget> all, boolean includeSystem,
                                         int filter, int maxCount, Set<String> manuallySelected,
                                         boolean measured) {
        ArrayList<AppTarget> result = new ArrayList<>();
        for (AppTarget app : all) {
            if (!includeSystem && app.system) continue;
            if (filter == MANUAL) {
                if (manuallySelected == null || !manuallySelected.contains(app.packageName)) continue;
            } else if (measured) {
                if (app.cacheBytes <= 0) continue;
                if (app.cacheBytes <= threshold(filter)) continue;
            } else if (filter != MOST_CACHE) {
                continue; // Sin medir, jamás inventar tamaños MB.
            }
            result.add(app);
        }
        if (measured) {
            result.sort((a, b) -> {
                int c = Long.compare(b.cacheBytes, a.cacheBytes);
                return c != 0 ? c : a.label.compareToIgnoreCase(b.label);
            });
        } else {
            result.sort(Comparator.comparing(a -> a.label.toLowerCase(java.util.Locale.ROOT)));
        }
        if (maxCount > 0 && result.size() > maxCount)
            return new ArrayList<>(result.subList(0, maxCount));
        return result;
    }

    public static long threshold(int filter) {
        if (filter == OVER_10) return 10L * 1024L * 1024L;
        if (filter == OVER_50) return 50L * 1024L * 1024L;
        if (filter == OVER_100) return 100L * 1024L * 1024L;
        return -1L;
    }

    public static long totalKnownCache(List<AppTarget> apps) {
        long sum = 0;
        for (AppTarget a : apps) if (a.cacheBytes > 0 && Long.MAX_VALUE - sum >= a.cacheBytes)
            sum += a.cacheBytes;
        return sum;
    }
}
