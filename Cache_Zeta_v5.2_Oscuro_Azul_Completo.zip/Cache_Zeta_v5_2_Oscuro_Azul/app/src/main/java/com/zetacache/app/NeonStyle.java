package com.zetacache.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;

/** Flat native drawables matching the approved dark-blue design. */
public final class NeonStyle {
    public static final int BG=0xFF111318, PANEL=0xFF1E222B, BLUE=0xFF23304A;
    public static final int TEXT=0xFFF1F4FB, MUTED=0xFF9DA6B6;
    public static final int CYAN=0xFF91B0FF, TEAL=CYAN, BORDER=0xFF363D4C;
    public static final int SOFT=0xFF2B303B, SELECTED=0xFF2D3C58, ON_ACCENT=0xFF142644;
    private NeonStyle(){}
    public static GradientDrawable solid(Context c,int color,float radius,int border){
        GradientDrawable d=new GradientDrawable();d.setColor(color);
        d.setCornerRadius(radius*c.getResources().getDisplayMetrics().density);
        if(border!=0)d.setStroke(Math.max(1,Math.round(c.getResources().getDisplayMetrics().density)),border);
        return d;
    }
    public static GradientDrawable background(Context c){return solid(c,BG,0,0);}
    public static GradientDrawable hero(Context c){return solid(c,BLUE,24,0);}
    public static GradientDrawable card(Context c){return solid(c,PANEL,20,0);}
    public static GradientDrawable chip(Context c,boolean selected){return solid(c,selected?SELECTED:PANEL,10,selected?CYAN:BORDER);}
    public static GradientDrawable scope(Context c,boolean selected){return solid(c,selected?PANEL:SOFT,10,0);}
    public static GradientDrawable primary(Context c){return solid(c,CYAN,15,0);}
    public static GradientDrawable secondary(Context c){return solid(c,BG,14,BORDER);}
    public static RippleDrawable ripple(android.graphics.drawable.Drawable d){
        return new RippleDrawable(ColorStateList.valueOf(0x2291B0FF),d,null);
    }
}
