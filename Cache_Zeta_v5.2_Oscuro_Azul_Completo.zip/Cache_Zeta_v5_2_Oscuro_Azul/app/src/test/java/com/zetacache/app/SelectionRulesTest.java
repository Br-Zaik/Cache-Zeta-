package com.zetacache.app;

import org.junit.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import static org.junit.Assert.*;

public final class SelectionRulesTest {
    @Test public void top5OrdenadoPorCache() {
        List<AppTarget> a=Arrays.asList(
                new AppTarget("a","A",false,40_000_000),
                new AppTarget("b","B",false,90_000_000),
                new AppTarget("c","C",true,120_000_000),
                new AppTarget("d","D",false,0));
        List<AppTarget> result=SelectionRules.select(a,false,SelectionRules.MOST_CACHE,2,
                Collections.emptySet(),true);
        assertEquals(2,result.size());
        assertEquals("b",result.get(0).packageName);
        assertEquals("a",result.get(1).packageName);
    }
    @Test public void filtroUmbralYDesconocidos() {
        List<AppTarget> a=Arrays.asList(
                new AppTarget("a","A",false,-1),
                new AppTarget("b","B",false,1024),
                new AppTarget("c","C",false,60L*1048576));
        List<AppTarget> result=SelectionRules.select(a,true,SelectionRules.OVER_50,0,
                Collections.emptySet(),true);
        assertEquals(1,result.size());
        assertEquals("c",result.get(0).packageName);
    }
    @Test public void manualNoSeleccionaTodos() {
        List<AppTarget> a=Arrays.asList(
                new AppTarget("a","A",false,0),
                new AppTarget("b","B",false,0));
        List<AppTarget> result=SelectionRules.select(a,true,SelectionRules.MANUAL,0,
                new HashSet<>(Arrays.asList("b")),false);
        assertEquals(1,result.size()); assertEquals("b",result.get(0).packageName);
    }
    @Test public void sinMedicionNoInventarMB() {
        List<AppTarget> a=Arrays.asList(new AppTarget("a","A",false,-1));
        assertTrue(SelectionRules.select(a,true,SelectionRules.OVER_10,0,
                Collections.emptySet(),false).isEmpty());
    }
}
