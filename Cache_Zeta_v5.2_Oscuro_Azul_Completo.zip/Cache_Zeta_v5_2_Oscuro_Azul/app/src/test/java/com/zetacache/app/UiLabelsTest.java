package com.zetacache.app;

import org.junit.Test;
import static org.junit.Assert.*;

public class UiLabelsTest {
    @Test public void nombresPermitidos() {
        assertTrue(UiLabels.isClearCache("BORRAR MEMORIA CACHÉ"));
        assertTrue(UiLabels.isClearCache("Borrar caché"));
        assertTrue(UiLabels.isClearCache("Clear cache"));
        assertTrue(UiLabels.isStorage("Almacenamiento y caché"));
        assertTrue(UiLabels.isStorage("Storage & cache"));
        assertTrue(UiLabels.isStorage("Almacenamiento"));
    }

    @Test public void nuncaConfundirConBorrarDatos() {
        assertFalse(UiLabels.isClearCache("Borrar datos"));
        assertFalse(UiLabels.isClearCache("Borrar almacenamiento"));
        assertFalse(UiLabels.isClearCache("Liberar espacio de almacenamiento"));
        assertFalse(UiLabels.isClearCache("Clear storage"));
        assertFalse(UiLabels.isClearCache("Clear data"));
        assertFalse(UiLabels.isClearCache("Clear cache and data"));
        assertFalse(UiLabels.isClearCache("Borrar caché y datos"));
        assertFalse(UiLabels.isClearCache("Eliminar"));
        assertFalse(UiLabels.isClearCache("OK"));
    }

    @Test public void coincidenciasExactasParaNavegar() {
        assertFalse(UiLabels.isStorage("Almacenamiento de archivos privados"));
        assertFalse(UiLabels.isStorage("Fotos y almacenamiento"));
        assertFalse(UiLabels.isStorage("Desinstalar"));
    }
}
