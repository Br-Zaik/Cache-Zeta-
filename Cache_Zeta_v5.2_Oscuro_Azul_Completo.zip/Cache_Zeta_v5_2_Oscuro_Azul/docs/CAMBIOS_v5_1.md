# Caché Zeta v5.1 — auditoría y mejoras

**Objetivo:** perfeccionar la v5 sin cambiar la interfaz elegida ni introducir funcionalidades ficticias.

## Corregido

1. Filtro por MB sin permiso: antes la alternativa «Limpiar sin análisis» podía dejar lista vacía, y el botón podía aparecer deshabilitado. Ahora permite elegir explícitamente limpiar **todas** las apps del grupo sin orden Top.
2. Ahorro estimado: antes se comparaban apps omitidas; ahora solo los paquetes donde se realizó la pulsación de caché.
3. Reanudación: aplica exclusiones vigentes antes de iniciar, y descarta cola vacía.
4. Automatización: en almacenamiento exige que la pantalla identifique la aplicación actual. Si el fabricante no muestra el nombre, **omite** por seguridad.
5. Interrupciones: distingue detención manual, salida de Ajustes, cierre del servicio e interrupción del servicio.
6. Indicador circular: etiqueta «Caché medida», no total garantizado.

## Ya conservado de la v5

- Interfaz NEO fija y adaptativa, azul oscuro/cian, controles principales sin desplazamiento.
- Todas las apps o instaladas por mí, Top 5/10/20/50/Todas, filtros 10/50/100 MB, selección y exclusiones.
- Datos de uso para escaneo local en segundo plano; permiso de Accesibilidad separado y cancelable.
- Cola reanudable, botón flotante Detener, historial local.
- Juegos: información verdadera de RAM, batería y temperatura de batería, espacio libre, favoritos y acceso a No molestar.

## Pruebas pendientes (necesitan APK compilado y dispositivo Android)

- Ensayar la ruta Accesibilidad en Moto e30 y otros fabricantes sin pulsar «Borrar datos».
- Comprobar filtros y Top tras conceder el acceso a datos de uso.
- Reanudar tras interrupción y tras cambiar exclusiones.
- Confirmar firma compatible con versiones previas; en APK debug distintas claves pueden impedir actualización.
- Medir el espacio libre antes y después y comprobar que no se informan cifras inventadas.

**No se afirma que el APK haya compilado ni que haya pasado pruebas en teléfonos reales.**
