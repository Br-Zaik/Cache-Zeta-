# Diseño NEO: implementación

Referencia elegida: pantalla de fondo azul profundo, logo Z, círculo cian y tarjeta de almacenamiento a la derecha, dos botones de alcance, 10/50/100 MB, Top 5/10/20/50, limpieza y selección, tres accesos inferiores.

- `MainActivity.java`: coloca los elementos nativos en una sola columna de altura flexible (`LinearLayout` con `layout_weight`). La pantalla principal NO contiene `ScrollView` y dispone de ajustes secundarios en diálogos.
- `CacheRingView.java`: indicador vectorial dibujado con Canvas y Paint; no simula un porcentaje de caché. Muestra raya / Sin analizar hasta obtener permiso y resultados. Muestra progreso durante el análisis.
- `NeonStyle.java`: degradados, bordes y ripple nativos; no hay videos, animaciones de partículas ni assets de alta memoria.
- `res/drawable/ic_brand.xml`: logo Z vectorial escalable en el icono y cabecera.
- `GameActivity.java`: conserva RAM, batería, favoritos y No molestar.
- `CacheAccessibilityService.java`: motor de limpieza de la v4 sin cambios funcionales.

## Opciones adicionales sin saturar la pantalla
- Toca «Sin filtro» para ignorar los umbrales de 10/50/100 MB.
- Toca «Todas» junto al título Top para no limitar el número de apps.
- Toca el indicador grande de caché para analizar. La primera vez te pedirá Acceso a datos de uso.
- Toca ⚙ para permisos, análisis, exclusiones, selección, reanudación e historial.
- Toca ⓘ para ver recuentos, estado y progreso sin colocar grandes bloques de texto en la pantalla.
- El botón grande se convierte en «Detener limpieza» mientras está activa; también se mantiene el botón de detención flotante en la pantalla de Ajustes.

## Pruebas que faltan
- Compilación real `:app:testDebugUnitTest :app:assembleDebug` en GitHub Actions.
- Moto e30 Android 11: comprobar pantalla fija, ajuste de tamaños y clics.
- Samsung One UI, Xiaomi HyperOS/MIUI y otros: probar navegación de Ajustes sin pulsar «Borrar datos».
- Pantallas pequeñas, fuente grande y modo horizontal: validar legibilidad.
