# Comprobaciones pendientes para publicación

## Seguridad funcional (en teléfono real)
- [ ] Moto e30 Android 11: instalar sin cambios peligrosos y mantener Play Protect activado.
- [ ] Abrir Accesibilidad con aviso y consentimiento. Confirmar que se puede detener.
- [ ] Instalar apps: Facebook con caché visible; top 5 por MB: confirmar que corresponde con Ajustes.
- [ ] «Instaladas por mí» excluye apps de sistema; «Todas» incluye sistema y omite pantallas desconocidas.
- [ ] Filtros 10 / 50 / 100 MB, 5 / 10 / 20 / 50 / todas y selección manual funcionan de forma independiente.
- [ ] Ninguna interacción pulsa «Borrar datos», «Borrar almacenamiento» o diálogos peligrosos.
- [ ] Pausar/detener a mitad del recorrido, volver y reanudar sin perder la cola.
- [ ] Repetir con pantalla rotada, app puesta en segundo plano, batería baja y permisos revocados.
- [ ] Medición sin permiso: no inventa MB ni elige por umbral sin análisis.
- [ ] Juegos: RAM, batería, temperatura de batería; hasta 6 favoritos; abrir/no abrir juego desinstalado; No molestar bajo control de usuario.

## Pruebas por fabricante y Android
- [ ] Motorola (Android 11)
- [ ] Samsung (One UI, Android 13+)
- [ ] Xiaomi / Redmi / POCO (MIUI / HyperOS)
- [ ] Realme / OPPO (realme UI / ColorOS)
- [ ] Vivo / Honor / Pixel
- [ ] Android 8 / 9 / 10 / 11 / 12 / 13 / 14 / 15 / 16 (dispositivos reales o emulador; automatización real requiere dispositivo)

Si una pantalla no está reconocida, la aplicación debe omitirla sin ejecutar acciones inseguras.

## Google Play
- [ ] Verificar política actual de Accesibilidad, consentimiento destacado y formulario de declaración.
- [ ] Justificar el uso esencial de `QUERY_ALL_PACKAGES` o reemplazar por visibilidad más limitada si el producto lo permite.
- [ ] Preparar política de privacidad pública y ficha veraz (no prometer FPS extra, incremento de RAM ni limpieza instantánea universal).
- [ ] Firmar AAB de lanzamiento con firma estable y subirlo a pruebas internas/cerradas.
- [ ] Cumplir requisitos de Play Console vigentes para la cuenta antes de producción.

Documentación oficial:
- https://developer.android.com/reference/android/app/usage/StorageStatsManager
- https://developer.android.com/reference/android/app/ActivityManager.MemoryInfo
- https://developer.android.com/reference/android/os/BatteryManager
- https://support.google.com/googleplay/android-developer/answer/10964491
