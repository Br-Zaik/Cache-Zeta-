# v5.2 — Diseño 2 aplicado

- MainActivity: sustituida la pantalla NEO por la distribución Oscuro Azul elegida.
- DesignLayout: colocación adaptable de vistas reales, descontando barras e insets del sistema.
- NeonStyle: paleta plana exacta de la propuesta, con estados seleccionados y ripple discretos.
- Nueve iconos vectoriales Android: información, ajustes, limpieza, juegos, historial, lista, flecha, análisis y almacenamiento.
- Tema oscuro también en diálogos; panel de juegos conserva funciones con la nueva paleta.
- Versionado y nombre del artefacto del workflow actualizados.
- Los motores de medición y limpieza, reglas, historial, exclusiones y favoritos no se modificaron.

Pruebas y alcance de la compilación local descritos en README.md.
