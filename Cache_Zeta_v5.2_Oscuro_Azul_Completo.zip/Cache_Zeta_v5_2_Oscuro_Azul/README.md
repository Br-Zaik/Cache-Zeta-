# Caché Zeta v5.2 — Oscuro Azul

Diseño 2 elegido: fondo oscuro, azul suave, tarjeta de caché sin aro, almacenamiento separado, filtros juntos y navegación inferior compacta. Implementación con vistas Android Java y drawables vectoriales; no utiliza una imagen como pantalla.

## Interfaz

- Cabecera «Limpieza», Información y Ajustes, sin el nombre grande ni el logo.
- Caché medida, estado «Sin analizar» y acción «Volver a analizar».
- Almacenamiento real: barra, porcentaje, usado y total.
- Todas las apps / Instaladas por mí.
- Tamaño: sin filtro, 10 / 50 / 100 MB; cantidad: Top 5 / 10 / 20 / 50 / Todas.
- Limpiar, detener, seleccionar manualmente y reanudar una sesión pendiente.
- Limpieza, Juegos e Historial. Ajustes conserva permisos y exclusiones.

`DesignLayout` distribuye controles nativos usando las proporciones de la referencia y el espacio disponible después de las barras del sistema. Un solo diseño se adapta a las dimensiones de la ventana. La pantalla principal no utiliza ScrollView. Los iconos son recursos vectoriales; no hay brillos animados ni imágenes de fondo.

La imagen de `docs/02_Oscuro_Azul.png` es la referencia aprobada, no una captura de ejecución. Sus cifras son ejemplos. La app consulta los datos del teléfono; conserva preferencias anteriores.

## Generar tu APK

1. Sustituye el ZIP anterior de tu repositorio por este (deja un único ZIP).
2. Conserva tu workflow de GitHub Actions, que detecta el proyecto dentro del ZIP.
3. Ejecuta el workflow y descarga `app-debug.apk` cuando termine.
4. Instálalo y revisa la pantalla con tus permisos y preferencias actuales.

Se incluye también `.github/workflows/android.yml` actualizado. Un workflow contenido dentro de un ZIP no se ejecuta solo: el repositorio debe conservar su archivo de workflow fuera del ZIP, como en el flujo anterior.

## Validación de esta entrega

- Pruebas existentes de selección, orden por caché, filtros, aplicaciones del sistema y etiquetas de seguridad: correctas.
- Análisis de sintaxis Java: correcto.
- Recursos compilados y enlazados con AAPT2 y Android SDK 36.
- Código Java compilado con destino Java 17 contra Android 36.
- DEX generado con D8 para Android 8+ y empaquetado APK de comprobación alineado correctamente.
- El APK de comprobación no está firmado ni incluido: el entregable es el proyecto completo para tu compilación habitual.
- No se ejecutó la app en un teléfono ni en un emulador; falta confirmar el aspecto y funcionamiento en el móvil. Esta validación local usa las herramientas Android directamente, no una ejecución completa de Gradle.

## Funciones y permisos conservados

Datos de uso permite medir la caché; Accesibilidad automatiza únicamente «Borrar caché» dentro de los Ajustes de Android, tras la confirmación del usuario. El motor original de v5.1 conserva exclusiones, cancelación, reanudación, verificación y registro. La aplicación no incluye anuncios ni permiso de Internet.

Android 8+ (`minSdk 26`), destino Android 36, versión `5.2.0-oscuro-azul`, código de versión 7. El fabricante, la fuente y la escala de pantalla pueden cambiar ligeramente el renderizado; los ajustes de accesibilidad extremos requieren comprobación en el dispositivo.
