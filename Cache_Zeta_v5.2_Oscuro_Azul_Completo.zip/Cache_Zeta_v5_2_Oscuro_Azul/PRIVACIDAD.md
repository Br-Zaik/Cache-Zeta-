# Privacidad — Caché Zeta v4

Caché Zeta funciona localmente. No solicita permiso de Internet, no contiene anuncios, analítica ni cuentas.

- **Accesibilidad:** solo cuando el usuario toca «Limpiar caché», lee controles de Ajustes para navegar a almacenamiento y pulsar exclusivamente el texto exacto «Borrar caché». Puede verse información de la pantalla durante ese proceso, según el aviso del sistema. Puede detenerse con el botón de detener o desactivarse desde Ajustes.
- **Acceso a datos de uso:** consulta los MB de caché mediante APIs del sistema para ordenar, filtrar y ofrecer estimaciones. Se concede/revoca en Ajustes.
- **Visibilidad de aplicaciones:** consulta nombres de paquetes instalados para mostrar grupos, seleccionar/excluir y crear favoritos de juegos. Esto está sujeto a las restricciones de Google Play.
- **Datos locales:** guarda exclusiones, selección, favoritos, últimos resultados, historial corto y cola de tareas pendiente. No transmite esta información.
- **Sin acceso:** fotos, documentos, contenidos de otras apps, contactos, mensajes, contraseñas, GPS o servidores externos.

Caché Zeta **no borra datos de usuario, cuentas, archivos ni configuraciones**. Solo intenta activar «Borrar caché» en pantallas de Ajustes que coincidan con las etiquetas seguras. En algunas marcas o versiones puede omitir aplicaciones desconocidas. Los resultados se muestran como acciones realizadas o estimaciones, no como MB liberados garantizados.

Antes de publicarla en Play Store es necesario cumplir la declaración y aviso de Accesibilidad y justificar `QUERY_ALL_PACKAGES` de acuerdo con las políticas vigentes.
