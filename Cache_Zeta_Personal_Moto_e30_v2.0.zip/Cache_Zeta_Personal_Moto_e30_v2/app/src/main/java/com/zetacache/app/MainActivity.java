package com.zetacache.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(10, 16, 32);
    private static final int PANEL = Color.rgb(21, 32, 51);
    private static final int TEXT = Color.rgb(244, 248, 255);
    private static final int MUTED = Color.rgb(160, 178, 198);
    private static final int MINT = Color.rgb(84, 241, 203);
    private static final String PREFS = "privacy_choice";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<AppTarget> allApps = new ArrayList<>();
    private boolean includeSystem = true;
    private TextView appCounter, statusText, resultText, scopeAll, scopeUser, progressText;
    private Button mainButton, accessButton, stopButton;
    private boolean updating = false;

    private final Runnable updateTask = new Runnable() {
        @Override public void run() {
            refresh();
            if (updating) handler.postDelayed(this, 650);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        }
        loadApps();
        createLayout();
    }

    @Override protected void onResume() {
        super.onResume();
        loadApps();
        updating = true;
        handler.removeCallbacks(updateTask);
        handler.post(updateTask);
    }

    @Override protected void onPause() {
        updating = false;
        handler.removeCallbacks(updateTask);
        super.onPause();
    }

    private void loadApps() {
        // QUERY_ALL_PACKAGES: únicamente para la versión personal instalada por APK.
        // Incluye apps sin icono de inicio (p. ej., servicios que sí tienen caché).
        allApps.clear();
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> packages = pm.getInstalledApplications(0);
        for (ApplicationInfo app : packages) {
            String pkg = app.packageName;
            // Nunca manipular los Ajustes desde los que depende la navegación,
            // ni la propia app / framework Android.
            if (pkg.equals(getPackageName()) || pkg.equals("com.android.settings")
                    || pkg.equals("com.samsung.android.settings") || pkg.equals("android")) continue;
            // Una app deshabilitada no tiene interfaz de caché utilizable en Ajustes.
            if (!app.enabled) continue;
            boolean system = (app.flags & (ApplicationInfo.FLAG_SYSTEM
                    | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0;
            CharSequence title = app.loadLabel(pm);
            String label = title == null ? pkg : title.toString().trim();
            if (label.isEmpty()) label = pkg;
            allApps.add(new AppTarget(pkg, label, system));
        }
        Collator collator = Collator.getInstance(new Locale("es"));
        allApps.sort(Comparator.comparing(a -> a.label, collator));
    }

    private List<AppTarget> selection() {
        List<AppTarget> targets = new ArrayList<>();
        for (AppTarget app : allApps) if (includeSystem || !app.system) targets.add(app);
        return targets;
    }

    private void createLayout() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setBackgroundColor(BG);
        scroll.setVerticalScrollBarEnabled(false);
        int horizontal = dp(22);
        scroll.setPadding(horizontal, dp(16), horizontal, dp(40));
        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            int top, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets system = insets.getInsets(WindowInsets.Type.systemBars());
                top = system.top; bottom = system.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(horizontal, top + dp(16), horizontal, bottom + dp(40));
            return insets;
        });
        LinearLayout content = vertical();
        scroll.addView(content);
        setContentView(scroll);

        LinearLayout header = horizontal();
        header.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout iconBackground = vertical();
        iconBackground.setGravity(Gravity.CENTER);
        iconBackground.setBackground(round(Color.rgb(20, 40, 57), 20));
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_brand);
        iconBackground.addView(logo, new LinearLayout.LayoutParams(dp(62), dp(62)));
        header.addView(iconBackground, new LinearLayout.LayoutParams(dp(66), dp(66)));

        LinearLayout brandTexts = vertical();
        brandTexts.setPadding(dp(12), 0, 0, 0);
        brandTexts.addView(label("CACHÉ ZETA", 19, TEXT, true));
        TextView brandSub = label("Espacio limpio. Datos seguros.", 12, MUTED, false);
        brandSub.setPadding(0, dp(2), 0, 0);
        brandTexts.addView(brandSub);
        header.addView(brandTexts);
        content.addView(header);

        LinearLayout hero = vertical();
        hero.setPadding(dp(22), dp(26), dp(22), dp(24));
        hero.setBackground(gradient(Color.rgb(24, 63, 80), Color.rgb(18, 34, 56), 27));
        LinearLayout.LayoutParams hp = matchWrap(); hp.topMargin = dp(28);
        content.addView(hero, hp);
        hero.addView(label("LIMPIEZA DE CACHÉ,\nSIN BORRAR TUS DATOS", 11, MINT, true));
        TextView big = label("Libera espacio\nen pocos toques.", 28, TEXT, true);
        big.setLineSpacing(dp(1), 1f);
        LinearLayout.LayoutParams bigp = matchWrap(); bigp.topMargin = dp(12);
        hero.addView(big, bigp);
        TextView expl = label("Solo la caché. No se pulsa «Borrar datos» ni «Liberar espacio».", 14, MUTED, false);
        LinearLayout.LayoutParams exp = matchWrap(); exp.topMargin = dp(12);
        hero.addView(expl, exp);

        LinearLayout counters = horizontal();
        counters.setGravity(Gravity.CENTER_VERTICAL);
        counters.setPadding(dp(2), dp(14), dp(2), 0);
        LinearLayout counterA = vertical();
        appCounter = label("0", 31, TEXT, true);
        counterA.addView(appCounter);
        counterA.addView(label("APPS DETECTADAS", 10, MUTED, true));
        counters.addView(counterA, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout counterB = vertical();
        statusText = label("● Desactivado", 13, MINT, true);
        counterB.addView(statusText);
        counterB.addView(label("ACCESIBILIDAD", 10, MUTED, true));
        counters.addView(counterB, new LinearLayout.LayoutParams(0, -2, 1f));
        content.addView(counters);

        TextView choose = label("Qué aplicaciones limpiar", 16, TEXT, true);
        LinearLayout.LayoutParams clp = matchWrap(); clp.topMargin = dp(30);
        content.addView(choose, clp);
        LinearLayout chips = horizontal();
        chips.setPadding(0, dp(12), 0, dp(8));
        scopeAll = label("Todas las apps", 13, TEXT, true);
        scopeUser = label("Instaladas por mí", 13, TEXT, true);
        setupChip(scopeAll, chips, true);
        setupChip(scopeUser, chips, false);
        scopeAll.setOnClickListener(v -> { includeSystem = true; updateChips(); refresh(); });
        scopeUser.setOnClickListener(v -> { includeSystem = false; updateChips(); refresh(); });
        content.addView(chips);
        updateChips();

        TextView scope = label("Incluye apps sin icono. Algunas del sistema no permiten borrar caché y se omitirán.", 12, MUTED, false);
        content.addView(scope);
        mainButton = new Button(this);
        mainButton.setTextSize(16);
        mainButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        mainButton.setAllCaps(false);
        mainButton.setTextColor(BG);
        mainButton.setBackground(ripple(MINT, 19));
        mainButton.setMinHeight(0);
        mainButton.setPadding(dp(16), dp(15), dp(16), dp(15));
        mainButton.setOnClickListener(v -> beginCleaning());
        LinearLayout.LayoutParams mbp = matchWrap(); mbp.topMargin = dp(24);
        content.addView(mainButton, mbp);

        accessButton = new Button(this);
        accessButton.setTextSize(13);
        accessButton.setAllCaps(false);
        accessButton.setTextColor(MINT);
        accessButton.setBackground(ripple(PANEL, 17));
        accessButton.setMinHeight(0);
        accessButton.setOnClickListener(v -> requestAccessibility());
        LinearLayout.LayoutParams abp = matchWrap(); abp.topMargin = dp(9);
        content.addView(accessButton, abp);

        LinearLayout results = vertical();
        results.setBackground(round(PANEL, 21));
        results.setPadding(dp(18), dp(16), dp(18), dp(18));
        LinearLayout.LayoutParams rlp = matchWrap(); rlp.topMargin = dp(23);
        content.addView(results, rlp);
        results.addView(label("ESTADO DE LA LIMPIEZA", 11, MINT, true));
        progressText = label("Listo para comenzar", 16, TEXT, true);
        LinearLayout.LayoutParams pp = matchWrap(); pp.topMargin = dp(9);
        results.addView(progressText, pp);
        resultText = label("Sin limpiezas todavía.", 13, MUTED, false);
        LinearLayout.LayoutParams rtp = matchWrap(); rtp.topMargin = dp(5);
        results.addView(resultText, rtp);
        stopButton = new Button(this);
        stopButton.setText("Detener limpieza");
        stopButton.setTextColor(TEXT);
        stopButton.setAllCaps(false);
        stopButton.setBackground(ripple(Color.rgb(104, 45, 60), 13));
        stopButton.setOnClickListener(v -> {
            CacheAccessibilityService service = CacheAccessibilityService.instance();
            if (service != null) service.cancel();
        });
        LinearLayout.LayoutParams stp = matchWrap(); stp.topMargin = dp(12);
        results.addView(stopButton, stp);

        LinearLayout privacy = vertical();
        privacy.setPadding(dp(4), dp(10), dp(4), dp(4));
        LinearLayout.LayoutParams prp = matchWrap(); prp.topMargin = dp(18);
        content.addView(privacy, prp);
        privacy.addView(label("PRIVACIDAD POR DISEÑO", 11, MINT, true));
        TextView paragraph = label("Sin anuncios, sin Internet, sin registro y sin acceso a tus fotos. El servicio solo analiza las pantallas de Ajustes cuando tú inicias la limpieza. Podrás detenerla cuando quieras.", 13, MUTED, false);
        LinearLayout.LayoutParams par = matchWrap(); par.topMargin = dp(6);
        privacy.addView(paragraph, par);
        TextView footer = label("Versión personal 2.0 · Moto e30 (Android 11) · Sin root", 11, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams foot = matchWrap(); foot.topMargin = dp(25);
        content.addView(footer, foot);
        refresh();
    }

    private void setupChip(TextView text, LinearLayout group, boolean first) {
        text.setGravity(Gravity.CENTER);
        text.setPadding(dp(8), dp(13), dp(8), dp(13));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        if (first) lp.rightMargin = dp(8);
        group.addView(text, lp);
    }

    private void updateChips() {
        scopeAll.setBackground(round(includeSystem ? Color.rgb(37, 86, 85) : PANEL, 13));
        scopeUser.setBackground(round(!includeSystem ? Color.rgb(37, 86, 85) : PANEL, 13));
        scopeAll.setTextColor(includeSystem ? MINT : MUTED);
        scopeUser.setTextColor(!includeSystem ? MINT : MUTED);
    }

    private void refresh() {
        if (mainButton == null) return;
        boolean enabled = CacheAccessibilityService.instance() != null;
        boolean running = SessionState.running;
        int count = selection().size();
        appCounter.setText(String.valueOf(count));
        statusText.setText(enabled ? "● Activada" : "● Desactivada");
        statusText.setTextColor(enabled ? MINT : Color.rgb(245, 180, 109));
        mainButton.setText(running ? "LIMPIEZA EN CURSO…" : "✦  LIMPIAR CACHÉ");
        mainButton.setEnabled(!running && count > 0);
        accessButton.setText(enabled ? "✓  Servicio de accesibilidad activo" : "Activar accesibilidad (necesario)");
        accessButton.setEnabled(!running);
        if (running) {
            progressText.setText("Procesando " + SessionState.index + " de " + SessionState.total);
            resultText.setText(SessionState.appName + "\nBotones pulsados: " + SessionState.pressed
                    + " · Omitidas: " + SessionState.skipped);
        } else {
            progressText.setText("Listo para comenzar");
            resultText.setText(SessionState.result);
        }
        stopButton.setVisibility(running ? View.VISIBLE : View.GONE);
    }

    private void requestAccessibility() {
        if (CacheAccessibilityService.instance() != null) {
            new AlertDialog.Builder(this)
                    .setTitle("Accesibilidad activada")
                    .setMessage("Puedes desactivar el servicio en Ajustes de accesibilidad cuando quieras.")
                    .setPositiveButton("Entendido", null)
                    .show();
            return;
        }
        SharedPreferences p = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (p.getBoolean("consent", false)) { openAccessibilitySettings(); return; }
        new AlertDialog.Builder(this)
                .setTitle("Tu consentimiento es necesario")
                .setMessage("Para borrar caché, Caché Zeta necesita utilizar el servicio de Accesibilidad.\n\n"
                        + "Cuando pulses «Limpiar caché», podrá leer únicamente los textos visibles de la pantalla de Ajustes para encontrar «Almacenamiento» y «Borrar caché» y pulsar esos controles.\n\n"
                        + "No almacena contraseñas ni lee contenido para este proceso fuera de Ajustes. No transmite información a Internet. "
                        + "Se detiene al terminar o si cancelas. No utiliza el botón «Borrar datos».\n\n"
                        + "El servicio puede ver contenido de pantalla según el aviso de Android. Actívalo solo si estás de acuerdo.")
                .setNegativeButton("No aceptar", null)
                .setPositiveButton("Acepto y continuar", (d, which) -> {
                    p.edit().putBoolean("consent", true).apply();
                    openAccessibilitySettings();
                })
                .show();
    }

    private void openAccessibilitySettings() {
        try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
        catch (Exception e) {
            new AlertDialog.Builder(this).setMessage("No se pudieron abrir los ajustes de accesibilidad.")
                    .setPositiveButton("Cerrar", null).show();
        }
    }

    private void beginCleaning() {
        if (SessionState.running) return;
        CacheAccessibilityService service = CacheAccessibilityService.instance();
        if (service == null) { requestAccessibility(); return; }
        List<AppTarget> list = selection();
        if (list.isEmpty()) {
            new AlertDialog.Builder(this).setMessage("No se encontraron aplicaciones para limpiar.")
                    .setPositiveButton("Aceptar", null).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("¿Empezar la limpieza?")
                .setMessage("Intentaremos abrir los ajustes de " + list.size() + " apps, una por una. "
                        + "Solo pulsaremos «Borrar caché» cuando aparezca exactamente ese botón.\n\n"
                        + "Mantén el teléfono desbloqueado y no cambies de app. Algunos paquetes del sistema no tienen botón de caché y se omitirán. "
                        + "Tendrás un botón flotante para detener el recorrido.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Empezar", (d, which) -> {
                    service.startCleaning(new ArrayList<>(list));
                    refresh();
                }).show();
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text); view.setTextSize(size); view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        view.setIncludeFontPadding(true);
        return view;
    }
    private LinearLayout vertical() { LinearLayout l = new LinearLayout(this); l.setOrientation(1); return l; }
    private LinearLayout horizontal() { LinearLayout l = new LinearLayout(this); l.setOrientation(0); return l; }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private int dp(float n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private GradientDrawable round(int fill, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill); g.setCornerRadius(dp(radius)); return g;
    }
    private GradientDrawable gradient(int first, int second, int radius) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{first, second});
        g.setCornerRadius(dp(radius)); return g;
    }
    private RippleDrawable ripple(int fill, int radius) {
        return new RippleDrawable(ColorStateList.valueOf(0x36FFFFFF), round(fill, radius), null);
    }
}
