package com.zetacache.app;

import java.text.Normalizer;
import java.util.Locale;

/** Lista blanca estricta: jamás coincide con Borrar datos ni Liberar espacio. */
public final class UiLabels {
    private UiLabels() {}

    static String norm(CharSequence original) {
        if (original == null) return "";
        return Normalizer.normalize(original.toString(), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .toLowerCase(Locale.ROOT)
                .replace('&', 'y')
                .replaceAll("\\s+", " ")
                .trim();
    }

    public static boolean isStorage(CharSequence label) {
        String text = norm(label);
        return text.equals("almacenamiento")
                || text.equals("almacenamiento y cache")
                || text.equals("uso de almacenamiento")
                || text.equals("storage")
                || text.equals("storage y cache")
                || text.equals("storage usage")
                || text.equals("uso de memoria")
                || text.equals("almacenamiento y datos");
    }

    public static boolean isClearCache(CharSequence label) {
        String text = norm(label);
        return text.equals("borrar memoria cache")
                || text.equals("borrar cache")
                || text.equals("eliminar cache")
                || text.equals("clear cache")
                || text.equals("limpiar cache")
                || text.equals("vaciar cache");
    }
}
