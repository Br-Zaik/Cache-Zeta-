package com.zetacache.app;

/** Metadatos mínimos: no se recolectan ni transmiten datos de ninguna app. */
public final class AppTarget {
    public final String packageName;
    public final String label;
    public final boolean system;

    public AppTarget(String packageName, String label, boolean system) {
        this.packageName = packageName;
        this.label = label;
        this.system = system;
    }
}
