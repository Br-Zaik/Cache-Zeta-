# Privacidad — Caché Zeta Personal v2.0

Este proyecto está diseñado para uso individual, sin servidores y sin acceso a Internet.

Al activar el servicio de Accesibilidad de Android, el sistema concede capacidades de observar y controlar algunas interfaces. Caché Zeta solo analiza el contenido de las pantallas de **Ajustes** del teléfono mientras una limpieza está en marcha; identifica etiquetas de almacenamiento y caché, y pulsa los controles correspondientes. No intenta leer o controlar otras apps abiertas.

El permiso `QUERY_ALL_PACKAGES` permite ver nombres de aplicaciones instaladas, incluso cuando no tienen icono, para preparar el recorrido. La información se procesa localmente; no se transmite, se vende ni se envía a ninguna cuenta.

La aplicación no solicita Internet, contactos, SMS, fotos, archivos, micrófono ni ubicación. No incluye anuncios ni componentes de seguimiento. La activación de Accesibilidad requiere consentimiento y una acción manual del usuario. La limpieza no se ejecuta de manera automática ni programada.

El servicio omite pantallas y botones que no reconoce de forma segura; nunca busca botones para borrar datos o almacenamiento completo. El usuario puede pulsar **DETENER** y desactivar Accesibilidad desde Ajustes.

No se ha auditado externamente ni probado en todos los modelos de Android. Se entrega como código fuente de uso personal.
