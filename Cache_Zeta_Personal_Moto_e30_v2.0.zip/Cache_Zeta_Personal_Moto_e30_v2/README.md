# CACHÉ ZETA PERSONAL — Moto e30 · v2.0

**App Android de uso personal**. Pensada principalmente para Motorola Moto e30 (Android 11), también puede funcionar en otros teléfonos con Android 8 o superior. No necesita root, ADB, Shizuku, cuenta, Internet ni pagar. **Se instala por APK; esta versión NO está pensada para publicarse en Play Store.**

## Qué cambia respecto de la v1

- La búsqueda utiliza `QUERY_ALL_PACKAGES` (permitido para uso personal fuera de Play Store), en lugar de limitarse a apps que tienen icono de lanzamiento. Por eso puede **detectar apps sin icono**.
- Dos opciones: **Todas las apps** (incluye apps del sistema habilitadas) o **Instaladas por mí** (solo apps ajenas al sistema).
- Se excluyen Caché Zeta, Ajustes de Android y el paquete base `android` para no romper la navegación durante el recorrido.
- Cuando el botón identificado no responde a una acción accesible, se intenta un toque controlado sobre el **centro del texto exacto** con un gesto de Accesibilidad. No se utilizan coordenadas fijas.
- Se puede hacer un solo desplazamiento para descubrir la opción de almacenamiento que no aparece inicialmente.
- Botón flotante para **DETENER** desde las pantallas de Ajustes.

## Cómo funciona en el teléfono

1. Instala el APK generado por GitHub Actions.
2. Abre **Caché Zeta** y pulsa **Activar accesibilidad (necesario)**. Lee la explicación y acepta solo si quieres darle ese acceso.
3. En **Ajustes → Accesibilidad**, busca **Caché Zeta · Limpieza guiada**, actívalo y vuelve a la app.
4. Escoge **Todas las apps** o **Instaladas por mí**.
5. Toca **LIMPIAR CACHÉ**, confirma y **mantén el Moto e30 desbloqueado sin cambiar de pantalla**. La app abrirá los Ajustes de cada aplicación, entrará a *Almacenamiento y caché* y pulsará **Borrar caché**, si está disponible.
6. Se muestra el progreso y un botón flotante **DETENER**. Al terminar se muestra el número de botones pulsados y de apps omitidas.

**Seguridad:** la lista blanca solo admite las etiquetas exactas «Borrar caché», «Borrar memoria caché», «Limpiar caché», etc. Nunca ejecuta «Borrar datos», «Borrar almacenamiento» ni «Liberar espacio». El toque solo se realiza si se detectó el texto adecuado dentro de la pantalla de Ajustes. No borra fotos, descargas o conversaciones por su cuenta.

**Límite real:** ninguna app de terceros sin root puede garantizar borrar la caché de **todas** las apps. Android puede mostrar botones desactivados, pantallas diferentes, cachés protegidas o paquetes que no tienen esa opción. Por seguridad, Caché Zeta los omite. El contador de «botones pulsados» no representa MB liberados ni garantiza que Android haya eliminado bytes.

## Cómo obtener el APK

1. Crea un repositorio nuevo en GitHub.
2. **Descomprime** el ZIP y sube **todos los archivos que hay dentro**, especialmente la carpeta oculta `.github`.
3. Abre **Actions → APK Caché Zeta Personal → Run workflow**. También se ejecuta al subir cambios a `main` o `master`.
4. Al terminar, abre **Cache-Zeta-Personal-APK** y descarga `app-debug.apk`.
5. En el Moto e30, abre el APK y autoriza instalar archivos desde la aplicación con la que lo abriste, si Android lo solicita.

Este proyecto utiliza Java 17, Android Gradle Plugin 8.13.2, Gradle 8.13 y SDK 36. El workflow instala las herramientas necesarias para compilar. **No se ha probado en un Moto e30 físico**; pueden ser necesarios ajustes después de la primera prueba.

## Privacidad y permisos

- `QUERY_ALL_PACKAGES`: detectar las aplicaciones instaladas, incluidas las que no tienen icono.
- Servicio `BIND_ACCESSIBILITY_SERVICE`: se activa **manualmente** desde los ajustes de Android para leer solo la UI de Ajustes durante la ejecución, pulsar los botones de caché y mostrar el control flotante.
- NO incluye permiso `INTERNET`, lectura de archivos personales, mensajes, contactos, ubicación, anuncios o telemetría.

No activa Accesibilidad por sí sola. Puedes revocarla en cualquier momento en los Ajustes del teléfono. En Android 13+, un APK instalado fuera de una tienda podría requerir autorizar expresamente «ajustes restringidos» en los detalles de la app antes de habilitar Accesibilidad. En el Moto e30 con Android 11 ese paso normalmente no existe.

## Probar primero de forma segura

Recomendación: prueba **Instaladas por mí** primero, verifica la caché de dos o tres apps en Ajustes y después usa **Todas las apps**. Las apps del sistema pueden tardar bastante y suelen no tener opción de limpiar caché.

Motorola indica en su manual la ruta **Almacenamiento y caché → Borrar caché**. Referencia: https://www.manualslib.com/manual/3451630/Motorola-Moto-E-30.html?page=182
