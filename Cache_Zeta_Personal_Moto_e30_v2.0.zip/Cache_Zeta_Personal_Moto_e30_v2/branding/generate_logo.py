"""Crea logos PNG HD desde primitivas vectoriales. No usa fuentes ni recursos externos."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
import math

HERE = Path(__file__).resolve().parent
S = 4
N = 512
SIZE = N*S


def draw_logo(round_mask=False):
    img = Image.new('RGBA', (SIZE, SIZE), (0,0,0,0))
    im = Image.new('RGBA', (SIZE, SIZE), (0,0,0,0))
    pix = im.load()
    # Degradado oscuro moderado con luz en la esquina superior izquierda.
    for y in range(SIZE):
        for x in range(SIZE):
            light = max(0, 1 - math.hypot(x - 450*S, y - 65*S) / (780*S))
            pix[x,y] = (int(8+12*light), int(18+27*light), int(33+31*light), 255)
    mask = Image.new('L', (SIZE, SIZE), 0)
    mdraw = ImageDraw.Draw(mask)
    if round_mask:
        mdraw.ellipse((0,0,SIZE-1,SIZE-1), fill=255)
    else:
        mdraw.rounded_rectangle((0,0,SIZE-1,SIZE-1), radius=110*S, fill=255)
    img.paste(im, (0,0), mask)
    ring_box = (115*S, 113*S, 399*S, 397*S)
    soft = Image.new('RGBA', img.size, (0,0,0,0))
    dsoft = ImageDraw.Draw(soft)
    dsoft.arc(ring_box, 307, 638, fill=(72,238,199,145), width=24*S)
    soft = soft.filter(ImageFilter.GaussianBlur(21*S))
    img = Image.alpha_composite(img, soft)
    d = ImageDraw.Draw(img)
    # Aro de acción sin cerrar y punta de flecha.
    d.arc(ring_box, 307, 638, fill=(78,243,202,255), width=22*S)
    d.line([(355*S,330*S),(400*S,332*S),(393*S,286*S)], fill=(78,243,202,255), width=20*S, joint='curve')
    for x,y in [(355,330),(400,332),(393,286)]:
        d.ellipse(((x-10)*S,(y-10)*S,(x+10)*S,(y+10)*S),fill=(78,243,202,255))
    # Tres líneas: archivos temporales que desaparecen.
    for y,x2 in [(203,303),(254,282),(305,260)]:
        d.line([(197*S,y*S),(x2*S,y*S)], fill=(248,253,255,255),width=19*S)
        d.ellipse(((197-10)*S,(y-10)*S,(197+10)*S,(y+10)*S), fill=(248,253,255,255))
        d.ellipse(((x2-10)*S,(y-10)*S,(x2+10)*S,(y+10)*S), fill=(248,253,255,255))
    # Brillo verde lima en la esquina superior derecha.
    p = (369,109)
    star = [(p[0],p[1]-39),(p[0]+12,p[1]-12),(p[0]+39,p[1]),(p[0]+12,p[1]+12),
            (p[0],p[1]+39),(p[0]-12,p[1]+12),(p[0]-39,p[1]),(p[0]-12,p[1]-12)]
    d.polygon([(int(x*S),int(y*S)) for x,y in star],fill=(219,255,119,255))
    return img.resize((N,N),Image.Resampling.LANCZOS)


def main():
    draw_logo(False).save(HERE/'Cache_Zeta_logo_cuadrado_512.png', optimize=True)
    draw_logo(True).save(HERE/'Cache_Zeta_logo_redondo_512.png', optimize=True)
    print('Logos generados')

if __name__=='__main__':
    main()
