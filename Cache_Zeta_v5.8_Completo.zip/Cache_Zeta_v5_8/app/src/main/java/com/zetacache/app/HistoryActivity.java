package com.zetacache.app;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.graphics.drawable.ColorDrawable;
import java.util.Collections;
import android.view.ViewGroup;
import android.widget.*;
import java.util.List;
import java.util.concurrent.*;

public final class HistoryActivity extends ToolsPage {
    private GridView list;
    private boolean gallery;
    private TextView empty;
    private long session;
    private int ticket,overviewPosition,overviewOffset;
    private final HistoryAdapter adapter=new HistoryAdapter();
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        if(state!=null){
            session=state.getLong("session");gallery=state.getBoolean("gallery");
            overviewPosition=state.getInt("overviewPosition");
            overviewOffset=state.getInt("overviewOffset");
        }
        FrameLayout content=new FrameLayout(this);
        body.addView(content,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f));
        list=new GridView(this);list.setColumnWidth(dp(142));list.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        list.setPadding(0,dp(10),0,dp(12));
        list.setClipToPadding(false);
        list.setHorizontalSpacing(dp(8));list.setVerticalSpacing(dp(8));list.setNumColumns(gallery?GridView.AUTO_FIT:1);
        list.setVerticalScrollBarEnabled(false);
        list.setDrawSelectorOnTop(true);
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent,view,index,id)->{
            ResultsDb.Row row=adapter.getItem(index);
            if(session==0 && row.sessionId>0){
                overviewPosition=list.getFirstVisiblePosition();
                overviewOffset=list.getChildAt(0).getTop()-list.getPaddingTop();
                session=row.sessionId;gallery=row.title.startsWith("Duplicados");
                showPage();
            }else if(gallery){
                LinearLayout contentView=new LinearLayout(this);contentView.setOrientation(LinearLayout.VERTICAL);
                if(!row.image.isEmpty()){
                    ImageView photo=new ImageView(this);photo.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    contentView.addView(photo,-1,dp(208));MediaPictures.bind(photo,"history/"+row.image,()->MediaPictures.archived(this,row.image));
                }
                TextView info=new TextView(this);info.setPadding(dp(16),dp(10),dp(16),dp(8));
                info.setText(row.subtitle+"\n"+(row.removed>=0?CacheScanner.size(row.removed)+" eliminados":row.status));
                contentView.addView(info);
                new android.app.AlertDialog.Builder(this).setTitle(row.title).setView(contentView).setPositiveButton("Cerrar",null).show();
            }
        });
        content.addView(list,new FrameLayout.LayoutParams(-1,-1));
        empty=new TextView(this);empty.setGravity(Gravity.CENTER);empty.setTextColor(NeonStyle.MUTED);
        content.addView(empty,new FrameLayout.LayoutParams(-1,-1));
        list.setEmptyView(empty);
        if(android.os.Build.VERSION.SDK_INT>=33){
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,this::onBackPressed);
        }
    }
    private final android.content.BroadcastReceiver updated=new android.content.BroadcastReceiver(){
        @Override public void onReceive(android.content.Context c,android.content.Intent i){load();}
    };
    @Override protected void onStart(){
        super.onStart();
        android.content.IntentFilter f=new android.content.IntentFilter("com.zetacache.app.HISTORY_CHANGED");
        if(android.os.Build.VERSION.SDK_INT>=33)registerReceiver(updated,f,RECEIVER_NOT_EXPORTED);else registerReceiver(updated,f);
    }
    @Override protected void onStop(){unregisterReceiver(updated);super.onStop();}
    @Override protected void onResume(){super.onResume();load();}
    private void load(){
        heading.setText(session==0?"Historial":"Detalle");
        final long id=session;final int version=++ticket;
        worker.execute(()->{
            List<ResultsDb.Row> rows=ResultsDb.get(this).history(id);
            if(id==0){
                String old=HistoryStore.get(this);
                if(!old.startsWith("Sin limpiezas")) for(String line:old.split("\n"))rows.add(new ResultsDb.Row(-1,"Registro anterior",line,"",-1,-1));
            }

            runOnUiThread(()->{
                if(version!=ticket||isDestroyed())return;
                empty.setText(id==0?"Todavía no hay limpiezas.":"Sin elementos registrados.");
                boolean opening=adapter.rows.isEmpty()&&!rows.isEmpty();
                adapter.replace(rows);
                if(opening){
                    if(id==0)list.setSelectionFromTop(overviewPosition,overviewOffset);
                    if(android.animation.ValueAnimator.areAnimatorsEnabled()){
                        list.setAlpha(.8f);list.animate().alpha(1f).setDuration(130).start();
                    }
                }
            });
        });
    }
    private void showPage(){
        list.setNumColumns(gallery?GridView.AUTO_FIT:1);list.animate().cancel();list.setAlpha(1f);
        adapter.replace(Collections.emptyList());
        empty.setText("");
        load();
    }
    private final class HistoryAdapter extends BaseAdapter {
        private List<ResultsDb.Row> rows=Collections.emptyList();
        void replace(List<ResultsDb.Row> next){rows=next;notifyDataSetChanged();}
        @Override public int getCount(){return rows.size();}
        @Override public ResultsDb.Row getItem(int position){return rows.get(position);}
        @Override public long getItemId(int position){return position;}
        @Override public boolean areAllItemsEnabled(){return false;}
        @Override public boolean isEnabled(int position){return gallery||rows.get(position).sessionId>0;}
        @Override public View getView(int position,View recycled,ViewGroup parent){
            if(gallery){
                GalleryTile tile=recycled instanceof GalleryTile?(GalleryTile)recycled:new GalleryTile(HistoryActivity.this);
                ResultsDb.Row row=getItem(position);tile.mark.setVisibility(View.GONE);
                tile.title.setText(row.title);tile.symbol.setText(GalleryTile.format(row.title));
                tile.caption.setText(row.removed>=0?CacheScanner.size(row.removed)+" eliminados":row.status);
                tile.caption.setTextColor(row.removed>0?0xFFFFA0A4:NeonStyle.MUTED);
                if(row.image.isEmpty())MediaPictures.clear(tile.picture);
                else MediaPictures.bind(tile.picture,"history/"+row.image,()->MediaPictures.archived(getApplicationContext(),row.image));
                return tile;
            }
            HistoryCard card=!(recycled instanceof HistoryCard)?new HistoryCard(HistoryActivity.this):(HistoryCard)recycled;
            card.bind(getItem(position));
            return card;
        }
    }
    @Override protected void onSaveInstanceState(Bundle b){
        super.onSaveInstanceState(b);b.putLong("session",session);b.putBoolean("gallery",gallery);
        b.putInt("overviewPosition",overviewPosition);b.putInt("overviewOffset",overviewOffset);
    }
    @Override public void onBackPressed(){if(session!=0){session=0;gallery=false;showPage();}else finish();}
    @Override protected void onDestroy(){worker.shutdownNow();super.onDestroy();}
}
