package com.zetacache.app;

import android.app.AlertDialog;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.provider.Settings;
import android.Manifest.permission;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;

public final class DuplicatesActivity extends ToolsPage {
    private int kind;
    private volatile int revision;
    private TextView status;
    private Button scan,access;
    private long approvalSession;
    private boolean requesting;
    private final BroadcastReceiver volumes=new BroadcastReceiver(){public void onReceive(Context c,Intent i){restartScan();}};
    private GridView grid;
    private Button select,review;
    private final Adapter adapter=new Adapter();
    private List<DuplicateIndex.Family> families=Collections.emptyList();
    private final ArrayList<DuplicateIndex.Item> all=new ArrayList<>(),shown=new ArrayList<>();
    private final Map<String,Integer> owner=new HashMap<>();
    private final Set<String> selected=new HashSet<>();
    private GalleryViewer viewer;
    private boolean reviewing,paused;
    private final Button[] tabs=new Button[3];
    private final Map<Integer,Set<String>> tabSelections=new HashMap<>();
    private final ExecutorService reader=Executors.newSingleThreadExecutor();
    private final BroadcastReceiver updated=new BroadcastReceiver(){public void onReceive(Context c,Intent i){int type=i.getIntExtra("kind",-1);if(!deleting&&(type<0||type==kind)){if(i.getBooleanExtra("published",true))refresh();else updateStatus();}}};
    private boolean deleting;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);kind=b==null?0:b.getInt("kind");heading.setText("Duplicados");
        if(b!=null){approvalSession=b.getLong("approval");requesting=b.getBoolean("requesting");deleting=approvalSession!=0;}
        LinearLayout types=new LinearLayout(this);body.addView(types);
        for(int i=0;i<tabs.length;i++){
            final int type=i;tabs[i]=button(DuplicateIndex.TITLES[i]);action(types,tabs[i]);
            tabs[i].setOnClickListener(v->{
                if(deleting||kind==type)return;
                tabSelections.put(kind,new HashSet<>(selected));
                kind=type;paused=false;reviewing=false;selected.clear();groups=0;stamp=0;
                install(Collections.emptyList());selected.addAll(tabSelections.getOrDefault(kind,Collections.emptySet()));
                showType();
            });
        }
        LinearLayout actions=new LinearLayout(this);body.addView(actions);
        access=button("Cambiar selección");action(actions,access);access.setOnClickListener(v->requestAccess());
        scan=button("Analizar");action(actions,scan);scan.setOnClickListener(v->{
            if(!DeviceStorage.allowed(this,kind)){requestAccess();return;}
            if(DuplicateIndex.pending(kind)){paused=true;DuplicateIndex.cancel();}else{paused=false;DuplicateIndex.focus(this,kind,true);}
            updateStatus();
        });
        status=new TextView(this);status.setTextColor(NeonStyle.MUTED);status.setPadding(dp(6),dp(9),dp(6),dp(9));body.addView(status);
        grid=new GridView(this);grid.setNumColumns(GridView.AUTO_FIT);grid.setColumnWidth(dp(142));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);grid.setHorizontalSpacing(dp(8));grid.setVerticalSpacing(dp(8));
        grid.setAdapter(adapter);body.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout bar=new LinearLayout(this);body.addView(bar);
        select=button("Marcar copias");action(bar,select);select.setOnClickListener(v->bulk());
        review=button("Revisar");action(bar,review);review.setOnClickListener(v->{
            if(reviewing)confirmBatch();else{reviewing=true;render();grid.setSelection(0);}
        });
    }
    @Override protected void onStart(){
        super.onStart();IntentFilter f=new IntentFilter(DuplicateIndex.EVENT);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(updated,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(updated,f);
        IntentFilter mounts=new IntentFilter();mounts.addAction(Intent.ACTION_MEDIA_MOUNTED);mounts.addAction(Intent.ACTION_MEDIA_UNMOUNTED);
        mounts.addAction(Intent.ACTION_MEDIA_REMOVED);mounts.addDataScheme("file");
        if(Build.VERSION.SDK_INT>=33)registerReceiver(volumes,mounts,Context.RECEIVER_EXPORTED);else registerReceiver(volumes,mounts);
        if(Build.VERSION.SDK_INT>=34 && (DeviceStorage.partial(this,0)||DeviceStorage.partial(this,1))){
            DuplicateIndex.cancel();
            for(int k=0;k<2;k++)if(DeviceStorage.partial(this,k))DuplicateIndex.prefs(this).edit().remove("scope"+k).apply();
        }
        if(paused)DuplicateIndex.cancel();
        showType();
    }
    @Override protected void onPause(){if(viewer!=null){viewer.close();viewer=null;}super.onPause();}
    @Override protected void onStop(){if(viewer!=null){viewer.close();viewer=null;}unregisterReceiver(volumes);unregisterReceiver(updated);super.onStop();}
    @Override protected void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);b.putInt("kind",kind);b.putLong("approval",approvalSession);b.putBoolean("requesting",requesting);}
    @Override protected void onDestroy(){reader.shutdownNow();super.onDestroy();}
    private long stamp;
    private int unread,groups;
    private boolean authorized;
    private void updateStatus(){
        boolean limited=DeviceStorage.partial(this,kind);
        access.setVisibility(limited?android.view.View.VISIBLE:android.view.View.GONE);
        access.setEnabled(!deleting&&!requesting);
        boolean working=DuplicateIndex.pending(kind);
        scan.setEnabled(!deleting&&!requesting&&!reviewing);
        scan.setText(!authorized?"Dar acceso":working?"Pausar":paused?"Reanudar":"Analizar "+DuplicateIndex.TITLES[kind].toLowerCase(Locale.ROOT));
        for(Button tab:tabs)tab.setEnabled(!deleting);
        if(deleting)status.setText("Verificando copias…");
        else if(!authorized)status.setText(kind==2&&Build.VERSION.SDK_INT>=30?"Permite el acceso a todos los archivos.":"Permite el acceso para buscar duplicados.");
        else if(reviewing)status.setText("Copias que vas a borrar · "+selected.size());
        else if(working)status.setText("Analizando "+DuplicateIndex.TITLES[kind].toLowerCase(Locale.ROOT)+"…");
        else if(paused)status.setText("Análisis pausado");
        else if(DuplicateIndex.progress.equals("No se pudo analizar "+DuplicateIndex.TITLES[kind].toLowerCase(Locale.ROOT)))status.setText(DuplicateIndex.progress);
        else if(stamp==0)status.setText("Pendiente de análisis");
        else status.setText((groups==0?"Sin duplicados":groups+" grupos")+(limited?" · Acceso parcial":"")+(unread>0?" · "+unread+" sin acceso":""));
        if(select!=null){
            select.setEnabled(!deleting&&!all.isEmpty());
            select.setText(reviewing?"Volver":selected.size()>0&&selected.size()==all.size()-families.size()?"Desmarcar":"Marcar copias");
            review.setEnabled(!deleting&&!selected.isEmpty());
            review.setText((reviewing?"Borrar":"Revisar")+(selected.isEmpty()?"":" ("+selected.size()+")"));
        }
    }
    private void showType(){
        authorized=DeviceStorage.allowed(this,kind);
        if(!authorized)install(Collections.emptyList());
        for(int i=0;i<tabs.length;i++)tabs[i].setBackground(NeonStyle.ripple(NeonStyle.chip(this,i==kind)));
        if(!deleting&&!paused)DuplicateIndex.focus(this,kind,false);
        updateStatus();refresh();
        if(!authorized&&!requesting&&!deleting&&kind<2 && !DuplicateIndex.prefs(this).getBoolean("asked"+kind,false))requestAccess();
    }
    private void refresh(){
        final int type=kind,ticket=++revision;
        reader.execute(()->{
            if(ticket!=revision)return;
            String scope=DeviceStorage.scope(this,type);
            boolean current=!scope.isEmpty()&&scope.equals(DuplicateIndex.prefs(this).getString("scope"+type,""));
            List<DuplicateIndex.Family> data=current?DuplicateIndex.families(this,type):Collections.emptyList();
            long when=current?DuplicateIndex.prefs(this).getLong("time"+type,0):0;
            runOnUiThread(()->{
                if(isDestroyed()||ticket!=revision||deleting)return;
                authorized=!scope.isEmpty();groups=data.size();stamp=when;
                unread=DuplicateIndex.prefs(this).getInt("unread"+type,0);install(data);
            });
        });
    }
    private void install(List<DuplicateIndex.Family> data){
        families=data;all.clear();owner.clear();
        for(int i=0;i<data.size();i++){
            List<DuplicateIndex.Item> copies=data.get(i).items;
            for(DuplicateIndex.Item item:copies){all.add(item);owner.put(item.doc,i);}
            boolean keep=false;for(DuplicateIndex.Item item:copies)if(!selected.contains(item.doc)){keep=true;break;}
            if(!keep)selected.remove(copies.get(0).doc);
        }
        selected.retainAll(owner.keySet());if(selected.isEmpty())reviewing=false;
        render();
    }
    private void render(){
        shown.clear();for(DuplicateIndex.Item item:all)if(!reviewing||selected.contains(item.doc))shown.add(item);
        adapter.notifyDataSetChanged();updateStatus();
    }
    private void bulk(){
        if(reviewing){reviewing=false;render();return;}
        if(selected.size()==all.size()-families.size())selected.clear();
        else for(DuplicateIndex.Family family:families)family.markCopies(selected);
        render();
    }
    private void mark(DuplicateIndex.Item item){
        if(deleting)return;
        if(!families.get(owner.get(item.doc)).toggle(item,selected))toast("Desmarca otra copia del grupo para conservarla.");
        if(selected.isEmpty())reviewing=false;
        render();
    }
    private final class Adapter extends BaseAdapter{
        public int getCount(){return shown.size();}
        public DuplicateIndex.Item getItem(int i){return shown.get(i);}
        public long getItemId(int i){return i;}
        public android.view.View getView(int position,android.view.View recycled,android.view.ViewGroup parent){
            GalleryTile tile=recycled==null?new GalleryTile(DuplicatesActivity.this):(GalleryTile)recycled;
            DuplicateIndex.Item item=getItem(position);
            tile.title.setText(item.name);
            int group=owner.get(item.doc);
            String volume=item.path.split(" / ",2)[0];
            tile.caption.setText(volume+"\nGrupo "+(group+1)+" · "+CacheScanner.size(item.size)+(selected.contains(item.doc)?" · Borrar":" · Conservar"));
            tile.symbol.setText(kind==2?GalleryTile.format(item.name):kind==1?"▶":"Foto");
            if(item.kind<2)MediaPictures.bind(tile.picture,item.doc+"/"+item.mtime,()->MediaPictures.thumbnail(getApplicationContext(),item.uri,item.kind));
            else MediaPictures.clear(tile.picture);
            tile.mark.setChecked(selected.contains(item.doc));tile.mark.setEnabled(!deleting);
            tile.mark.setContentDescription("Marcar "+item.name);tile.mark.setOnClickListener(v->mark(item));
            tile.setOnClickListener(v->{if(!deleting){if(viewer!=null)viewer.close();int current=shown.indexOf(item);if(current>=0)viewer=new GalleryViewer(DuplicatesActivity.this,new ArrayList<>(shown),current);}});
            return tile;
        }
    }
    private void invalidateAccess(){
        SharedPreferences.Editor edit=DuplicateIndex.prefs(this).edit();
        for(int k=0;k<3;k++)edit.remove("scope"+k);
        edit.apply();
    }
    private void restartScan(){if(deleting)return;DuplicateIndex.cancel();showType();}
    private void requestAccess(){
        if(requesting)return;
        if(kind==2 && Build.VERSION.SDK_INT>=30){
            Intent settings=new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,Uri.parse("package:"+getPackageName()));
            try{requesting=true;startActivityForResult(settings,44);}
            catch(ActivityNotFoundException e){
                try{startActivityForResult(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION),44);}
                catch(ActivityNotFoundException noSettings){requesting=false;toast("Abre Acceso especial → Acceso a todos los archivos en Ajustes.");}
            }
            return;
        }
        String primary=Build.VERSION.SDK_INT>=33?DeviceStorage.mediaPermission(kind):permission.READ_EXTERNAL_STORAGE;
        boolean asked=DuplicateIndex.prefs(this).getBoolean("asked"+kind,false);
        if(asked&&!DeviceStorage.allowed(this,kind)&&!shouldShowRequestPermissionRationale(primary)){
            requesting=true;
            startActivityForResult(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())),44);return;
        }
        List<String> permissions=new ArrayList<>();permissions.add(primary);
        if(Build.VERSION.SDK_INT>=34)permissions.add(permission.READ_MEDIA_VISUAL_USER_SELECTED);
        if(Build.VERSION.SDK_INT<30)permissions.add(permission.WRITE_EXTERNAL_STORAGE);
        DuplicateIndex.prefs(this).edit().putBoolean("asked"+kind,true).apply();requesting=true;
        requestPermissions(permissions.toArray(new String[0]),45);
    }
    @Override public void onRequestPermissionsResult(int code,String[] names,int[] values){
        super.onRequestPermissionsResult(code,names,values);
        if(code==45){requesting=false;paused=false;invalidateAccess();restartScan();}
    }
    @Override protected void onActivityResult(int code,int result,Intent data){
        super.onActivityResult(code,result,data);
        if(code==44){requesting=false;paused=false;invalidateAccess();restartScan();}
        if(code==46&&approvalSession!=0){
            long session=approvalSession;approvalSession=0;
            DuplicateIndex.worker.execute(()->{
                DuplicateIndex.resolveChunk(this,session,result==RESULT_OK);
                if(result==RESULT_OK)approval(session);else complete(DuplicateIndex.finishRemoval(this,session));
            });
        }
    }
    private void approval(long session){
        ArrayList<Uri> chunk=DuplicateIndex.nextApproval(this,session);
        if(chunk.isEmpty()){complete(DuplicateIndex.finishRemoval(this,session));return;}
        runOnUiThread(()->{
            if(!isDestroyed()&&!isFinishing()){
                try{
                    approvalSession=session;
                    startIntentSenderForResult(MediaStore.createDeleteRequest(getContentResolver(),chunk).getIntentSender(),46,null,0,0,0);
                    return;
                }catch(IntentSender.SendIntentException|RuntimeException e){approvalSession=0;}
            }
            DuplicateIndex.worker.execute(()->complete(DuplicateIndex.finishRemoval(this,session)));
        });
    }
    private void complete(String message){
        runOnUiThread(()->{
            if(isDestroyed())return;
            deleting=false;selected.clear();reviewing=false;toast(message);render();refresh();
        });
    }
    private void confirmBatch(){
        if(selected.isEmpty()||deleting)return;
        long bytes=0;for(DuplicateIndex.Item item:shown)bytes+=item.size;
        new AlertDialog.Builder(this).setTitle("Borrar "+selected.size()+" copias")
            .setMessage(CacheScanner.size(bytes)+" seleccionados. Se conservará al menos una copia por grupo.")
            .setNegativeButton("Cancelar",null).setPositiveButton("Borrar",(d,w)->{
                deleting=true;updateStatus();DuplicateIndex.cancel();++revision;
                List<DuplicateIndex.Family> batch=new ArrayList<>(families);
                Set<String> marked=new HashSet<>(selected);int type=kind;
                DuplicateIndex.worker.execute(()->{
                    try{
                        DuplicateIndex.Removal result=DuplicateIndex.remove(getApplicationContext(),batch,marked,type);
                        if(result.needsApproval){approval(result.session);return;}
                        complete(result.message);
                        if(result.originalUnavailable)runOnUiThread(()->explainOriginal());
                    }catch(RuntimeException e){complete("Revisa el resultado en Historial.");}
                });
            }).show();
    }
    @Override public void onBackPressed(){
        if(reviewing&&!deleting){reviewing=false;render();return;}
        super.onBackPressed();
    }
    private void explainOriginal(){
        if(isDestroyed()||isFinishing())return;
        AlertDialog.Builder dialog=new AlertDialog.Builder(this).setTitle("Verificar los originales")
                .setMessage("Android no entregó los archivos originales para comparar todos sus bytes, incluidos los metadatos. Las copias sin verificar se conservaron.")
                .setNegativeButton("Cerrar",null);
        if(checkSelfPermission(permission.ACCESS_MEDIA_LOCATION)!=android.content.pm.PackageManager.PERMISSION_GRANTED)
            dialog.setPositiveButton("Permitir acceso",(d,w)->requestPermissions(new String[]{permission.ACCESS_MEDIA_LOCATION},47));
        dialog.show();
    }
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_SHORT).show();}
}
