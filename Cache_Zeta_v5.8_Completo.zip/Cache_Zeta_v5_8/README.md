# Caché Zeta 5.8

Proyecto Android nativo en Java. Android 8 o posterior (API 26–36 como intervalo de compilación y destino). Para generar el APK, sustituye el ZIP anterior en tu repositorio y usa tu workflow habitual de GitHub Actions.

## Limpieza

El inicio muestra caché medida y almacenamiento. Elige Todas las apps, Instaladas por mí o Sistema, y un mínimo inclusivo de 5 MB, 10 MB o un valor manual desde 5 MB. El mínimo de 5 MB también se aplica a la selección manual y a la reanudación. La selección manual respeta las apps marcadas sin recortarlas al Top. Los tamaños que el sistema no deja medir quedan fuera. Antes de comenzar se vuelven a medir las apps seleccionadas.

Al abrir Limpieza o volver desde fuera de la app con acceso de uso, se comprueba el permiso y se reutiliza la medición reciente. El análisis arranca automáticamente si faltan datos, cambió la lista de apps o pasaron 15 minutos. Se muestra la última medición mientras llega el resultado actualizado. También se puede pulsar Volver a analizar. Accesibilidad informa si el servicio está activo, si Android aún debe conectarlo o si está desactivado.

## Duplicados

En Fotos y Videos concede el permiso que muestra Android. Se consulta automáticamente la galería disponible en la memoria interna y en las tarjetas montadas. En Android 14 o posterior, si autorizas solo algunos elementos, la búsqueda se limita a esa selección. Puedes ampliarla desde «Cambiar selección».

En Archivos, toca «Dar acceso». En Android 11 o posterior activa «Acceso a todos los archivos» y regresa a la app. Se buscan documentos, audios, descargas y otros archivos compartidos. Las carpetas privadas de apps no están incluidas. Cada copia indica su almacenamiento y ruta. Al entrar se revisan las categorías autorizadas que necesitan actualizarse. Los resultados recientes se reutilizan durante 15 minutos. Cambiar de pestaña da prioridad a la categoría visible. También puedes pausar o analizar manualmente.

Se agrupan archivos no vacíos del mismo tipo por tamaño. Solo los candidatos se leen para calcular SHA-256. La app reutiliza huellas cuando el identificador, el tamaño y la fecha de modificación coinciden. El índice temporal está en disco. Los videos se leen por bloques de 64 KiB. Pausar conserva el último resultado completo. La enumeración de nombres y fechas puede tomar tiempo en una SD grande.

La galería muestra las copias agrupadas. «Marcar copias» conserva la primera ubicación de cada grupo por orden de ruta, o una que hayas dejado desmarcada. Revisa las miniaturas, cambia las marcas y confirma el lote. Android puede pedir confirmación por bloques en lotes grandes. El visor detiene el video al pasar al siguiente. Antes de borrar se comparan los bytes con una copia conservada. En el detalle del historial aparecen las miniaturas disponibles de las nuevas eliminaciones.

## Historial

Historial abre una pantalla independiente. Las tarjetas muestran el tamaño inicial en verde y lo eliminado en rojo suave. Un guion indica que falta la medición. Cada sesión de caché muestra las apps previstas, omitidas, pendientes o pulsadas. Los MB se calculan a partir de las mediciones anterior y posterior. Sin una segunda medición válida se indica «Sin verificar». En los duplicados se guardan nombre, ubicación, tamaño y resultado. Los registros de versiones anteriores siguen disponibles como resúmenes.

El comportamiento de Accesibilidad depende de los controles que muestre el fabricante en Ajustes. La app omite las pantallas que no identifica.
